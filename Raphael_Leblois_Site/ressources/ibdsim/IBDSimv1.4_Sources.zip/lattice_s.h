/***************************************************************************
� R. leblois 2005- for code collection
leblois@mnhn.fr

This file is part of IBDSim. This software is a computer program
whose purpose is to perform population genetic simulations.

This software is governed by the CeCILL license under French law and
abiding by the rules of distribution of free software.  You can  use,
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info".

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability.

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or
data to be ensured and,  more generally, to use and operate it in the
same conditions as regards security.

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

 ***************************************************************************/
#ifndef SANS_PTR_H
#define SANS_PTR_H


/********generation by generation coalescent programme*********************
********* two dimension continuous populations of finite size on a lattice********************************
*********pre-specified dispersal distribution with variable kurtosis or*******************
********* user defined stepping stone between adjacent nodes or *******************************
********* user defined geomatric and sichel mixture distributions*******************************
*********heterogeneities of dispersal and density in time added*********************
*********heterogeneities of density in space**************************
************************************************


5)v9 23 07 2002
ajout des modification faites prealablement dans v7redsurf.c pour reduction
de surface rejane faites le 28052002
variables dimRes1 et dimRes2 utilis�es dans procedures de dispersion.
101ssIAM OK 500 loci 40 000 cf fichiers pdf
1019 OK
1015IAM OK
1010ssIAM OK
10109IAM ??
10105IAM ??

6)v9 23 07 2002
modification pour que l'echantillon ne se retrouve pas toujours
dans un coin du grand torre (avant expansion)
modification des "sorties" avec translation
prise en compte des vides dans nouvelle procedure calcul proba d'id.


7)v9 1 08 2002
modif fis : calcul en utilisant les proba d'id calculee par ailleurs
verification :
101ssIAM 50 000 200 loci OK
1010ssIAM 100 000 200 loci a lancer (prevoir a peu pres 48h)

8)115082002 modif des proba d'identit� :
on fait le tour que si l'on est sur un torre.
ajout des calculs des proba d'id intra individu Qind2,Qind_moy
verif 101ssIAM 10 000 500 loci OK
verif 101s4v1IAM 10 000 500 loci OK
verif s1v3 Q et FIS 10 000 500 loci OK
verif  101ss densit� 10 10000 500 loci OK 130186 secondes

9) v93 25032003
quelque corrections sur calculs des proba d'id
attention : le Fis et toujours calcul� sur l'�chantillon et pas sur la pop entiere
verification Fis local avec mathematica OK

10)v94sanspoint pour enlever les putain de bug qui traine depuis 3 ans!
verif ss101kam 10 000 500 loci tres bon
verif s4v1101kam 10 000 500 loci OK
verif s4v3101d10kam 10 000 500 loci OK


plus de prb persistants :probleme de pointeur quand torre de 20*20 21*21 22*22 apres c'est bon
bizarre
ca marche bien quand on enleve lez pointeurs

11)v95 on rajoute les pointeurs
marche bien avec isoutils2.c
verif ss101kam 10 000 500 loci TRES BON
verif s4v1101kam 10 000 500 loci excellent
verif s4v3101d10kam 10 000 500 loci ok

il y avait un probleme dans translationx et y qui se faisait meme quand on changait pas de taille de reseau = a toute les generations
on avait donc des individus qui etait en dehors du reseau!

12)v96 22052003
problemes avec les pointeurs compteur et identity dans calcul proba d'id.
momentanement remplac� par un gros tableau de 500
verifier les ditributions de disp
quelque chose bizarre car x != y quand reflectif...

17072003
pas de differences dansles proc de calc stat disp.
voir la disp en elle meme.

13) on a enlev� dispy_fixe maintenant que dispx_fixe pour y et x.
bizarre il semble que les y disperse moins...malgres la meme procedure...

14) v97 bug dans disp_fixe, il y avait une translation apres migration pour les x, enlev�e...
ne jouais pas pour dispersif mais pour torre et reflectif!


15) modifs dans la creation des fichiers migrate


16)v10 = avec les calcul de HobsNei et delta H et variance de taille alleliques
//02022004 ajout de M la statistique de garza et williamson

17) ajout de l'�criture de fichiers DG2002 pour FR
a modifer pour 2 dim (sp�cialement de le calcul du numero attribu� a la pop)

18) ajout de la migration g�om�trique 'g' pour FR

19) V11 correction bug dans calcul de M=taille max- taille min, ajout de +1

20) V12 petites corrections :
			stop si echantillon mal plac� ou trop grand par rapport a dimRes1/2G0
			affichage des dimension du reseau : print dimRes1/2G0 et plus dim_reseau1/2 qui ne veut plus rien dire...
			
21) FER 08/2005: remplac� malloc... free par new... delete dans isoutils
	remplac� les autres malloc... de m�me ou par STL.
	Introduit les variables dy_min, dy_max
	Ecritures infos dans simulpars

nouvelle version c++

22) RL: Nouvelle version:
		ajout d'un fichier de parametres
		possibilit� d'avoir un taux de mutation variable par locus (loi gamma de moyenne pour l'instant fix�e a 5.10-4)
		changement du g�n�rateur de nombre aleatoire, marsaglia remplac� par mersenne twister
		possibilit� de d�finir les coordonn�es de l'�chantillon
		fixe n'a plus a etre rentr� comme parametre mais fonction des autyres parametres (vide et zone)
		taux de migration fix� par l'utilisateur pour le stepping stone.
		considere aussi bien des diploides que des haploides (sachant que la migration est toujours gametique)
		 

commentaires RL sur modifs de FR : 	
int lPSON=dim_reseau1; pose peut etre probleme si taille de reseau variable (a verifier, remplacer par dim_Res1?)

a faire :

mettre choix torre, absorbant ou reflectif dans le fichier de parametres
ajouter la petite transfo pour modele lin�aire cf v10lineaire.c pour eviter que de faire des
tours sur la seconde dimension quand on est en une dimension et en cercle.
a tester = le mieux serait de mettre un test selon la dimension du r�seau pour eviter qu'il fasse des tours de torres sur y quand une seule dimension

a faire pour speeder : (on s'en fiche un peu vu que la vitesse n'est pas une priorit�)

1)ajuster l'allocation de m�moire pour la dispersion (disdis(); tabdis[][].cum2[][],...) en fonction de fixe_global : 
  si on est toujours en fixe=1 et disp constante, allouer une fois par run
  si il y a 1 changement de fixe ou de disp, allouer au premier changement
  si il y a plusieurs changement de fixe ou disp, allouer a chaque changement ou faire un tableau par cas
2)mettre des inline pour certaines proc�dures
3)eviter les lectures r�p�t�es dans les tableaux = remplacer par des variables locales
******************************************************************************************/


#define PI 3.14159265358979323846264338328

// comments for each function are in the main .cpp files before each function implementation
//order is the same than in the main .cpp file
int analyse(int mls,int tranche);
int analyse(int mls);
int read_settings_file(const char filename[]);
int (*SortieSupfnPtr1)(int coord, int dim);
int (*SortieSupfnPtr2)(int coord, int dim, int trans);
int (*SortieInffnPtr1)(int coord, int dim);
int (*SortieInffnPtr2)(int coord, int dim, int trans);
int sortie_sup_circ_abs1(int coord, int dim);
int sortie_inf_circ_abs1(int coord, int dim);
int sortie_sup_circ_abs2(int coord, int dim, int trans);
int sortie_inf_circ_abs2(int coord, int dim, int trans);
int sortie_sup_refl1(int coord, int dim);
int sortie_inf_refl1(int coord, int dim);
int sortie_sup_refl2(int coord, int dim, int trans);
int sortie_inf_refl2(int coord, int dim, int trans);
int new_disdis(const int dxmax); 
int new_disdis(const int dxmax,const int dymax); 
void affichage_ecran(void);
void ini_moy_glob(void);
void ini_tableaux(void);/*initialisation des tableaux par locus*/
void ini_tableaux_specifique(void);//initialisation pour echantillon special
void ini_struct_noeud(void);
void ini_struct_noeud2(void);/*reinitialisation si locus
									  precedent monomorphe*/
void ini_moy(void);
void ini_migra(void);
char migra_tps(long int G);/*caracteristiq de disp*/
void forw(void);
void new_disp(void);
int getDensityFromFile(void);
int  calcul_densite(int coordx, int coordy);
void cumul1(void);
void cumul2(void);
void dispxy(void);
int  decim_tabdis(int coordx);
void disp_fixe(void);
void cumul_fixex(int k);
void cumul_fixey(int k);
int  dispx_fixe(void);
int dispy_fixe(void);
int ComputeDemeSize(void);
void nbre_aleat_noeud(void);
double gamma_mut(double rate);/*pour taux de mut variable*/
int K_ini(void);
void compter_alleles_KAM(void);
void compter_alleles_SMM(void);
void compter_alleles_IAM(void);
void compter_alleles_TPM(void);
void compter_alleles_GSM(void);
void compter_allele (void);
void entete_fichier(void);
void ecriture_fichier(void);
void ecriture_fichier_migrate(void);
void ecriture_fichiers_DG2002KAM(void);
void ecriture_fichiers_DG2002SMM(void);
void ecriture_fichier_moyennes(void);
void ecriture_disp(void);//ecriture des distances de dispersion "efficaces"
void ecriture_disp_moy(void);//ecriture des distances de dispersion "efficaces" moyennes sur repets
void ecriture_fichier_Fis_Het(void);
void ecriture_fichier_Fis_Het_cpp();
void calcul_proba_identite(void);
void ecriture_matrice_proba_id(void);
void calcul_proba_identite_matrice(void);
void calcul_coa_individuel(void);
void calcul_stat_disp(void);
void calcul_stat_disp_moy(void);
void calcul_hetero_fis(void);
void freq_sample(void);
void var_allele(void);



double binom(double pp,int n);
double gammln(double xx);/*pour procedure loi de poisson*/
int loi_geom(const double var_geom);
int  mutation(long int temps);
//void nrerror(char error_text[]);
double poisson(double poiss);


#endif
