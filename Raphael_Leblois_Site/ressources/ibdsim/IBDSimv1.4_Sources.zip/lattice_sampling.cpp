/***************************************************************************
© R. Leblois 2005- for code collection
leblois@mnhn.fr

This file is part of IBDSim. This software is a computer program
whose purpose is to perform population genetic simulfations.

This software is governed by the CeCILL license under French law and
abiding by the rules of distribution of free software.  You can  use,
modify and/ or redistribute the software under the terms of the CeCILL
license as circulated by CEA, CNRS and INRIA at the following URL
"http://www.cecill.info".

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability.

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or
data to be ensured and,  more generally, to use and operate it in the
same conditions as regards security.

The fact that you are presently reading this means that you have had
knowledge of the CeCILL license and that you accept its terms.

 ***************************************************************************/

// 28012009 : many changes and bug corrected (allocation and free memory for cum2, unaccurrate computations of dy_min & max in Forw())
// bugs were problematic only for cases with void_node>1
// delete procedures in isoutils2.cpp were also change to delete[] after valgrind warnings, same modifications in main()
// bug fixed in allocation of the deffective[][] mattrix
// diverse new intiatilisations (problems found with valgrind)

// V1.0 -> V1.1 : 23032009
// incorporation of a specific density matrix giving the number of individuals in each lattice node
// information is read in a file named DensityMatrix.txt
// this is yet implemented only for the first generation before a potential change but not after

//V1.1->v1.2 : 24032009
//incorporation of continuous time change of deme size : linear, exponential and logistic
//16042009 : corrected bug : problem in free(tabdis) in new_disp() not conditionned on fixe_global

//31032010 : bug for void_sample_nodes>2 with a linear lattice. vide_sample replaced by vide_sampleX and vide_sampleY

//03052010 : bug with vide_sampleX and Y that did not take the vide_sample value with Specific_Sample_design=TRUE, L.2072


//for compilation under DevC++ do not include the BesselK.c file into the file to be included in compilation, the compiler will find it automatically. RL
#include "lattice_s.h"
// contains documentation and prototypes

//#define STL_DEBUG
//#define DEBUG
#ifdef DEBUG
//int maxprev=0; source de bug possible (mais trËs improbable sur nombre descendants
#endif


#include <cstdio>
#include <iostream> // cout...
#include <fstream> // ofstream
#include <sstream> //stringstream
#include <cstdlib> //needed for vector too!!
#include <cstring>
#include <cmath>
#include <vector>
#include <ctime>
#include <limits>

using namespace std;


#define GOTO


//uncomment the following line if compiling with wxDev-C++ or MinGW
//#include <windows.h> //for mkdir(), system() but also for _gotoxy
#ifdef WIN32

       #ifdef DEVCPP //user-supplied -DDEVCPP
              #include <Windows.h>
              //#define sleep Sleep
//              #include <values.h>
/*              #ifndef DBL_MIN //RL j'ai ajoutÈ ca car ca ne marchait pas avec DEVC++ et sous unix... prb dans BesselK.c DBL_MAX undeaclared
              #define DBL_MIN 4.94065645841246544e-324
              #endif
              #ifndef DBL_MAX
              #define DBL_MAX 1.79769313486231470e+308
              #endif */
       #else
            #include <sys/stat.h> //mkdir
       #endif //if not DEVCPP
#else
      #include <sys/stat.h> //mkdir
#endif

#include "MersenneTwister.h"
#include "genepop_extract.h"
#include "isoutils2.h"
#include "charfunc.h"
#include "Bessel.h"
#include "BesselK.h"

//#define NO_MODULES
#ifdef NO_MODULES
#include "charfunc.cpp"
#include "genepop_extract.cpp"
#include "isoutils2.cpp"
#include "BesselK.cpp"
#endif //NO_MODULES


#define petit 10E-10
#define t1 1
#define haut 1
#define bas 2
#define x 1
#define y 2
#define sup(value1,value2) (value1>value2 ? value1 : value2)

char spname[]="simul_pars.txt"; // initialisation de longueur suffisante
ofstream simulpars(spname,ios::out);
//ofstream ffishet;
bool simulparsWrittenBool=false;
string SettingsFilename="IbdSettings.txt";//fichiers d'entree avec valeurs des parametres
string SpecificDensityFilename="DensityMatrix.txt";//fichiers avec valeurs de densitÈs a chaque point du rÈseau


/*CONSTANTES MARQUEURS*/
int   min_allele;/*1 ou 2 si on veut que loci polymorphes*/
int	 max_allele;//nbre d'allele max pour HexpGSM
double mu,_mu;//0.0000005;
char  model_mut;/*'1'=SMM, '2'=IAM, '3'=KAM, '4'=TPM, '5'=GSM*/
int   Kmin, Kmax;/* bornes pour tailles alleliques*/
int	Kini;//si 0 automatique...sinon cette valeur
double pSMM;/*proportion de SMM sous TPM*/
double var_geom_TPM;/* variance de la loi geometrique du TPM*/
double var_geom_GSM;/* variance de la loi geometrique du GSM*/

//int atej;
//char test[50]="are";
//200 echant de 200 locus pour la simul ‡ 40000 loci
int   n_locus;//1 5 14 /* nbre de locus simules par repetition*/ /*+s pr fichiers Genepop*/
bool  genepopoui=true;/*si 1 ecrit les fichier genepop*/
bool  DG2002=false;//1... si 1 ecrit les fichiers DG2002 !! que pour 1 locus!!!!!!!!
bool  AllStates=false;//pour affichier tous les Ètats allÈliques, meme sans Èchantillons pour DG2002KAM = equivalent de AllStates dans migraine
int   repet;/*600... nbre de repetitions*/


int		Seeds;//seeds
vector < vector<int> > Spec_Sample_Coord;//stocke les coord de l'echantillon quand user defined
bool	calcul_anc=false;//lance proba_d'id_anc et pas new
bool	HexpNeioui=false;//si 1 calcul l'heterozygotie attendue de Nei (somme des produit des frequences)
bool	DeltaHoui=false;//pour calculer le deficit en heterozygote pour tester le logiciel Bottleneck
bool	Varoui=false;//si 1 calcul la variance de taille allelique
bool  	effective_disp=false;// si 1 ecrit fichier de distribution des distance de dispersion "efficaces"
bool	suiviQ=false;/*si 1 suit les Q a chaque repet pour graphe*/
bool	migrate_oui=false,migrate_lettre_oui=false;//si true ecrit les fichiers migrate, si true ecrit des lettres pour les alleles (limitÈ a 36 alleles)
bool	dossier_nbre_allele=false;//1 si dossiers spÈciale par nbre d'allÈles pour DG2002
bool	Fis_Het=false; // si 1 ecrit les fichiers Fis, Het, !!!!! calcul_oui necessaire !!!!!
bool  	calculoui=false; /*si 1 lance calculs proba d'id et temps de coa, rajoute environ 10% de temps de calcul*/
bool 	const_disp=true; // permet Èviter calcul forw ‡ chaque rep
string  twoD_disp="Simple1DProduct";
bool	total_disp=true; // si true, dispersion jusqu'a dx_max et non limitÈ par taille du reseau (ajout RL necessaire pour tester = pour comparer avec mathematica).
bool  	Prob_Id_Matrix=false; // estimation des probas d'identitÈ ‡ chaque position ÈchantillonnÈe

/*CONSTANTES DEMOGRAPHIQUES *///ATTENTION : penser a changer dimRes1G0,G1... et dimRes2G0,G1... et pas seulement dim_reseau1 et dim_reseau2

int   EdgeEffect;//types of edge effects : 0=circular,1=absorbing (disperse until a ancestor is found inside the lattice),2=reflecting,3=FRAbsorbing (disperse if first ancestor found inside the lattice, or do not disperse)
int   dim_reseau1;/* dimensions maximale (=toutes generations confondues) en x*/
int   dim_reseau2;/* 1... dimensions maximale en y*/
int   dim_sample1;/* axial nb noeuds echantillonnÈs*/
int   dim_sample2;/*1... """""""""""""""*/
int   Spec_SampleSize;//sample size for specific design
int   xmin_sample,ymin_sample;//1... coord minimales de l'Èchantillon
                          //ATTENTION si vide sample!=1 ajuster x et y min
int	dens_sample;/*10... was 30 or 20*//* nbre d'ind echantillonne par noeud*/
int	vide_sample;/*was 11 or 2*/
int	vide_sampleX;/*was 11 or 2*/
						/*1 si pas de noeuds vides
						 2,3 si il existe des noeuds vide ( 1sur 2, 1 sur 3)
						 dans l'Èchantillon*/
int	vide_sampleY;
int  xmin_zone,xmax_zone;//dÈfinition de la zone (cf ci dessous) sur x
int  ymin_zone,ymax_zone;// definition de la zone sur y

/*CARACTERISTIQUES DE DISPERSION + TAILLES ET NBRE DE POPS*/

// *9=>sig≤=4 sur 48 pas* *0=>sig≤=4 sur 15 pas* *1=>step stone m=0.666*  *2=>sig≤=1*
// *3=>sig≤=100* *4=>sig≤=1 1noeud sur 2*  *5=>sig≤=1 1noeud sur 3*/
// *6=> sig≤=20* *7=>sig≤=10*  *8=>sig≤=4 1noeud sur 3* *a=>step stone m=0.333*
// *b=> step stone m=0.01* * g=geometric mig=0.01* S=>Sichel mixture, inverse gamma mixture

//au cours de l'execution du programme, les variables suivantes prennent les valeurs ci dessous en fonction des changements temporels :
//dimRes1=dimRes1GX;dimRes2=dimRes2GX;dens=densX;zone=zoneX;vide_zone=vide_zoneX;dens_zone=dens_zoneX; mod=modX; avec X=0,1,2,3

//40 pour geo130_nd350:
int 	dens0;//20 pour samp20//1;/*4... was 200 for island*///nbre d'individus diploÔdes par noeud (non vide!)
int 	dimRes1G0; // doit etre <=  dim_reseau1
int 	dimRes2G0; //1...doit etre <=  dim_reseau2
bool 	random_translation=false;//1 si random, 0 si au milieu
bool 	fixe0=true;//=0 si il existe des noeud vides sur le reseau
int 	vide0;//1 si pas de noeuds vides 2,3 si il existe des noeuds vide ( 1sur 2, 1 sur 3)
bool 	zone0=false;//1 si il existe une zone de densitÈ diffÈrente du reste
int 	vide_zone0;//si il y a des noeuds vides dans la zone
int 	dens_zone0,DX_max0;//nbre d'individus diploÔdes par noeud dans la zone
char 	mod0; /*S ou g... Modele de dispersion *chercher cette option pour en modif les params*/
double	Mig0,GeoG0,Pareto_Shape0;
double Sichel_Gamma0,Sichel_Xi0,Sichel_Omega0;
int ContSizeChange0=0;
double LogisticGrowthRate0=0;
//
//const long int Gn1=2147483647;//le plus grand long int=2147483647
int Gn1;//si =le plus grand int=2147483647=pas de changements
int dimRes1G1;
int dimRes2G1;
bool  fixe1=true;
int  dens1;
int  vide1;
bool  zone1=false;
int  vide_zone1;
int  dens_zone1,DX_max1;
char mod1;
double Mig1, GeoG1,Pareto_Shape1;
double Sichel_Gamma1,Sichel_Xi1,Sichel_Omega1;
int ContSizeChange1=0;
double LogisticGrowthRate1=0;



 //attention  : ne marche pas quand plusieurs changement temporels avec fixe=0 :
//modifications a faire : changer de sym,disp,etc a chaque changement
//pour l'instant on ne peut considerer qu'un changement dans le temps avec fixe=0
int Gn2;
int dimRes1G2;
int dimRes2G2;
bool  fixe2=true;
int  dens2;
int  vide2;
bool  zone2=false;
int  vide_zone2;
int  dens_zone2,DX_max2;
char mod2;
double Mig2, GeoG2,Pareto_Shape2;
double Sichel_Gamma2,Sichel_Xi2,Sichel_Omega2;
int ContSizeChange2=0;
double LogisticGrowthRate2=0;

int Gn3;
int dimRes1G3;
int dimRes2G3;
bool  fixe3=true;
int  dens3;
int  vide3;
bool  zone3=false;
int  vide_zone3;
int  dens_zone3,DX_max3;
char mod3;
double Mig3, GeoG3,Pareto_Shape3;
double Sichel_Gamma3,Sichel_Xi3,Sichel_Omega3;

/*variables globales*/
double Hexp_GSMs100[155]={0.00000000,0.00000000,0.19149255,0.34028941,0.46678172,0.56743466,0.64368663,0.69987672,0.74241582,0.77549535,
0.80070707,0.82224988,0.83940492,0.85369846,0.86608793,0.87623859,0.88527461,0.89303530,0.89994320,0.90606415,
0.91158018,0.91626543,0.92065599,0.92465557,0.92805518,0.93124045,0.93432545,0.93700485,0.93956555,0.94196583,
0.94412433,0.94613763,0.94806428,0.94987692,0.95136958,0.95304185,0.95446937,0.95579344,0.95714082,0.95825146,
0.95947760,0.96055465,0.96167040,0.96262956,0.96359032,0.96455177,0.96531625,0.96613980,0.96711370,0.96779654,
0.96843296,0.96911619,0.96977584,0.97043175,0.97107251,0.97162576,0.97219564,0.97277530,0.97327106,0.97379882,
0.97429360,0.97477233,0.97523296,0.97565571,0.97609682,0.97653392,0.97692181,0.97732312,0.97772187,0.97807068,
0.97843922,0.97876906,0.97911917,0.97944844,0.97979235,0.98007672,0.98038837,.98069973,0.98096754,0.98125839,
0.98154127,0.98176691,0.98208152,0.98231417,0.98256286,0.98281302,0.98303982,0.98326427,0.98349047,0.98373072,
0.98395383,0.98412205,0.98431176,0.98453663,0.98476496,0.98495450,0.98514464,0.98533484,0.98550484,0.98571439,
0.98585977,0.98606018,0.98622117,0.98636781,0.98653165,0.98669666,0.98686333,0.98700487,0.98717398,0.98729641,
0.98747136,0.98759653,0.98774493,0.98786251,0.98800758,0.98814924,0.98828825,0.98840539,0.98855534,0.98867229,
0.98880873,0.98891466,0.98903334,0.98915491,0.98927330,0.98937655,0.98949944,0.98961634,0.98971716,0.98984463,
0.98991543,0.99004974,0.99015223,0.99025791,0.99036800,0.99044519,0.99056254,0.99066993,0.99076498,0.99080417,
0.99098084,0.99102149,0.99117637,0.99120068,0.99131017,0.99134583,0.99134828,0.99157812,0.98772143,0.99172778,
0.99183182,0.99179000,0.99193333,0.99205000,0.99215000};
double Hexp_GSMs30[61]={0.00000000,0.00000000,0.22830195,0.40138901,0.52696065,0.6211678,0.6918355,0.73754651,0.77559422,0.80411304,
0.82764967,0.84540352,0.85957917,0.87327738,0.88373603,0.89269392,0.90120951,0.90781574,0.91287772,0.91842095,
0.92357622,0.92789402,0.93142196,0.93531951,0.93835109,0.94167386,0.94430822,0.94655735,0.94886433,0.95092748,
0.95290439,0.95495305,0.95655019,0.9582709,0.95985712,0.96143896,0.9629032,0.96422282,0.96546751,0.96675947,
0.9678547,0.96895461,0.97005926,0.97109945,0.97195721,0.9728708,0.97377368,0.97457602,0.97540988,0.97618186,
0.97695963,0.97767515,0.9783862,0.97907978,0.97974441,0.98034314,0.98102694,0.98160494,0.98222222,0.98277778};
FILE      *fgenepop,*fmoyenne,*fsuivi,*fmigrate,*fDG2002,*fdisp,*fdisp_moy/*,*ffishet*/;/* pour fichier genepop,moyennes,...*/
bool variable_mubool=false,txt_extensionbool=false,Specific_Sample_Designbool=false,Specific_Density_Designbool=false,diploidebool=true;
int ploidy;// 1 pour haploides 2 pour diploides
MTRand alea;
int n_genes;/* nbre de genes de l'echant*/
int grande_dim;//dim du plus grand cotÈ de la pop
int dimRes1,dimRes2;//dimensions du reseau variables pour reduction de la surface
int translationx=0,translationy=0;//facteur de translation au moment de l'augmentation de surface
               //pour ne pas tjs mettre l'echantillon dans un coin de la pop
char fichier_migrate[50],fichier_genepop[50],fichier_stepsim[50],comments[50];
int locus,rep;

int nbre_noeud_restant;
int nbre_noeud_existant;
int no_noeud_coalesce;
int n_mut,compte_mut;
double mut_moy_glob,mut_moy_glob_var;
int nbre_allele_loc,*nbre_allele;
int *allele_max,*allele_min;
float nbre_allele_moy;
char model_mig;
double Sichel_Gamma,Sichel_Xi,Sichel_Omega,Pareto_Shape,migra0;
int ContSizeChange=0,growthStart=0,startingSize;
double LogisticGrowthRate;
double growthRate=0,KLogistic=0,P0Logistic=0;
int fixe,fixe_global;/*0/1 si densite fixe en tout point du reseau*/
int dens;/*nbre d'ind diploides par noeud*/
int	vide;/*si il y a des noeuds vides sur le reseau quand fixe=0*/
int sym;//si il y a des vides -> symetries 2,3,10...
bool zone=false;//1 si il y a une zone de densitÈ diffÈrente du reste
int dens_zone;//densitÈ dans la zone
int vide_zone;
int DX_max,dx_min,dx_max,dy_min,dy_max,dispxx,dispyy,dx,dy  // dy_min,dy_max FER
			  ,deja /*0/1 si tab migra deja rempli*/
			  ,deja1/*0/1 si cumul deja fait*/,deja3;
long double     Mig,GeoG,sig,kurt,checksum;
long double     *migra,*cum_fixex,*cum_fixey;
int 	   **densite;
long long int        **effective/*[60][3]*/,**effective_moy/*[60][3]*/,cum_moyx,cum_moyy;//tab des distances de dispersion "efficaces" : compteur,moy sur repets
//long long MAx=9223372036854775807
double     **deffective/*[60][3]*/;//tab des distances de dispersion "efficaces" : frÈquences
long long int   **effectiveImmigration,**cumulEffectiveImmigration,**effectiveImmigration_moy,**cumulEffectiveImmigration_moy;
double	   **deffectiveImmigration;
double     moy_dispx,sig_dispx,kurto_dispx,skew_dispx;//stat sur ditrib disp efficace en x
double     moy_dispy,sig_dispy,kurto_dispy,skew_dispy;//stat sur ditrib disp efficace en y
double     moy_demidispx,sig_demidispx,kurto_demidispx,skew_demidispx;//stat sur demi ditrib disp efficace en x
double     moy_demidispy,sig_demidispy,kurto_demidispy,skew_demidispy;//stat sur demi ditrib disp efficace en y
double     denom;
long double     norm;
long double* Sicheltable;
int  mrca_max,*mrca/*[501]*/;
double mrca_moy,mrca_moy_glob;
unsigned long int currentGeneration;
#ifdef STL_DEBUG
vector<vector<int> > coord_individus;
vector<vector<int> >coord_noeud,coord_ori;
vector<int>no_noeud_restant,aleat_noeud;
#else
int 	  **coord_individus/*[1601][3]*/;//tableau des coord dans l'echantillon
int 		**coord_noeud,**coord_ori;
int 		*no_noeud_restant,*aleat_noeud;
#endif
//int 	  **coord_noeud/*[1601][3]*/;//tableau des coord des noeuds pdt la construction de l'arbre
//int	  	  **coord_ori/*[1601][3]*/;//a virer?
int       coord_origine[4];
//int   	  *aleat_noeud/*[1601]*/;
//int   	  *no_noeud_restant/*[1601]*/;
int       **nom_alleles_locusi/*[501][1001]*/;// a mettre en pointeur


int       pas;
//long int  temps_coa;
int  temps_coa;
double    temps_coa_moy,coa_moy_glob;
vector< vector < vector < vector<double> > > > QMatrix_Moy_Glob,QMatrix_Moy;//moyenne globale sur les repets, moyenne sur tous les locus pour une repet
vector< vector< vector< vector< vector<double> > > > > QMatrix;//par locus pour une repet

//long int  compteur3;
int  compteur3;
double	  **Q1/*[501][60]*/,*Q1_moy/*[60]*/, *Qind2/*[501]*/, Qind_moy,*Q1_moy_glob/*[60]*/,Qind_moy_glob;
double	  *hetero/*[501]*/,*fis/*[501]*/,hetero_moy,fis_moy_glob,hetero_moy_glob,
           fis_moy,fis_moy2,Qpop_moy_glob, Qpop_moy,
           fis_moy_denom,fis_moy_numer,fis_moy_denom_glob,fis_moy_numer_glob;
double    *HexpNei,HexpNei_moy, HexpNei_moy_glob,HexpNei_moy_glob_var;
double	  *DeltaH,DeltaH_moy,DeltaH_moy_glob,DeltaH_moy_glob_var;
double    *Var,Var_moy,Var_moy_glob,Var_moy_glob_var;
double	  *M,M_moy,M_moy_glob,M_moy_glob_var;
double    **freq;//pour calcul de HexpNei
//vector<vector<double> >freq;
double	  Hexp,Vexp;//attendu theoriques pour l'heterozygotie et la vriance de taille allÈlique !! que pour certain mod mut
int 	  mono2;/*compteur pour proportion de locus monomorphes*/
double	  mono;/*proportion de locus monomorphes*/
struct    node{int descendant[10];
//					long int generation;
					int generation;
					int etat_allele;
					char etat_allele_lettre;//pour migrate
					int ancetre;
					int nbre_descendant;
				  };
struct    node **noeud;//[1601][501]
//vector <vector<node> > noeud;
struct    disdis{
    //double cum2[100][100]; /*
#ifdef DEBUG
	vector<vector<double> > cum2;
#else
	double** cum2;
#endif
};
struct    disdis **tabdis/*[3][3]/*[60][60]*/;



/*****************************************************************************/
/**********************programme principal ***********************************/
int main(int argc, char *argv[])
{int noeudi,noeudj,noeudk,i_ini,KminIni,KmaxIni,Min,Max;
clock_t start, end;
double temps_ecoule = 0.0;

#ifdef GOTO
effacer_ecran();
#endif

/*cout<<numeric_limits<int>::max()<<endl;
cout<<numeric_limits<long int>::max()<<endl;
cout<<numeric_limits<long long int>::max()<<endl;*/

if (argc>1) {
    	string buf(argv[1]);
    	string::size_type pos=std::min(buf.find('='),std::min(buf.find('\t'),buf.length()));
    	string var=buf.substr(0,pos).c_str();
    	if(cmp_nocase(var,"SettingsFile")==0) SettingsFilename=buf.substr(pos+1);
    } else SettingsFilename="IbdSettings.txt";
read_settings_file(SettingsFilename.c_str());
#ifdef GOTO
	effacer_ecran();
#endif
affichage_ecran();
fflush(stdin);
fflush(stdout);

start=clock();
alea.seed(Seeds);
if(Specific_Sample_Designbool) n_genes=ploidy*dens_sample*Spec_SampleSize;
    else n_genes=ploidy*dens_sample*dim_sample1*dim_sample2;
grande_dim=sup(dim_reseau1,dim_reseau2);
KminIni=Kmin;KmaxIni=Kmax;

/*-----Allocation pointeurs utilises pour moyennes tout le long des repetitions---------*/
if(!Specific_Sample_Designbool) Q1_moy_glob=dvector(sup(dimRes1G0,sup(dim_sample1,dim_sample2))+2);/*moy inter individus a i pas*/
densite=imatrix(dim_reseau1+2,dim_reseau2+2);
//migra=dvector(100); //FER 24/09/2005 : highly suspect, moved to
if(effective_disp) {
    effective_moy=llimatrix(2*grande_dim+2,4);//tab des occurences de dispersion pour distribution de disp efficace
	deffective=dmatrix(2*grande_dim+2,4);//tab des frÈquences pour distribution de disp efficace
	effectiveImmigration_moy=llimatrix(dim_reseau1+1,dim_reseau2+1);//tab des occurences d'immigration efficaces
	cumulEffectiveImmigration_moy=llimatrix(dim_reseau1+1,dim_reseau2+1);//tab des occurences d'immigration efficaces
	deffectiveImmigration=dmatrix(dim_reseau1+1,dim_reseau2+1);
}
/*---------------------------------------------------------------------------*/
/*----dimensionnement des vecteurs utilisÈs tout le long des repetitions-----*/
if(Prob_Id_Matrix && !Specific_Sample_Designbool) {
	QMatrix_Moy_Glob.resize(dim_sample1);
	for(int i=0;i<dim_sample1;i++) {
		QMatrix_Moy_Glob[i].resize(dim_sample2);
		for(int j=0;j<dim_sample2;j++) {
			QMatrix_Moy_Glob[i][j].resize(dim_sample1);
			for(int i2=0;i2<dim_sample1;i2++)
				QMatrix_Moy_Glob[i][j][i2].resize(dim_sample2,0.0);
		}
	}
}
/*---------------------------------------------------------------------------*/

ini_moy_glob();//initialisation pour moyennes sur repets

/*---initialisation de structure **noeud et **tabdis---------*/
//noeud=(struct node **) malloc((unsigned) (2*n_genes+2)*sizeof(struct node*));
noeud=new node*[2*n_genes+2];
//noeud.resize(2*n_genes+2);
if (!noeud) nrerror("allocation failure 1 in structure node()");
for (int i=0; i<=2*n_genes+1; i++)
  {//noeud[i].resize(n_locus+2);
//  noeud[i]=(struct node *) malloc((unsigned) (n_locus+2)*sizeof(struct node));
  noeud[i]=new node[n_locus+2];
  if (!noeud[i]) nrerror("allocation failure 2 in structure node()");
  }

if(fixe_global==0) {
    //tabdis=(struct disdis **) malloc((unsigned) (sym+2)*sizeof(struct disdis*));
	tabdis=new disdis*[sym+2];
    if (!tabdis) nrerror("allocation failure 1 in structure disdis()");
    for (int i=0; i<=sym+1; i++) {//tabdis[i]=(struct disdis *) malloc((unsigned) (sym+2)*sizeof(struct disdis));
     tabdis[i]=new disdis[sym+2];
      if (!tabdis[i]) {printf("boucle %d",i);
	   nrerror("allocation failure 2 in structure disdis()");
	   getchar();
	  }
     }//for i
  }// if fixe
/*---fin initialisation de **noeud et **tabdis-------*/
// les tableaux cum seront redimensionnÈs par new_disdis appelÈ dans forw
#ifdef GOTO
_gotoxy(0,13);
#endif
cout<<"Dataset:          Locus:";//"\n nbre_noeud_restant"<<ends;
fflush(stdout);//marche pas bien
fflush(stdin);

// BOUCLE PRINCIPALE
for(rep=1;rep<=repet;rep++) {/*debut boucle sur repetition*/
#ifdef GOTO
	_gotoxy(8,13);
#endif
cout << rep << "   ";
fflush(stdout);//marche pas bien
fflush(stdin);


//pout initialisations quand IAM
Kmin=KminIni;
Kmax=KmaxIni;


/*------pointeurs utilises pdt une boucle de repetition---*/
nom_alleles_locusi=imatrix(n_locus+2,Kmax+2);/*nbre et nom des alleles a chaque locus*/
if(effective_disp) {
	effective=llimatrix(2*grande_dim+2,4);//tab pour distribution de dispersion efficace
	effectiveImmigration=llimatrix(dim_reseau1+1,dim_reseau2+1);//tab des taux d'immigration efficaces par demes
	cumulEffectiveImmigration=llimatrix(dim_reseau1+1,dim_reseau2+1);//tab des taux d'immigration efficaces par demes

}
nbre_allele=ivector(n_locus+2);//tableau du nbre d'allele pour chaque locus
allele_max=ivector(n_locus+2);//pour range de taille
allele_min=ivector(n_locus+2);//pour range de taille
hetero=dvector(n_locus+2);
HexpNei=dvector(n_locus+2);//vecteur des Heterozygoties de Nei
DeltaH=dvector(n_locus+2);//vecteur des DeltaH / Hexp_alleleGSM
Var=dvector(n_locus+2);//vecteur des variances de tailles allelqies par locus
M=dvector(n_locus+2);
//freq=dmatrix(n_locus+20,Kmax+10);//matrice des frequence alleleliques de l'echantillon
freq=dmatrix(n_locus+1,Kmax+1);//matrice des frequence alleleliques de l'echantillon
//freq.resize(n_locus+20)
//for (vector<vector<double> >::iterator ii=freq.begin();ii<freq.end();ii++) (*ii).resize(Kmax+10);
fis=dvector(n_locus+2);
Qind2=dvector(n_locus+2);
if(!Specific_Sample_Designbool) Q1=dmatrix(n_locus+2,sup(dimRes1G0,sup(dim_sample1,dim_sample2))+2);/*proba d'identite inter individus*/
if(!Specific_Sample_Designbool) Q1_moy=dvector(sup(dimRes1G0,sup(dim_sample1,dim_sample2))+2);/*moyenne inter individus a i pas de distance*/
mrca=ivector(n_locus+2);/*age mrca de tous les individus pour chaque locus*/
#ifdef STL_DEBUG
coord_individus.resize(2*n_genes+2);
for (vector<int>::iterator ii=coord_individus.begin();ii<coord_individus.end();ii++) (*ii).resize(4);
#else
coord_individus=imatrix(2*n_genes+2,4);/*coordonnees des individus de l'echantillon de depart*/
#endif
/*------------------------------------------*/

/*-----dimensionnement des vecteurs utilisÈ pdt une repetition-------*/
if(Prob_Id_Matrix && !Specific_Sample_Designbool) {
	QMatrix.resize(0);
	QMatrix.resize(n_locus);
	for(int l=0;l<n_locus;l++) {
		QMatrix[l].resize(dim_sample1);
		for(int i=0;i<dim_sample1;i++) {
			QMatrix[l][i].resize(dim_sample2);
			for(int j=0;j<dim_sample2;j++) {
				QMatrix[l][i][j].resize(dim_sample1);
				for(int i2=0;i2<dim_sample1;i2++)
					QMatrix[l][i][j][i2].resize(dim_sample2,0.0);
			}
		}
	}
	QMatrix_Moy.resize(0);//pour reinitialiser a chaque fois
	QMatrix_Moy.resize(dim_sample1);
	for(int i=0;i<dim_sample1;i++) {
		QMatrix_Moy[i].resize(dim_sample2);
		for(int j=0;j<dim_sample2;j++) {
			QMatrix_Moy[i][j].resize(dim_sample1);
			for(int i2=0;i2<dim_sample1;i2++)
				QMatrix_Moy[i][j][i2].resize(dim_sample2,0.0);
		}
	}
}
/*-------------------------------------------------------------------*/



ini_struct_noeud();
/*for(i=1;i<=n_locus;i++)
{for(j=1;j<=2*n_genes;j++)
  {printf("1noeud: %d;\n generation: %ld;\n etat allele: %d;ancetre: %d;
			  nbre de descendants: %d;\n"
			  ,j, noeud[j][i].generation,noeud[j][i].etat_allele,
			  noeud[j][i].ancetre,noeud[j][i].nbre_descendant);
  getchar();
  }
}
clrscr();*/

ini_moy();/*initialisations pour calculs moyennes sur locus*/

if( ! simulparsWrittenBool) {
	simulpars<<"nbr of samples/files simulated: "<<repet<<endl;
	simulpars<<"generic data file name: "<<fichier_genepop<<endl;
    if (EdgeEffect==0) simulpars<<"Closed (circular or toroidal) lattice"<<endl;
	if (EdgeEffect==1) simulpars<<"Lattice with absorbing boundaries (unreachable dispersal probability mass reported on the whole dispersal distribution including P(dx=0)=(1-mig))"<<endl;
	if (EdgeEffect==2) simulpars<<"Lattice with reflecting boundaries"<<endl;
	if (EdgeEffect==3) simulpars<<"Lattice with absorbing boundaries (unreachable dispersal probability mass reported on the non-immigration term P(dx=0)=(1-mig))"<<endl;
	simulpars<<"At G=0 (sampling time ==  present) : "<<endl;
	simulpars<<"lattice dimensions are (dim_reseau1 X dim_reseau2): "<<dim_reseau1<<" x "<<dim_reseau2<<endl;
	if(vide0!=1)  simulpars<<"with "<< (vide0-1) << " nodes over " <<vide0<< " being empty, so that real gene density is : "<< ((double) 2.0*dens0/vide0)<<endl;
	if(diploidebool) simulpars<<"Diploid individuals : nbr of genes per non empty lattice node (2 * dens0): "<<2*dens0<<endl;
	 else simulpars<<"Haploid individuals : nbr of genes per lattice node (1* dens0): "<<dens0<<endl;
	simulpars<<"nbr of loci per sample file (n_locus): "<<n_locus<<endl;
	if(!Specific_Sample_Designbool) simulpars<<"nbr of sampled nodes (dim_sample1 X dim_sample2): "<<dim_sample1<<" x "<<dim_sample2<<endl;
	   else simulpars<<"nbr of sampled nodes (Spec_SampleSize): "<<Spec_SampleSize << ";" << endl;
	simulpars<<"Unsampled nodes between sampled nodes (void_sample_node-1): "<<vide_sample-1<<endl;
	simulpars<<"# nbr of sampled individuals per sampled node (dens_sample): "<<dens_sample<<endl;
	simulpars<<"x/y coordinate of \"first\" sampled node (xmin_sample/ymin_sample): "<<xmin_sample << "/" << ymin_sample<<endl<<endl;
	if (model_mut=='1') simulpars<<"Mutation model: SMM("<<Kmax-Kmin+1<<" alleles)"<<endl;
	if (model_mut=='2') simulpars<<"Mutation model: IAM"<<endl;
	if (model_mut=='3') simulpars<<"Mutation model: KAM ("<<Kmax-Kmin+1<<" alleles)"<<endl;
	if (model_mut=='4') simulpars<<"Mutation model: TPM("<<Kmax-Kmin+1<<" alleles)"<<endl;
	if (model_mut=='5') simulpars<<"Mutation model: GSM("<<Kmax-Kmin+1<<" alleles)"<<endl;
	if(variable_mubool) simulpars<<"Mutation rate is variable among loci : distribution is gamma with mean "<< _mu<<"\n"<<endl;
	 else simulpars<<"Mutation rate is constant for all loci (mu): "<<_mu<<endl<<endl;
	simulpars<<"Dispersal model: "<<mod0<<endl;
}

//cout<<"ola\n"<<flush;

for(locus=1;locus<=n_locus;)/*boucle sur locus*/ {

 	/*----pointeurs utilisÈ pdt une boucle sur un locus---*/
	//cout<<"huma"<<flush;
	//coord_noeud.resize(2*n_genes+2);
	//for (vector<vector<int> >::iterator ii=coord_noeud.begin();ii<coord_noeud.end();ii++) ii->resize(4);
	coord_noeud=imatrix(2*n_genes+2,4);/*position geographique des noeuds*/
	//int **coord_noeud=new int*[2*n_genes+2];
	//for (int ii=0;ii<2*n_genes+2;ii++) coord_noeud[ii]=new int[4];
	//cout<<"humb"<<flush;
	//coord_ori.resize(2*n_genes+2);
	//for (vector<vector<int> >::iterator ii=coord_ori.begin();ii<coord_ori.end();ii++) ii->resize(4);
    coord_ori=imatrix(2*n_genes+2,4);/* position des lignees ancestrales*/
	//cout<<"humc"<<flush;
	//aleat_noeud.resize(2*n_genes+2);
    aleat_noeud=ivector(2*n_genes+2);/*identifie "les deux genes d'un individu"*/
	//cout<<"humd"<<flush;
	//no_noeud_restant.resize(n_genes+2);
    no_noeud_restant=ivector(n_genes+2);/*numero noeuds pas encore coalesces*/
	//cout<<"hume"<<flush;
 	/*-------------------------------------------------*/

 	//cout<<"\nlocus"<<locus<<endl<<flush;
	//getchar();
	//gotoxy(17,16);
 	/*printf("locus: %d ;",locus);*/
	if(n_locus<100) {
#ifdef GOTO
		_gotoxy(25,13);
#endif
		cout<<locus<<"   ";
		fflush(stdout);
		fflush(stdin);
	}
    currentGeneration=0;/*initialisation du nbre de generations*/
	//ini_tableaux_spe_FR_migrate();
    if(Specific_Sample_Designbool) ini_tableaux_specifique();
    	else ini_tableaux();/*initialise tableaux utilises pendant boucle sur locus*/
    nbre_noeud_existant=n_genes;/*nbre de noeud total existant a Gn=0*/
    nbre_noeud_restant=n_genes;/*nbre de noeuds n'ayant pas coalesce a GN=0*/

    {//int anterieur=n_genes; // pour afficher la rÈduction progressive de l'arbre ancestral (rep==1)
         while (nbre_noeud_restant>1){ //boucle ppale pour chaque locus
 	           	//if (rep<3 && nbre_noeud_restant<anterieur-99) {
               	//  _gotoxy(20,20);
               	//  cout<<nbre_noeud_restant<<"   "<<flush;

				// cout<<" "<<nbre_noeud_restant<<" "<<n_mut<<" "<<compte_mut<<flush;
                // anterieur=nbre_noeud_restant;
 	           	//} //if
				//cout<<"\nola1";

 			/*creation arbre de coalescence*/
  	          	currentGeneration++;/*incremente le numero de la generation*/
				//if((fmod(currentGeneration,10))==0.0) {
                //if(currentGeneration==Gn1) {
				//	printf("\ngeneration: %ld; ",currentGeneration);
				//	cout<<"dens="<<dens<<flush;
				//	cout<<"noeuds restants="<<nbre_noeud_restant<<flush;
				//	getchar();
                //}
                new_disp();  //appelle forw()=choix de la disp et fait la dispersion des noeuds restants
                if(ContSizeChange) ComputeDemeSize();
  	            nbre_aleat_noeud();/*identifie les deux genes de chaque individus pour coalescence*/
                i_ini=2;
 				boucle1:
  				//processus de coalescence
                for(noeudi=i_ini;noeudi<=nbre_noeud_restant;noeudi++) {/*comparaison noeuds 2 a 2*/
                   if (nbre_noeud_restant>1) {
                      for(noeudj=1;noeudj<noeudi;noeudj++) {
                         if((coord_noeud[no_noeud_restant[noeudi]][x]==coord_noeud[no_noeud_restant[noeudj]][x])//regarde tout d'abord s'ils sont danns le meme deme
	&&(coord_noeud[no_noeud_restant[noeudi]][y]==coord_noeud[no_noeud_restant[noeudj]][y])
	&&(aleat_noeud[no_noeud_restant[noeudi]]==aleat_noeud[no_noeud_restant[noeudj]])
                           ) {//puis regarde s'ils ont le meme gene ancetreal
                              if (noeud[no_noeud_restant[noeudi]][locus].generation!=currentGeneration)/*coa non multiples*/ {
                                 no_noeud_coalesce=nbre_noeud_existant+1;
                                 nbre_noeud_existant++;
                                 aleat_noeud[no_noeud_coalesce]=aleat_noeud[no_noeud_restant[noeudj]];
                                 coord_noeud[no_noeud_coalesce][x]=coord_noeud[no_noeud_restant[noeudj]][x];
                                 coord_noeud[no_noeud_coalesce][y]=coord_noeud[no_noeud_restant[noeudj]][y];
                                 noeud[no_noeud_coalesce][locus].generation=currentGeneration;
                                 noeud[no_noeud_restant[noeudi]][locus].ancetre=no_noeud_coalesce;
                                 noeud[no_noeud_restant[noeudj]][locus].ancetre=no_noeud_coalesce;
                                 noeud[no_noeud_coalesce][locus].nbre_descendant++;
#ifdef DEBUG
								// if (noeud[no_noeud_coalesce][locus].nbre_descendant++>maxprev)
								//  	{maxprev=noeud[no_noeud_coalesce][locus].nbre_descendant++; cout<<"!!"<<maxprev<<"!!"<<flush;}
#endif
                                 noeud[no_noeud_coalesce][locus].descendant[noeud[no_noeud_coalesce][locus]
	  								.nbre_descendant]=no_noeud_restant[noeudi];
                                 noeud[no_noeud_coalesce][locus].nbre_descendant++;
                                 noeud[no_noeud_coalesce][locus].descendant[noeud[no_noeud_coalesce][locus]
	  								.nbre_descendant]=no_noeud_restant[noeudj];
                                 for(noeudk=noeudj;noeudk<nbre_noeud_restant;noeudk++)
                                 	no_noeud_restant[noeudk]=no_noeud_restant[noeudk+1];/*enleve le noeud j des noeud restants*/
                                 no_noeud_restant[nbre_noeud_restant]=no_noeud_coalesce;
                                 for(noeudk=noeudi-1;noeudk<nbre_noeud_restant;noeudk++)
                                 	no_noeud_restant[noeudk]=no_noeud_restant[noeudk+1];/*enleve le noeud i des noeud restants*/
                                 no_noeud_restant[nbre_noeud_restant]=0;
                                 nbre_noeud_restant--;
                               	 i_ini=noeudi-1;
 								 goto boucle1;
                              }/*fin coalescence non multiple*/
                              else {/* pour coalescences multiples*/
                                 no_noeud_coalesce=no_noeud_restant[noeudi];
                                 noeud[no_noeud_coalesce][locus].nbre_descendant++;
                                 noeud[no_noeud_coalesce][locus].descendant[noeud[no_noeud_coalesce][locus].nbre_descendant]=no_noeud_restant[noeudj];
                                 noeud[no_noeud_restant[noeudj]][locus].ancetre=no_noeud_coalesce;
                                 for(noeudk=noeudj;noeudk<=nbre_noeud_restant;noeudk++)
                                    no_noeud_restant[noeudk]=no_noeud_restant[noeudk+1];
                                 nbre_noeud_restant--;
                                 i_ini=noeudi;
 								 goto boucle1;
                              }/*fin coalescence multiple*/
                         }/*fin if coalescence possible*/
                      }/*fin boucle sur noeudj*/
                   }/*fin if sur noeud restant*/
                }/*fin boucle sur noeudi=fin comparaison noeuds 2 a 2*/
        }/*fin while: creation arbre de coalescence*/
        //if (rep==1) cout<<endl;
    } //bloc int anterieur
//cout<<"fini\n"<<flush;


//verif
//printf("\nn_genes= %d  ;2*n_genes= %d   ;\n",n_genes,2*n_genes);
//for(atej=1;atej<=2*n_genes;atej++){
//   printf("\nancetre de %d= %d",atej,noeud[atej][locus].ancetre);
//   getchar();
//   }

	if(variable_mubool) mu=gamma_mut(_mu/2); else mu=_mu;//taux de mutation variable ou fixe

    mono2+=1;
    switch(model_mut) {//donne les etats alleliques de l'Èchantillon
       case'1':
       compter_alleles_SMM();
       break;
       case'2':
       compter_alleles_IAM();
       break;
       case'3':
       compter_alleles_KAM();
       break;
       case'4':
       compter_alleles_TPM();
       break;
       case'5':
       compter_alleles_GSM();
       break;
    } //fin switch

    if(nbre_allele_loc>=min_allele) {
//cout<<"if sup"<<flush;
        mrca[locus]=currentGeneration;
        mrca_moy+=currentGeneration/n_locus;
        if(calculoui && diploidebool) calcul_coa_individuel();//calcul temps de coa intra-individus
        if(mrca[locus]>mrca_max) mrca_max=mrca[locus];
        locus++;
    } else {
        mono +=1;
//cout<<"else"<<flush;
        ini_struct_noeud2();
    }

/*------liberation des pointeurs utilisÈs pdt boucle sur locus-----*/
//cout<<"hum1"<<flush;
    free_imatrix(coord_noeud,2*n_genes+2);
//for (int ii=0;ii<2*n_genes+2;ii++) delete(coord_noeud[ii]);delete(coord_noeud);

//cout<<"hum2"<<flush;
    free_imatrix(coord_ori,2*n_genes+2);
//cout<<"hum3"<<flush;
    free_ivector(aleat_noeud);
//cout<<"hum4"<<flush;
    free_ivector(no_noeud_restant);
//cout<<"hum5"<<flush;
/*-----------------------------------------------*/

}/*fin boucle locus*/
//cout<<"fin boucle locus\n"<<flush;

if(fixe_global==0 && !const_disp) {//allouÈ dans disdis qui n'est appelÈ qu'une fois a la premiere repet et au premier locus
  //for(i=sym+1; i>=0; i--) free((tabdis[i]));
   //free((tabdis));
	   for(int i=sym+1; i>=0; i--) {
		  for(int j=sym+1; j>=0; j--) {
#ifdef DEBUG
#else
            //cout << "free memory for tabids[" << i << "][" << j << "]." << endl;

            for(int k=2*dx_max+1; k>=0; k--) {
                //cout << "and cum2[" << k << "]" << endl;
                delete[] (tabdis[i][j].cum2[k]);
            }
            //cout << "free cum2" << endl;
            //getchar();
			delete[] (tabdis[i][j].cum2);
#endif
          }
		//delete[] tabdis[i];//libÈrÈ a la fin des repets
       }
	//delete[] tabdis;//libÈrÈ a la fin des repets

}



if(model_mut=='2') {
//cout<<"if(model_mut=='2'):"<<flush;
	Min=2147483647;
	Max=0;
	for(int j=1;j<=n_locus;j++) for(int i=1;i<=n_genes;i++){
		if(noeud[i][j].etat_allele>Max) Max=noeud[i][j].etat_allele;
		if(noeud[i][j].etat_allele<Min) Min=noeud[i][j].etat_allele;
	}
	Kmax=Max;
	Kmin=Min;
}


//file_tester(2);

//calcul la distribution de dispersion "efficace"
if(effective_disp) {calcul_stat_disp();ecriture_disp();}

//fait divers calculs
if(calculoui) {//cout<<"if(calculoui):"<<flush;
    if(!Specific_Sample_Designbool) calcul_proba_identite();/*file_tester(21);*/
        else if(rep==repet) cout << "\n\n!! Calcul_Proba_Id can not be run with a specific sample design !!" << endl;
    //cout<<":apres calcul_proba_identite()"<<flush;
    //file_tester(3);

    if(Fis_Het) {
        if(!Specific_Sample_Designbool) {
            //cout<<"if(Fis_Het):"<<flush;
            //file_tester(4);
            calcul_hetero_fis();
            //cout<<":apres calcul_hetero_fis()"<<flush;
            ecriture_fichier_Fis_Het();
                //ecriture_fichier_Fis_Het_cpp(); //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! bizarre ce truc RL???
        //cout<<":apres ecriture_fichier_Fis_Het()"<<flush;
        } else if(rep==repet) cout << "\n!! Iterative_Statistics=true can not be run with a specific sample design, and will be ignored !!" << endl;
    }
    mrca_moy_glob+=mrca_moy/repet;
    ecriture_fichier_moyennes();
    //cout<<":apres ecriture_fichier_moyennes()"<<flush;
}//en if(calculoui)


//calcul de la matrice des probabilitÈ d'identitÈ pour toutes les paires de coordonnÈes ÈchantillonnÈes
//indÈpendant des calculs de proba d'identitÈ par pas.
if (Prob_Id_Matrix) {
	if(!Specific_Sample_Designbool) calcul_proba_identite_matrice();
	 else {
   		if(rep==repet) cout << "\n!! Prob_Id_Matrix can not be run with a specific sample design !!" << endl;
   	 }
	//cout << ":apres calcul_proba_identitÈ_matrix()" << flush;
}

if(genepopoui) {//cout<<"ecriture_fichier:"<<flush;
					ecriture_fichier();}
if(migrate_oui) {//cout<<"ecriture_fichier_migrate:"<<flush;
					ecriture_fichier_migrate();}
if(DG2002) {//cout<<"ecriture_fichier_DG2002:"<<flush;
				if(model_mut=='2' || model_mut=='3') ecriture_fichiers_DG2002KAM(); else ecriture_fichiers_DG2002SMM();}


/*-----liberation des pointeurs utilises pdt une boucle de repetition---*/
//free_livectorl(mrca);
free_ivector(mrca);
#ifdef STL_DEBUG
#else
free_imatrix(coord_individus,2*n_genes+2);
#endif
if(!Specific_Sample_Designbool) free_dmatrix(Q1,n_locus+2);
if(!Specific_Sample_Designbool) free_dvector(Q1_moy);
free_dvector(Qind2);
free_dvector(hetero);
free_dvector(HexpNei);
free_dvector(DeltaH);
free_dvector(Var);
free_dvector(M);
//free_dmatrix(freq,n_locus+20);
free_dmatrix(freq,n_locus+1);
free_dvector(fis);
free_ivector(allele_max);
free_ivector(allele_min);
free_ivector(nbre_allele);
if(effective_disp) {
	free_llimatrix(effective,2*grande_dim+2);
	free_llimatrix(effectiveImmigration,dim_reseau1+1);
	free_llimatrix(cumulEffectiveImmigration,dim_reseau1+1);
}
free_imatrix(nom_alleles_locusi,n_locus+2);
/*------------------------------------------------------*/




}/*fin boucle repetition*/

if(fixe_global==0 && const_disp) {//allouÈ dans disdis qui n'est appelÈ qu'une fois a la premiere repet et au premier locus
  //for(i=sym+1; i>=0; i--) free((tabdis[i]));
   //free((tabdis));
	   for(int i=sym+1; i>=0; i--) {
		  for(int j=sym+1; j>=0; j--) {
#ifdef DEBUG
#else
            //cout << "free memory for tabids[" << i << "][" << j << "]." << endl;

            for(int k=2*dx_max+1; k>=0; k--) {
                //cout << "and cum2[" << k << "]" << endl;
                delete[] (tabdis[i][j].cum2[k]);
            }
            //cout << "free cum2" << endl;
            //getchar();
			delete[] (tabdis[i][j].cum2);
#endif
          }
		//delete[] tabdis[i];//libÈrÈ a la fin des repets
       }
	//delete[] tabdis;//libÈrÈ a la fin des repets

}

if(effective_disp) {calcul_stat_disp_moy();ecriture_disp_moy();}
if(Prob_Id_Matrix) if(!Specific_Sample_Designbool) ecriture_matrice_proba_id();

/*-----liberation pointeurs utilises sur toutes les repetitions multilocus----------------------*/
if(!Specific_Sample_Designbool) free_dvector(Q1_moy_glob);
free_imatrix(densite,dim_reseau1+2);
free_ldvector(migra);
free_ldvector(cum_fixex);
free_ldvector(cum_fixey);
if(effective_disp) {
	free_llimatrix(effective_moy,2*grande_dim+2);
	free_dmatrix(deffective,2*grande_dim+2);//crÈÈ dans calcul stat disp moy
	free_llimatrix(effectiveImmigration_moy,dim_reseau1+1);
	free_llimatrix(cumulEffectiveImmigration_moy,dim_reseau1+1);
	free_dmatrix(deffectiveImmigration, dim_reseau1+1);
}
//for(i=2*n_genes+1; i>=0; i--) free((noeud[i]));
//free((noeud));
for(int i=2*n_genes+1; i>=0; i--) delete[] noeud[i];
delete[] noeud;

if(fixe_global==0) {
	for(int i=sym+1; i>=0; i--) delete[] tabdis[i];
	delete[] tabdis;
}
/*-----------------------------------------------------------------*/


simulpars.close();

end=clock();
temps_ecoule= (double)(end - start) /CLOCKS_PER_SEC;
printf("\n\n...normal ending...%f seconds have elapsed...", temps_ecoule);
printf("\n...Press ENTER to stop the program and close the window...");
getchar();
return 0;
}/*fin programme principal*/

/************************fin programme principal**********************/
/*********************************************************************/


//circle/torus = no edge effects : turn around the lattica in each direction
//also for absorbing edges : have to come from inside the lattice (loop while inside dispersal code)
int sortie_sup_circ_abs1(int coord, int dim) {
if(coord>dim) return((coord - (int) floor( (double) coord/ (double) dim - 1E-5)*dim));
else return(coord);
}
int sortie_inf_circ_abs1(int coord, int dim) {
if(coord<=0) return( (coord + (int) ceil(-((double) coord/ (double) dim) + 1E-5)*dim) );
else return(coord);
}
int sortie_sup_circ_abs2(int coord, int dim, int trans) {
if(coord>dim) return( (coord - (int) floor( (double) coord/ (double) dim - 1E-5)*dim + (trans) ) );
else return(coord + (trans));
}
int sortie_inf_circ_abs2(int coord, int dim, int trans) {
if(coord<=0) return( (coord + (int) ceil(- ((double) coord/ (double) dim) + 1E-5)*dim + (trans)) );
else return(coord + (trans));
}

//reflective edges = miror effect on edges
int sortie_sup_refl1(int coord, int dim) {
if(coord>dim) return( (2*dim-(coord)) );
else return(coord);
}
int sortie_inf_refl1(int coord, int dim) {
if(coord<=0) return( (2-(coord)) );
else return(coord);
}
int sortie_sup_refl2(int coord, int dim, int trans) {
if(coord>dim) return( (2*dim-(coord) + (trans) ) );
else return(coord + (trans));
}
int sortie_inf_refl2(int coord, int dim, int trans) {
if(coord<=0) return( (2-(coord) + (trans)) );
else return(coord + (trans));
}

/*****************/
//Lecture des paramËtres dans fichier
int read_settings_file(const char filename[]) {
string buf,var;
//stringstring good mostly for string/numbers conversions
int pos,tempo;
char bidon;
bool BoundariesSet=false;

ifstream settings(filename,ios::in);

if(!settings.is_open()) {
	cout << "Unable to open file "<<filename << " in read_settings_file();" << endl;
	cerr << "Unable to open file "<<filename << " in read_settings_file();" << endl;
	cout << "Abnormal termination...Press any key to close the window..." << endl;
	cerr << "Abnormal termination...Press any key to close the window..." << endl;
	getchar();
	exit(-1);
	}
else
do {
		getline(settings,buf);
		if(buf.length()==0) goto nextline;
		while((buf[0]==' ')||(buf[0]=='\t')||(buf[0]=='\r')) {buf.erase(0,1);}//vire les blancs initiaux
		pos=std::min(buf.find('='),std::min(buf.find('\t'),buf.length()));
//		pos=std::min(buf.find('='),buf.length());
		var=buf.substr(0,pos).c_str();
		if(var.length()==0) goto nextline;
		if(var[0]=='%' || var[0]=='/') goto nextline;

#ifdef GOTO
_gotoxy(0,15);
#endif


		if(cmp_nocase(var,"Data_File_Name")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			strcpy(fichier_genepop,locstring.c_str());
			//fichier_migrate[1]='m';
			//strcat(fichier_migrate,fichier_genepop);
			strcat(fichier_migrate,fichier_genepop);
			strcat(fichier_migrate,"_m");
			strcat(fichier_stepsim,fichier_genepop);
			strcat(fichier_stepsim,"_dg");
			strcat(fichier_genepop,"_");
			goto nextline;
		}
		if(cmp_nocase(var,".txt_extension")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) txt_extensionbool=true;
			else if(cmp_nocase(locstring,"false")==0) txt_extensionbool=false;
			else {
				cout<<"\nBad Argument for .txt_extension in " << SettingsFilename <<  " :"<<endl;
				cout<<"Only true or false are yet implemented"<<endl;
				getchar();
				exit(-1);
			}
			goto nextline;
		}
		if(cmp_nocase(var,"Run_Number")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>repet;
			goto nextline;
		}
		if(cmp_nocase(var,"Random_Seeds")==0) {
			string reste=buf.substr(pos+1);
			stringstream strstr(reste);
			//int i=0;
			while (!strstr.eof()) {
				strstr>>tempo;
				/*strstr.get(); to skip any one-character separator which is necessarily here
				is not sufficient is there are whitespaces after the last value. If so, eof is not reached
				but no new value is read -> the last value is duplicated */
                 while (!strstr.eof() && !(isdigit(bidon=strstr.peek())) && bidon!='.') strstr.get();
                 Seeds=tempo;
                 //i++;
			}
			strstr.clear(); // c'est le truc essentiel pour le rÈutil... snif
			goto nextline;
		}
		if(cmp_nocase(var,"Locus_Number")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>n_locus;
			goto nextline;
		}
		if(cmp_nocase(var,"Min_Allele_Number")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>min_allele;
			goto nextline;
		}
		if(cmp_nocase(var,"Max_Allele_Number")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>max_allele;
			goto nextline;
		}
		if(cmp_nocase(var,"Mutation_Rate")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>_mu;
			goto nextline;
		}
		if(cmp_nocase(var,"Variable_Mutation_Rate")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) variable_mubool=true;
			else if(cmp_nocase(locstring,"false")==0) variable_mubool=false;
				else {cout<<"\nBad Argument for Variable_Mutation_Rate in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are yet implemented"<<endl;
					  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Mutation_Model")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"SMM")==0) model_mut='1';
			  else if(cmp_nocase(locstring,"IAM")==0) model_mut='2';
				else if(cmp_nocase(locstring,"KAM")==0) model_mut='3';
					else if(cmp_nocase(locstring,"TPM")==0) model_mut='4';
						else if(cmp_nocase(locstring,"GSM")==0) model_mut='5';
							else {cout<<"\nBad Argument for Mutation_Model in " << SettingsFilename <<  " :"<<endl;
					 			  cout<<"Only SMM,IAM,KAM,TPM or GSM are yet implemented"<<endl;
								  getchar();
								  exit(-1);
							}
			goto nextline;
		}
		if(cmp_nocase(var,"Allelic_Lower_Bound")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Kmin;
			goto nextline;
		}
		if(cmp_nocase(var,"Allelic_Upper_Bound")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Kmax;
			goto nextline;
		}
		if(cmp_nocase(var,"Allelic_State_MRCA")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Kini;
			goto nextline;
		}
		if(cmp_nocase(var,"SMM_Probability_In_TPM")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>pSMM;
			goto nextline;
		}
		if(cmp_nocase(var,"Geometric_Variance_In_TPM")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>var_geom_TPM;
			goto nextline;
		}
		if(cmp_nocase(var,"Geometric_Variance_In_GSM")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>var_geom_GSM;
			goto nextline;
		}
		if(cmp_nocase(var,"Ploidy")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"Diploid")==0) {diploidebool=true;ploidy=2;}
			else if(cmp_nocase(locstring,"Haploid")==0) {diploidebool=false;ploidy=1;}
				else {cout<<"\nBad Argument for Ploidy in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only Diploid or Haploid are yet implemented"<<endl;
					  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"genepop")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) genepopoui=true;
			else if(cmp_nocase(locstring,"false")==0) genepopoui=false;
				else {cout<<"\nBad Argument for genepop in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
					  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Migraine")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) DG2002=true;
			else if(cmp_nocase(locstring,"false")==0) DG2002=false;
				else {cout<<"\nBad Argument for Migraine in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Migraine_AllStates")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) AllStates=true;
			else if(cmp_nocase(locstring,"false")==0) AllStates=false;
				else {cout<<"\nBad Argument for Migraine in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Migrate")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) migrate_oui=true;
			else if(cmp_nocase(locstring,"false")==0) migrate_oui=false;
				else {cout<<"\nBad Argument for Migrate in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Migrate_Letter")==0 || cmp_nocase(var,"Migrate_Lettre")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) migrate_lettre_oui=true;
			else if(cmp_nocase(locstring,"false")==0) migrate_lettre_oui=false;
				else {cout<<"\nBad Argument for Migrate_Lettre in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
					  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Generic_Computations")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) calculoui=true;
			else if(cmp_nocase(locstring,"false")==0) calculoui=false;
				else {cout<<"\nBad Argument for Generic_Computation in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Hexp_Nei")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) HexpNeioui=true;
			else if(cmp_nocase(locstring,"false")==0) HexpNeioui=false;
				else {cout<<"\nBad Argument for HexpNei in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"DeltaH")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) DeltaHoui=true;
			else if(cmp_nocase(locstring,"false")==0) DeltaHoui=false;
				else {cout<<"\nBad Argument for DeltaH in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Allelic_Variance")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) Varoui=true;
			else if(cmp_nocase(locstring,"false")==0) Varoui=false;
				else {cout<<"\nBad Argument for Allelic_Variance in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Iterative_Identity_Probability")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) suiviQ=true;
			else if(cmp_nocase(locstring,"false")==0) suiviQ=false;
				else {cout<<"\nBad Argument for Iterative_Identity_Probability in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Iterative_Statistics")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) Fis_Het=true;
			else if(cmp_nocase(locstring,"false")==0) Fis_Het=false;
				else {cout<<"\nBad Argument for Fis_Het in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Allelic_Number_Folder")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;

			if(cmp_nocase(locstring,"true")==0) {
                cout<<"\nAllelic_Number_Folder is no more implemented :"<<endl;
				cout<<"Contact R. leblois if you really need this option"<<endl;
				getchar();
				exit(-1);
                //dossier_nbre_allele=true;
            } else if(cmp_nocase(locstring,"false")==0) dossier_nbre_allele=false;
				else {cout<<"\nBad Argument for Allelic_Number_Folder in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Prob_Id_Matrix")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) Prob_Id_Matrix=true;
			else if(cmp_nocase(locstring,"false")==0) Prob_Id_Matrix=false;
				else {cout<<"\nBad Argument for Prob_Id_Matrix in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Old_Version_Computation")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) calcul_anc=true;
			else if(cmp_nocase(locstring,"false")==0) calcul_anc=false;
				else {cout<<"\nBad Argument for Old_Version_Computation in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Effective_Dispersal")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) effective_disp=true;
			else if(cmp_nocase(locstring,"false")==0) effective_disp=false;
				else {cout<<"\nBad Argument for Effective_Dispersal in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Constant_Dispersal")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) const_disp=true;
			else if(cmp_nocase(locstring,"false")==0) const_disp=false;
				else {cout<<"\nBad Argument for Constant_Dispersal in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"2D_Dispersal")==0 || cmp_nocase(var,"2D_Disp")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"Simple1DProduct")==0) twoD_disp="Simple1DProduct";
			else if(cmp_nocase(locstring,"1DProductWithoutm0")==0) twoD_disp="1DProductWithoutm0";
			else if(cmp_nocase(locstring,"X+YdistProb")==0) twoD_disp="X+YDistProb";
			else {cout<<"\nBad Argument for 2D_Dispersal in " << SettingsFilename <<  " :"<<endl;
				cout<<"Only Simple1DProduct, 1DProductWithoutm0 or X+YdistProb are possible options"<<endl;
				getchar();
				exit(-1);
			}
			goto nextline;
		}
		if(cmp_nocase(var,"Total_Range_Dispersal")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) total_disp=true;
			else if(cmp_nocase(locstring,"false")==0) total_disp=false;
				else {cout<<"\nBad Argument for Total_Range_Dispersal in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Lattice_Boundaries")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"Circular")==0) {
                EdgeEffect=0;
                SortieSupfnPtr1 = &sortie_sup_circ_abs1;
                SortieSupfnPtr2 = &sortie_sup_circ_abs2;
                SortieInffnPtr1 = &sortie_inf_circ_abs1;
                SortieInffnPtr2 = &sortie_inf_circ_abs2;
            }
			else if(cmp_nocase(locstring,"Absorbing")==0 || cmp_nocase(locstring,"Absorbing1")==0) {
                    EdgeEffect=1;
                    SortieSupfnPtr1 = &sortie_sup_circ_abs1;
                    SortieSupfnPtr2 = &sortie_sup_circ_abs2;
                    SortieInffnPtr1 = &sortie_inf_circ_abs1;
                    SortieInffnPtr2 = &sortie_inf_circ_abs2;
                }
			 else if(cmp_nocase(locstring,"Reflecting")==0) {
                        EdgeEffect=2;
                        SortieSupfnPtr1 = &sortie_sup_refl1;
                        SortieSupfnPtr2 = &sortie_sup_refl2;
                        SortieInffnPtr1 = &sortie_inf_refl1;
                        SortieInffnPtr2 = &sortie_inf_refl2;
                    }
			 else if(cmp_nocase(locstring,"Absorbing2")==0) {
				 EdgeEffect=3;
				 SortieSupfnPtr1 = &sortie_sup_circ_abs1;
				 SortieSupfnPtr2 = &sortie_sup_circ_abs2;
				 SortieInffnPtr1 = &sortie_inf_circ_abs1;
				 SortieInffnPtr2 = &sortie_inf_circ_abs2;

			 }
			 else {cout<<"\nBad Argument for Lattice_Boundaries in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only Circular, Absorbing (1 or 2) or Reflecting are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			BoundariesSet=true;
            goto nextline;
		}
		if(cmp_nocase(var,"Max_Lattice_SizeX")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dim_reseau1;
			goto nextline;
		}
		if(cmp_nocase(var,"Max_Lattice_SizeY")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dim_reseau2;
			goto nextline;
		}
		if(cmp_nocase(var,"Sample_SizeX")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dim_sample1;
			goto nextline;
		}
		if(cmp_nocase(var,"Sample_SizeY")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dim_sample2;
			goto nextline;
		}
		if(cmp_nocase(var,"Min_Sample_CoordinateX")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>xmin_sample;
			goto nextline;
		}
		if(cmp_nocase(var,"Min_Sample_CoordinateY")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>ymin_sample;
			goto nextline;
		}
		if(cmp_nocase(var,"Specific_Sample_Design")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) Specific_Sample_Designbool=true;
			else if(cmp_nocase(locstring,"false")==0) Specific_Sample_Designbool=false;
				else {cout<<"\nBad Argument for Specific_Sample_Design in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"SpecificSampleDesign_SampleSize")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Spec_SampleSize;
			goto nextline;
		}
		if(cmp_nocase(var,"Sample_Coordinates_X")==0) {
			if(Specific_Sample_Designbool) {
				string reste=buf.substr(pos+1);
				stringstream strstr(reste);
				int i=0;
				Spec_Sample_Coord.resize(3);
				Spec_Sample_Coord[x].resize(Spec_SampleSize);
				while (!strstr.eof()) {
					strstr>>tempo;
					/*strstr.get(); to skip any one-character separator which is necessarily here
					is not sufficient is there are whitespaces after the last value. If so, eof is not reached
					but no new value is read -> the last value is duplicated */
	                 while (!strstr.eof() && !(isdigit(bidon=strstr.peek())) && bidon!='.') strstr.get();
	                 Spec_Sample_Coord[x][i]=tempo;
	                 i++;
				}
				if(i!=Spec_SampleSize) {
					cout<<"\nX Sample Coordinates are misspecified:"<<endl;
					cout<<"The number of X coordinates does not correspond to Spec_SampleSize"<<endl;
					cout<<"Check input file : " << filename << " and start the program again...."<<endl;
				 	getchar();
					exit(-1);
				}
				xmin_sample=Spec_Sample_Coord[x][0];
				strstr.clear(); // c'est le truc essentiel pour le rÈutil... snif
			}
			goto nextline;
		}
		if(cmp_nocase(var,"Sample_Coordinates_Y")==0) {
			if(Specific_Sample_Designbool) {
				string reste=buf.substr(pos+1);
				stringstream strstr(reste);
				int i=0;
				Spec_Sample_Coord[y].resize(Spec_SampleSize);
				while (!strstr.eof()) {
					strstr>>tempo;
					/*strstr.get(); to skip any one-character separator which is necessarily here
					is not sufficient is there are whitespaces after the last value. If so, eof is not reached
					but no new value is read -> the last value is duplicated */
	                 while (!strstr.eof() && !(isdigit(bidon=strstr.peek())) && bidon!='.') strstr.get();
	                 Spec_Sample_Coord[y][i]=tempo;
	                 i++;
				}
				if(i!=Spec_SampleSize) {
					cout<<"\nY Sample Coordinates are misspecified:"<<endl;
					cout<<"The number of Y coordinates does not correspond to Spec_SampleSize"<<endl;
					cout<<"Check input file : " << filename << " and start the program again...."<<endl;
				 	getchar();
					exit(-1);
				}
				ymin_sample=Spec_Sample_Coord[y][0];
				strstr.clear(); // c'est le truc essentiel pour le rÈutil... snif
			}
			goto nextline;
		}
		if(cmp_nocase(var,"Ind_Per_Pop_Sampled")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dens_sample;
			goto nextline;
		}
		if(cmp_nocase(var,"Void_Sample_Node")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>vide_sample;
			goto nextline;
		}
		if(cmp_nocase(var,"Min_Zone_CoordinateX")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>xmin_zone;
			goto nextline;
		}
		if(cmp_nocase(var,"Max_Zone_CoordinateX")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>xmax_zone;
			goto nextline;
		}
		if(cmp_nocase(var,"Min_Zone_CoordinateY")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>ymin_zone;
			goto nextline;
		}
		if(cmp_nocase(var,"Max_Zone_CoordinateY")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>ymax_zone;
			goto nextline;
		}
		if(cmp_nocase(var,"Specific_Density_Design")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) Specific_Density_Designbool=true;
			else if(cmp_nocase(locstring,"false")==0) Specific_Density_Designbool=false;
				else {cout<<"\nBad Argument for Specific_Density_Design in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
                }//remplissage du tableau densitÈ plus loin car besoiun de DimResX0 et Y0
			goto nextline;
		}
		if(cmp_nocase(var,"Ind_Per_Pop0")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dens0;
			goto nextline;
		}
		if(cmp_nocase(var,"Lattice_SizeX0")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dimRes1G0;
			goto nextline;
		}
		if(cmp_nocase(var,"Lattice_SizeY0")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dimRes2G0;
			goto nextline;
		}
		if(cmp_nocase(var,"Void_Nodes0")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>vide0;
			goto nextline;
		}
		if(cmp_nocase(var,"Zone0")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) zone0=true;
			else if(cmp_nocase(locstring,"false")==0) zone0=false;
				else {cout<<"\nBad Argument for Zone0 in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Void_Nodes_Zone0")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>vide_zone0;
			goto nextline;
		}
		if(cmp_nocase(var,"Ind_Per_Pop_Zone0")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dens_zone0;
			goto nextline;
		}
		if(cmp_nocase(var,"Dispersal_Distribution0")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>mod0;
			goto nextline;
		}
		if(cmp_nocase(var,"Total_Emigration_Rate0")==0) {
					stringstream strstr(buf.substr(pos+1));
					strstr>>Mig0;
					goto nextline;
		}
		if(cmp_nocase(var,"disp_max0")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>DX_max0;
			goto nextline;
		}
		if(cmp_nocase(var,"Pareto_Shape0")==0) {
					stringstream strstr(buf.substr(pos+1));
					strstr>>Pareto_Shape0;
					goto nextline;
		}
		if(cmp_nocase(var,"Geometric_Shape0")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>GeoG0;
			goto nextline;
		}
		if(cmp_nocase(var,"Sichel_Gamma0")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Sichel_Gamma0;
			goto nextline;
		}
		if(cmp_nocase(var,"Sichel_Xi0")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Sichel_Xi0;
			goto nextline;
		}
		if(cmp_nocase(var,"Sichel_Omega0")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Sichel_Omega0;
			goto nextline;
		}
		if(cmp_nocase(var,"ContinuousDemeSizeVariation0")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"Linear")==0) ContSizeChange0=1;
			 else if(cmp_nocase(locstring,"Exponential")==0) ContSizeChange0=2;
			  else if(cmp_nocase(locstring,"Logistic")==0) ContSizeChange0=3;
			   else if(cmp_nocase(locstring,"False")==0) ContSizeChange0=0;
				else {cout<<"\nBad Argument " << locstring << "  for ContinuousDemeSizeVariation0 in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only Linear,Exponential, Logistic or False are yet implemented"<<endl;
					  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"LogisticGrowthRate0")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>LogisticGrowthRate0;
			goto nextline;
		}
		if(cmp_nocase(var,"Gn1")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Gn1;
			goto nextline;
		}
		if(cmp_nocase(var,"Ind_Per_Pop1")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dens1;
			goto nextline;
		}
		if(cmp_nocase(var,"Lattice_SizeX1")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dimRes1G1;
			goto nextline;
		}
		if(cmp_nocase(var,"Lattice_SizeY1")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dimRes2G1;
			goto nextline;
		}
		if(cmp_nocase(var,"Void_Nodes1")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>vide1;
			goto nextline;
		}
		if(cmp_nocase(var,"Zone1")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) zone1=true;
			else if(cmp_nocase(locstring,"false")==0) zone1=false;
				else {cout<<"\nBad Argument for Zone1 in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Void_Nodes_Zone1")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>vide_zone1;
			goto nextline;
		}
		if(cmp_nocase(var,"Ind_Per_Pop_Zone1")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dens_zone1;
			goto nextline;
		}
		if(cmp_nocase(var,"Dispersal_Distribution1")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>mod1;
			goto nextline;
		}
		if(cmp_nocase(var,"Total_Emigration_Rate1")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Mig1;
			goto nextline;
		}
		if(cmp_nocase(var,"disp_max1")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>DX_max1;
			goto nextline;
		}
		if(cmp_nocase(var,"Pareto_Shape1")==0) {
					stringstream strstr(buf.substr(pos+1));
					strstr>>Pareto_Shape1;
					goto nextline;
		}
		if(cmp_nocase(var,"Geometric_Shape1")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>GeoG1;
			goto nextline;
		}
		if(cmp_nocase(var,"Sichel_Gamma1")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Sichel_Gamma1;
			goto nextline;
		}
		if(cmp_nocase(var,"Sichel_Xi1")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Sichel_Xi1;
			goto nextline;
		}
		if(cmp_nocase(var,"Sichel_Omega1")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Sichel_Omega1;
			goto nextline;
		}
		if(cmp_nocase(var,"ContinuousDemeSizeVariation1")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"Linear")==0) ContSizeChange1=1;
			 else if(cmp_nocase(locstring,"Exponential")==0) ContSizeChange1=2;
			  else if(cmp_nocase(locstring,"Logistic")==0) ContSizeChange1=3;
			   else if(cmp_nocase(locstring,"False")==0) ContSizeChange1=0;
				else {cout<<"\nBad Argument " << locstring << "   for ContinuousDemeSizeVariation1 in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only Linear,Exponential, Logistic or False are yet implemented"<<endl;
					  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"LogisticGrowthRate1")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>LogisticGrowthRate1;
			goto nextline;
		}
		if(cmp_nocase(var,"Gn2")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Gn2;
			goto nextline;
		}
		if(cmp_nocase(var,"Ind_Per_Pop2")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dens2;
			goto nextline;
		}
		if(cmp_nocase(var,"Lattice_SizeX2")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dimRes1G2;
			goto nextline;
		}
		if(cmp_nocase(var,"Lattice_SizeY2")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dimRes2G2;
			goto nextline;
		}
		if(cmp_nocase(var,"Void_Nodes2")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>vide2;
			goto nextline;
		}
		if(cmp_nocase(var,"Zone2")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) zone2=true;
			else if(cmp_nocase(locstring,"false")==0) zone2=false;
				else {cout<<"\nBad Argument for Zone2 in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Void_Nodes_Zone2")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>vide_zone2;
			goto nextline;
		}
		if(cmp_nocase(var,"Ind_Per_Pop_Zone2")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dens_zone2;
			goto nextline;
		}
		if(cmp_nocase(var,"Dispersal_Distribution2")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>mod2;
			goto nextline;
		}
		if(cmp_nocase(var,"disp_max2")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>DX_max2;
			goto nextline;
		}
		if(cmp_nocase(var,"Pareto_Shape2")==0) {
					stringstream strstr(buf.substr(pos+1));
					strstr>>Pareto_Shape2;
					goto nextline;
		}
		if(cmp_nocase(var,"Total_Emigration_Rate2")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Mig2;
			goto nextline;
		}
		if(cmp_nocase(var,"Geometric_Shape2")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>GeoG2;
			goto nextline;
		}
		if(cmp_nocase(var,"Sichel_Gamma2")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Sichel_Gamma2;
			goto nextline;
		}
		if(cmp_nocase(var,"Sichel_Xi2")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Sichel_Xi2;
			goto nextline;
		}
		if(cmp_nocase(var,"Sichel_Omega2")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Sichel_Omega2;
			goto nextline;
		}
		if(cmp_nocase(var,"ContinuousDemeSizeVariation2")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"Linear")==0) ContSizeChange2=1;
			 else if(cmp_nocase(locstring,"Exponential")==0) ContSizeChange2=2;
			  else if(cmp_nocase(locstring,"Logistic")==0) ContSizeChange2=3;
			   else if(cmp_nocase(locstring,"False")==0) ContSizeChange2=0;
				else {cout<<"\nBad Argument " << locstring << "   for ContinuousDemeSizeVariation2 in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only Linear,Exponential, Logistic or False are yet implemented"<<endl;
					  getchar();
					  exit(-1);
				}

            goto nextline;
		}
		if(cmp_nocase(var,"LogisticGrowthRate2")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>LogisticGrowthRate2;
			goto nextline;
		}
		if(cmp_nocase(var,"Gn3")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Gn3;
			goto nextline;
		}
		if(cmp_nocase(var,"Ind_Per_Pop3")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dens3;
			goto nextline;
		}
		if(cmp_nocase(var,"Lattice_SizeX3")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dimRes1G3;
			goto nextline;
		}
		if(cmp_nocase(var,"Lattice_SizeY3")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dimRes2G3;
			goto nextline;
		}
		if(cmp_nocase(var,"Void_Nodes3")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>vide3;
			goto nextline;
		}
		if(cmp_nocase(var,"Zone3")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) zone3=true;
			else if(cmp_nocase(locstring,"false")==0) zone3=false;
				else {cout<<"\nBad Argument for Zone3 in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		if(cmp_nocase(var,"Void_Nodes_Zone3")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>vide_zone3;
			goto nextline;
		}
		if(cmp_nocase(var,"Ind_Per_Pop_Zone3")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>dens_zone3;
			goto nextline;
		}
		if(cmp_nocase(var,"Dispersal_Distribution3")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>mod3;
			goto nextline;
		}
		if(cmp_nocase(var,"Total_Emigration_Rate3")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Mig3;
			goto nextline;
		}
		if(cmp_nocase(var,"disp_max3")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>DX_max3;
			goto nextline;
		}
		if(cmp_nocase(var,"Pareto_Shape3")==0) {
					stringstream strstr(buf.substr(pos+1));
					strstr>>Pareto_Shape3;
					goto nextline;
		}
		if(cmp_nocase(var,"Geometric_Shape3")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>GeoG3;
			goto nextline;
		}
		if(cmp_nocase(var,"Sichel_Gamma3")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Sichel_Gamma3;
			goto nextline;
		}
		if(cmp_nocase(var,"Sichel_Xi3")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Sichel_Xi3;
			goto nextline;
		}
		if(cmp_nocase(var,"Sichel_Omega3")==0) {
			stringstream strstr(buf.substr(pos+1));
			strstr>>Sichel_Omega3;
			goto nextline;
		}
		if(cmp_nocase(var,"Random_Translation")==0) {
			string locstring;
			stringstream strstr(buf.substr(pos+1));
			strstr>>locstring;
			if(cmp_nocase(locstring,"true")==0) random_translation=true;
			else if(cmp_nocase(locstring,"false")==0) random_translation=false;
				else {cout<<"\nBad Argument for Random_Translation in " << SettingsFilename <<  " :"<<endl;
					  cout<<"Only true or false are possible options"<<endl;
				 	  getchar();
					  exit(-1);
				}
			goto nextline;
		}
		cout<<"\n(!) Unknown keyword "<<var<<" in file "<<filename<<endl;
	   getchar();
	   exit(-1);
nextline: ;	// the pleasure of sin :-)
} while((!settings.eof()) || (cmp_nocase(var,"EndOfSettings")==1));
if((cmp_nocase(var,"EndOfSettings")==0)||(settings.eof())) {
} else {
	cout<<"\n(!) Unknown keyword "<<var<<" in file "<<filename<<endl;
	getchar();
	exit(-1);
}
if((ContSizeChange0==1 || ContSizeChange0==2) && (Gn1>2147483646)) {
    cout<<"\nContinuousDemeSizeVariation0 and/or Gn1 are misspecified:"<<endl;
	cout<<"Gn1 should be < 2147483647 with ContinuousDemeSizeVariation0!=0"<<endl;
	cout<<"This is because the continuous change in deme size is yet configured from"<<endl;
	cout<<"Ind_Per_Pop0 to Ind_Per_Pop1 from G0 to Gn1 and not from a user defined growth rate"<<endl;
	cout<<"infinitely long growth or decline is thus not yet configured."<<endl;
	cout<<"Check input file : " << filename << " and start the program again...."<<endl;
 	getchar();
	exit(-1);
}

if(!const_disp && (Gn1>2147483646 || (dimRes1G0==1 && dimRes2G0==1 && dimRes1G1==1 && dimRes2G1==1 && dimRes1G2==1 && dimRes2G2==1))) {
    cout<<"\nConstant dispersal is set to false but there is no change in time or a single population:"<<endl;
	cout<<"Constant dispersal is now set to true"<<endl;
    const_disp=true;
 	getchar();
}
if((ContSizeChange1==1 || ContSizeChange1==2) && (Gn2>2147483646)) {
    cout<<"\nContinuousDemeSizeVariation1 and/or Gn2 are misspecified:"<<endl;
	cout<<"Gn2 should be < 2147483647 with ContinuousDemeSizeVariation1!=0"<<endl;
	cout<<"This is because the continuous change in deme size is yet configured from"<<endl;
	cout<<"Ind_Per_Pop1 to Ind_Per_Pop2 from Gn1 to Gn2 and not from a user defined growth rate"<<endl;
	cout<<"infinitely long growth or decline is thus not yet configured."<<endl;
	cout<<"Check input file : " << filename << " and start the program again...."<<endl;
 	getchar();
	exit(-1);
}
if((ContSizeChange2==1 || ContSizeChange2==2) && (Gn3>2147483646)) {
    cout<<"\nContinuousDemeSizeVariation1 and/or Gn3 are misspecified:"<<endl;
	cout<<"Gn3 should be < 2147483647 with ContinuousDemeSizeVariation2!=0"<<endl;
	cout<<"This is because the continuous change in deme size is yet configured from"<<endl;
	cout<<"Ind_Per_Pop2 to Ind_Per_Pop3 from Gn2 to Gn3 and not from a user defined growth rate"<<endl;
	cout<<"infinitely long growth or decline is thus not yet configured."<<endl;
	cout<<"Check input file : " << filename << " and start the program again...."<<endl;
 	getchar();
	exit(-1);
}
if(false/*ContSizeChange0==3 /*&& (Gn1>2147483646)*/) {
        cout << "Logistic not yet implemented" << endl;
//    cout<<"\nContinuousDemeSizeVariation0 and/or Gn1 are misspecified:"<<endl;
//	cout<<"Gn1 should be < 2147483647 with ContinuousDemeSizeVariation0!=0"<<endl;
//	cout<<"This is because the continuous change in deme size is yet configured from"<<endl;
//	cout<<"Ind_Per_Pop0 to Ind_Per_Pop1 from G0 to Gn1 and not from a user defined growth rate"<<endl;
//	cout<<"infinitely long growth or decline is thus not yet configured."<<endl;
//	cout<<"Check input file : " << filename << " and start the program again...."<<endl;
 	getchar();
	exit(-1);
}
if(BoundariesSet==false) {
    cout<<"\nNo settings for Lattice_Boundaries were detected in " << SettingsFilename <<  " :"<<endl;
	cout<<"Please add a line to specify if Boundaries are Circular, Absorbing or Reflecting"<<endl;
	cout<<"Refer to the user manual for more details; \n Programm aborted"<<endl;
	getchar();
	exit(-1);
}

//vÈrifications de l'homogÈnÈitÈ des constantes rentrÈes
if(!((1<=Gn1)&&(Gn1<=Gn2)&&(Gn2<=Gn3))) {
	printf("\nProblem : Gn1, Gn2, Gn3 are not in the good order; \n Programm aborted");
	getchar();
	exit(0);
}
if(Kini!=0&&(Kini>Kmax||Kini<Kmin)) {
	printf("\nProblem : Kini is not between Kmin and Kmax; \n Programm aborted");
	getchar();
	exit(-1);
}
if(DG2002&&n_locus>1)
 {printf("\nCannot write multilocus files for DG2002 (=> Set n_locus=1)");
  printf("\n Programm aborted");
  getchar();exit(-1);
}
//if(!Specific_Sample_Designbool) {
	if(dimRes2G0==1) vide_sampleY=1; else vide_sampleY=vide_sample;
	if(dimRes1G0==1) vide_sampleX=1; else vide_sampleX=vide_sample;
//}
if(!Specific_Sample_Designbool) if((dimRes1G0>1 && dimRes1G0<(dim_sample1-1)*vide_sampleX+1) || (dimRes2G0>1 && dimRes2G0<(dim_sample2-1)*vide_sampleY+1))
 {printf("\nproblem with lattice dimensions: dim_Sample > dim_Reseau");
  printf("\ndimRes1G0=%d; xmin_sample=%d; dim_sample1=%d void_sample_nodeX=%d;",dimRes1G0,xmin_sample,dim_sample1,vide_sampleX);
  printf("\ndimRes2G0=%d; ymin_sample=%d; dim_sample2=%d; void_sample_nodeY=%d;",dimRes2G0,ymin_sample,dim_sample2,vide_sampleY);
  printf("\n Programm aborted");
  getchar();exit(-1);
}
if(!Specific_Sample_Designbool) if(dimRes1G0<(xmin_sample+(dim_sample1-1)*vide_sampleX)||(dimRes2G0<(ymin_sample+(dim_sample2-1)*vide_sampleY) && dim_sample2>vide_sampleY && dimRes2G0>1))
 {printf("\nProblem with sample position on the lattice: X/Ymin_sample > dimReseauG0");
  printf("\ndimRes1G0=%d; xmin_sample=%d; dim_sample1=%d void_sample_nodeX=%d;",dimRes1G0,xmin_sample,dim_sample1,vide_sampleX);
  printf("\ndimRes2G0=%d; ymin_sample=%d; dim_sample2=%d; void_sample_nodeY=%d;",dimRes2G0,ymin_sample,dim_sample2,vide_sampleY);
  printf("\n Programm aborted");
  getchar();exit(-1);
}
if(!Specific_Sample_Designbool) if((xmin_sample+(dim_sample1-1)*vide_sample)<=0||(ymin_sample+(dim_sample2-1)*vide_sample)<=0)
 {printf("\nProblem with sample position on the lattice: X/Ymin_sample < 0");
  printf("\ndimRes1G0=%d; xmin_sample=%d; dim_sample1=%d vide_sample=%d;",dimRes1G0,xmin_sample,dim_sample1,vide_sample);
  printf("\ndimRes2G0=%d; ymin_sample=%d; dim_sample2=%d; vide_sample=%d;",dimRes2G0,ymin_sample,dim_sample2,vide_sample);
  printf("\n Programm aborted");
  getchar();exit(-1);
}
if(Specific_Sample_Designbool && !(fmod((double)Spec_Sample_Coord[x][0],(double)vide_sampleX)==0.0)) {
	cout<<"\nX Sample Coordinates are misspecified:"<<endl;
	cout<<"The first X coordinate (=" << Spec_Sample_Coord[x][0] << ") does not match void_sample_node=" << vide_sampleX << ";" <<endl;
	cout<<"Check input file : " << filename << " and start the program again...."<<endl;
 	getchar();
	exit(-1);
}
if(Specific_Sample_Designbool && !(fmod((double)Spec_Sample_Coord[y][0],(double)vide_sampleY)==0.0)) {
	cout<<"\nY Sample Coordinates are misspecified:"<<endl;
	cout<<"The first Y coordinate does not match void_sample_node"<<endl;
	cout<<"Check input file : " << filename << " and start the program again...."<<endl;
 	getchar();
	exit(-1);
}
 if((fmod(double(dimRes1G0),double(vide0))!=0.0)||(fmod(double(dimRes2G0),double(vide0))!=0.0)
     ||(fmod(double(dimRes1G1),double(vide1))!=0.0)||(fmod(double(dimRes2G1),double(vide1))!=0.0)
     ||(fmod(double(dimRes1G2),double(vide2))!=0.0)||(fmod(double(dimRes2G2),double(vide2))!=0.0)
     ||(fmod(double(dimRes1G3),double(vide3))!=0.0)||(fmod(double(dimRes2G3),double(vide3))!=0.0))
 {printf("\nproblem of non homogeneous lattice in regards to Vide : dimReseau != k*vide");
  printf("\n Programm aborted");
  getchar();exit(-1);
}


if(Specific_Sample_Designbool && (Prob_Id_Matrix || calculoui || HexpNeioui || DeltaHoui || Varoui || Fis_Het)) {
	cout<<"\n\n\nSpecific_Sample_Design=true is not compatible with Generic_Computations=true,"<<endl;
	cout<<"Hexp_Nei=true,DeltaH=true,Allelic_Variance=true, Pob_id_Matrix=true or Iterative_Statistics=true "<<endl;
	cout<<"All computations of genetic statistics will be set to false...."<<endl;
	cout<<"Press any key to continue computations...."<<endl;
	calculoui=false;
	HexpNeioui=false;
	DeltaHoui=false;
	Varoui=false;
	Fis_Het=false;
	Prob_Id_Matrix=false;
	getchar();
	//exit(-1);
} else {
	if(HexpNeioui && !calculoui) {
		cout<<"\nHexp_Nei=true needs Generic_Computations=true"<<endl;
		cout<<"Generic_Computations will be set to true...."<<endl;
		cout<<"Press any key to continue computations...."<<endl;
		calculoui=true;
		getchar();
		//exit(-1);
	}
	if(DeltaHoui && !calculoui) {
		cout<<"\nDeltaH=true needs Generic_Computations=true"<<endl;
		cout<<"Generic_Computations will be set to true...."<<endl;
		cout<<"Press any key to continue computations...."<<endl;
		calculoui=true;
		getchar();
		//exit(-1);
	}
	if(Varoui && !calculoui) {
		cout<<"\nAllelic_Variance=true needs Generic_Computations=true"<<endl;
		cout<<"Generic_Computations will be set to true...."<<endl;
		cout<<"Press any key to continue computations...."<<endl;
		calculoui=true;
		getchar();
		//exit(-1);
	}
	if(Fis_Het && !calculoui) {
		cout<<"\nIterative_Statistics=true needs Generic_Computations=true"<<endl;
		cout<<"Generic_Computations will be set to true...."<<endl;
		cout<<"Press any key to continue computations...."<<endl;
		calculoui=true;
		getchar();
		//exit(-1);
	}
	if(cmp_nocase(twoD_disp,"1DProductWithoutm0")==0 && mod0!='g') {
		cout<<"\ntwoD_disp==\"1DProductWithoutm0\"  is yet implemented for the geometric distribution only"<<endl;
		cout<<"I exit...."<<endl;
		getchar();
		exit(-1);
	}
}//end else if (specific sample design)
#ifdef GOTO
	_gotoxy(0,0);
#endif


cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" << endl;
cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" << endl;
cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" << endl;
fflush(stdout);

#ifdef GOTO
	_gotoxy(0,15);
#endif

if((!Specific_Density_Designbool) && (!zone0) && (vide0==1)) fixe0=true; else fixe0=false;
if((!zone1) && (vide1==1)) fixe1=true; else fixe1=false;
if((!zone2) && (vide2==1)) fixe2=true; else fixe2=false;
if((!zone3) && (vide3==1)) fixe3=true; else fixe3=false;
if(!Specific_Density_Designbool && ((fixe0&&fixe1&&fixe2&&fixe3) || (fixe0&&(Gn1>2147483646)))) fixe_global=1;
  else fixe_global=0;

if((!fixe0 && (!fixe1 || !fixe2 || !fixe3)) || (!fixe1 && (!fixe0 || !fixe2 || !fixe3)) || (!fixe2 && (!fixe0 || !fixe1 || !fixe3))) {
 cout << "IBDSim is not yet designed to take into account temporal changes with diffÈrent non-homogeneous density configurations." << endl;
 cout << "Contact R. Leblois to adapt the program for such cases.\nEnd of the program" << endl;
 getchar();
 exit(-1);

}
if(fixe_global==0){
	sym=0;
	if((!Specific_Density_Designbool) && (!zone0) && (!fixe0)) sym=vide0;
	if((!zone1)&&(!fixe1)&&(vide1>sym)&&(Gn1<2147483646)) sym=vide1;
	if((!zone2)&&(!fixe2)&&(vide2>sym)&&(Gn2<2147483646)) sym=vide2;
	if((!zone3)&&(!fixe3)&&(vide3>sym)&&(Gn3<2147483646)) sym=vide3;
	if(sym==0) sym=sup(dim_reseau1,dim_reseau2);
}
if((!fixe_global || Specific_Density_Designbool) && (ContSizeChange0 || ContSizeChange1 || ContSizeChange2)) {
    cout << "IBDSim is not yet designed to take into account continuous deme size changes with non-homogeneous density configurations." << endl;
    cout << "Check ContinuousDemeSizeVariation, Void_nodes and Specific_Density_Design specifications in " << filename << endl;
    cout << "End of the program" << endl;
    getchar();
    exit(-1);
}
//fin vÈrification homogÈnÈitÈ des constantes entrÈes


#ifdef GOTO
	_gotoxy(0,0);
#endif


cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" << endl;
cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" << endl;
cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n" << endl;
fflush(stdout);
#ifdef GOTO
	_gotoxy(0,0);
#endif

settings.close();
//getchar();
return 0;
}
/*****************/

/****************/
/*int file_tester(const int i) {
char Fishet[] = "atuer";
ffishet.open(Fishet,ios::out|ios::app);
ffishet<<i<<endl;
cout<<i<<endl<<flush;
ffishet.close();
return 0;
}*/
/****************/


/*****************/
//crÈÈ et/ou alloue la memoire pour cum2[][] de tabdis[][].cum2[][]
// avec dx_max et dy_max potentiellement diffÈrents
int new_disdis(const int dxmax,const int dymax) {
if(fixe_global==0) {// si la densitÈ n'est pas la mÍme partout
	if (!tabdis[0]) {
			cout<<"Went into new_disdis while tabdis has not been allocated"<<flush;
	   		getchar();
		}

for (int i=0; i<=sym+1; i++) {
	 for (int j=0; j<=sym+1; j++) {
#ifdef DEBUG
		tabdis[i][j].cum2.resize(2*dxmax+2);
  	  	for (int k=0; k<2*dxmax+2; k++)	tabdis[i][j].cum2[k].resize(2*dymax+2);
#else
        //cout << "Allocate memory for tabdis[" << i << "][" << j << ".cum2" << ends;
        tabdis[i][j].cum2=new double*[2*dxmax+2];
    	if (!tabdis[i][j].cum2) {
    	 	printf("boucle %d",j);
	 	   	nrerror("allocation failure 3 in structure disdis()");
	   		getchar();
	  		}
  	  	for (int k=0; k<2*dxmax+2; k++)	{
            //cout << "k=" << k << "(2*dymax+2=" << 2*dymax+2 << "); " << ends;
            tabdis[i][j].cum2[k]=new double[2*dymax+2];
      		if (!tabdis[i][j].cum2[k]) {
      			printf("boucle %d",j);
			   	nrerror("allocation failure 4 in structure disdis()");
		   		getchar();
	  			}
     		}//for k
     		//cout << endl;
     		//cout << endl;
#endif
     	}//for  j
	}// for i
}//if
return 0;
}

/*****************/
//crÈÈ et/ou alloue la memoire pour cum2[][] de tabdis[][].cum2[][]
// avec dx_max et dy_max identiques
int new_disdis(const int dxmax) {
if(fixe_global==0) {// si la densitÈ n'est pas la mÍme partout
	if (!tabdis[0]) {
			cout<<"Went into new_disdis while tabdis has not been allocated"<<flush;
	   		getchar();
		}

for (int i=0; i<=sym+1; i++) {
	 for (int j=0; j<=sym+1; j++) {
#ifdef DEBUG
		tabdis[i][j].cum2.resize(2*dxmax+2);
  	  	for (int k=0; k<2*dxmax+2; k++)	tabdis[i][j].cum2[k].resize(2*dxmax+2);
#else
	    tabdis[i][j].cum2=new double*[2*dxmax+2];
    	if (!tabdis[i][j].cum2) {
    	 	printf("boucle %d",j);
	 	   	nrerror("allocation failure 3 in structure disdis()");
	   		getchar();
	  		}
  	  	for (int k=0; k<2*dxmax+2; k++)	{
  	  		fflush(stdout);
            tabdis[i][j].cum2[k]=new double[2*dxmax+2];
      		if (!tabdis[i][j].cum2[k]) {
      			printf("boucle %d",j);
			   	nrerror("allocation failure 4 in structure disdis()");
		   		getchar();
	  			}
     		}//for k
#endif
     	}//for  j
	}// for i
}//if
return 0;
}

/*****************/
//divers affichage Ècran au dÈbut du run a ameillorer...
void affichage_ecran()
{
#ifdef GOTO
	_gotoxy(0,0);
#endif

//printf("\n");
printf("================================================================\n");
printf("This is IBDSim v1.2 (Leblois et al. 2008 MolEcol Ressources) for the\n");
printf("simulation of genotypic data under isolation by distance models\n");
printf("based in the algorithms described in Leblois et al. 2003 MBE,\n");
printf(" Leblois et al. 2004 Genetics, Leblois et al. 2006 MolEcol\n");
printf("=================================================================\n");
printf("Summary settings: genetic file name is %s;\n",fichier_genepop);
printf("Mutational model is ");
switch(model_mut)
 {case'1':
 printf("SMM; ");
 break;
 case'2':
 printf("IAM; ");
 break;
 case'3':
 printf("KAM; ");
 break;
 case'4':
 printf("TPM; ");
 break;
 case'5':
 printf("GSM; ");
 break;
 }
printf("\nSimulation of %d data sets/iterations x %d locus;",repet,n_locus);
if(!Specific_Sample_Designbool) printf("\nSample: (%d x %d) * %d = %d ",dim_sample1,dim_sample2,dens_sample,dim_sample1*dim_sample2*dens_sample);
    else printf("\nSample: (%d) * %d = %d ",Spec_SampleSize,dens_sample,Spec_SampleSize*dens_sample);
if(diploidebool) printf("diploid individuals ");
 else printf("haploid individuals ");
if (EdgeEffect==0) printf("evolving at G=0 on a %d x %d torus",dimRes1G0,dimRes2G0);
if (EdgeEffect==1) printf("evolving at G=0 on a %d x %d lattice with absorbing boundaries (truncated dispersal distribution, probability mass reported on the whole distribution including or not P(dx=0)=(1-mig))",dimRes1G0,dimRes2G0);
if (EdgeEffect==3) printf("evolving at G=0 on a %d x %d lattice with absorbing boundaries (truncated dispersal distribution, probability mass reported on P(dx=0)=(1-mig))",dimRes1G0,dimRes2G0);
if (EdgeEffect==2) printf("evolving at G=0 on a %d x %d lattice with reflecting boundaries",dimRes1G0,dimRes2G0);
printf("\n================================================================\n");
}/*fin affichage ecran*/



/*---------initialisations pour deux dimensions---------------------------*/

/*****************/
void ini_migra()
{sig=kurt=0.0;
norm=0.0;
deja=deja1=deja3=0;
}

/*****************/
//initialisation des position geographiques des individus ÈchantillonnÈs
void ini_tableaux()
{int p,k,o,d;// j et d virÈs FER 28/08/2005 rajoutÈ RL car importants :
// d= si l'on Èchantillonne plusieurs individus sur un meme deme on veut qu'ils aient les meme coordonnÈes
//j= pour prendre en compte la deuxieme dimension de l'Èchantillon = la position en x est incrÈmentÈ uniquement
// quand on a placÈ tout les individus voulus en diffÈrents y

for(int i=1;i<=2*n_genes;i++) coord_ori[i][x]=coord_ori[i][y]=0;
for(int i=1;i<=n_genes;i++)  no_noeud_restant[i]=i;

p=1; k=xmin_sample;
for(int i=1;i<=(2*n_genes);)
 {if(i<=n_genes)
	{o=ymin_sample;
	for(int j=1;j<=dim_sample2;j++) // ‡ quoi Áa sert ??? cf plus haut
	 {for(d=1;d<=dens_sample;d++) // ‡ quoi Áa sert ???
		{coord_noeud[p][x]=coord_individus[p][x]=k;
		 if(diploidebool) coord_noeud[p+1][x]=coord_individus[p+1][x]=k;
		 coord_noeud[p][y]=coord_individus[p][y]=o;
		 if(diploidebool) coord_noeud[p+1][y]=coord_individus[p+1][y]=o;
		 p+=ploidy;
		}
	 o+=vide_sampleY;
	 }
	i=p;
	}
  else
	{coord_noeud[i][x]=coord_individus[i][x]=0;
	if(diploidebool) coord_noeud[i+1][x]=coord_individus[i+1][x]=0;
	coord_noeud[i][y]=coord_individus[i][y]=0;
	if(diploidebool) coord_noeud[i+1][y]=coord_individus[i+1][y]=0;
	i=i+ploidy;
	}
  k+=vide_sampleX;
 }
//verif
//for(i=1;i<=n_genes;i++)
// {printf("\n coord_individu[%d]=[%d,%d]",i,coord_individus[i][x],coord_individus[i][y]);
//  getchar();
// }
}

/*****************/
//procÈdure spÈciale pour positionnement spÈcifiques des individus sur le reseau (intialement pour simuls MIGRATE)
void ini_tableaux_specifique()
{int i,p,d; //j, d virÈs FER 28/08/2005 RL rajoutÈ  :meme chose que plus haut

for(i=1;i<=2*n_genes;i++) coord_ori[i][x]=coord_ori[i][y]=0;
for(i=1;i<=n_genes;i++)  no_noeud_restant[i]=i;

//cout << "\n\nBeginning of ini_tableaux(), n_genes=" << n_genes << "; Specific Sample Coordinates are :" << endl;
//for(int i=0;i<Spec_SampleSize;i++)	cout << Spec_Sample_Coord[x][i] << " " << Spec_Sample_Coord[y][i] << endl;


for(i=0,p=1;p<=(2*n_genes);) {
    if(p<=n_genes) {
        //cout << "p=" << p << "i=" << i << endl;
            for(d=1;d<=dens_sample;d++) {
                coord_noeud[p][x]=coord_individus[p][x]=Spec_Sample_Coord[x][i];
                if(diploidebool) coord_noeud[p+1][x]=coord_individus[p+1][x]=Spec_Sample_Coord[x][i];
                coord_noeud[p][y]=coord_individus[p][y]=Spec_Sample_Coord[y][i];
                if(diploidebool) coord_noeud[p+1][y]=coord_individus[p+1][y]=Spec_Sample_Coord[y][i];
                //cout << "coord_individu[" << p << "]=[" << coord_individus[p][x] << "," << coord_individus[p][y] << "]" << endl;
                p+=ploidy;
    	   }
    	i++;
    }
    else {
        coord_noeud[p][x]=coord_individus[p][x]=0;
	    if(diploidebool) coord_noeud[p+1][x]=coord_individus[p+1][x]=0;
	    coord_noeud[p][y]=coord_individus[p][y]=0;
	    if(diploidebool) coord_noeud[p+1][y]=coord_individus[p+1][y]=0;
	    p+=ploidy;
	}
}
//cout << "\nEnd of ini_tableaux(), we have :" << endl;
//for(i=1;i<=(2*n_genes);i++) {
//	cout << "coord_individu[" << i << "]=[" << coord_individus[i][x] << "," << coord_individus[i][y] << "]" << endl;
//}
//getchar();
}

/*****************/
//initialisation des stats utilisÈes sur plusieurs repetitions
void ini_moy_glob()
{cum_moyx=cum_moyy=0;
if(effective_disp) {
	for(int i=0;i<=2*grande_dim;i++) effective_moy[i][x]=effective_moy[i][y]=0;
	for(int i=0;i<dim_reseau1+1;i++) for(int j=0;j<dim_reseau2+1;j++) effectiveImmigration_moy[i][j]=cumulEffectiveImmigration_moy[i][j]=0;
}
hetero_moy_glob=0.0;
HexpNei_moy_glob=0.0;
HexpNei_moy_glob_var=0.0;
DeltaH_moy_glob=0.0;
DeltaH_moy_glob_var=0.0;
Var_moy_glob=0.0;
Var_moy_glob_var=0.0;
M_moy_glob=0.0;
M_moy_glob_var=0.0;
fis_moy_glob=0.0;
fis_moy_denom_glob=0.0;
fis_moy_numer_glob=0.0;
Qpop_moy_glob=0.0;
mono=0;
compte_mut=0;
mut_moy_glob=0.0;
mut_moy_glob_var=0.0;
mrca_moy_glob=0.0;
coa_moy_glob=0.0;
Qind_moy_glob=0.0;
if(!Specific_Sample_Designbool) for(int i=0;i<=sup(dimRes1G0,sup(dim_sample1,dim_sample2));i++) Q1_moy_glob[i]=0.0;
}

/*****************/
//initialisation des stats utilisÈes sur une repetition multilocus
void ini_moy() {
nbre_allele_moy=0.0;
if(effective_disp) {
	for(int i=0;i<=2*grande_dim;i++) effective[i][x]=effective[i][y]=0;
	for(int i=0;i<dim_reseau1+1;i++) for(int j=0;j<dim_reseau2+1;j++) effectiveImmigration[i][j]=cumulEffectiveImmigration[i][j]=0;
}
for(int i=1;i<=n_locus;i++){
	for(int j=0;j<=Kmax;j++) {
        freq[i][j]=0.0;
        nom_alleles_locusi[i][j]=0;
    }
	HexpNei[i]=0.0;
	Var[i]=0.0;
	mrca[i]=0;
	DeltaH[i]=0.0;
	fis[i]=0.0;
	nbre_allele[i]=0;
	allele_max[i]=-1000;
	allele_min[i]=1000;
	hetero[i]=0.0;
	M[i]=0.0;
}
HexpNei_moy=0.0;
DeltaH_moy=0.0;
Var_moy=0.0;
M_moy=0.0;
hetero_moy=0.0;
fis_moy=0.0;
fis_moy_denom=0.0;
fis_moy_numer=0.0;
Qpop_moy=0.0;
mrca_moy=0.0;
temps_coa=compteur3=0;
temps_coa_moy=0.0;
Qind_moy=0.0;
if(!Specific_Sample_Designbool) for(int i=0;i<=sup(dimRes1G0,sup(dim_sample1,dim_sample2));i++)
 {for(int j=1;j<=n_locus;j++) Q1[j][i]=0.0;
 Q1_moy[i]=0.0;
 }
}

/*****************/
//initialisation de la structure noeud
void ini_struct_noeud()
{ for(int i=1;i<=2*n_genes;i++)
  {for(int j=1;j<=n_locus;j++)
	{noeud[i][j].etat_allele=111;
	noeud[i][j].generation=noeud[i][j].
	nbre_descendant=noeud[i][j].ancetre=0;
	for(int k=0;k<10;k++) noeud[i][j].descendant[k]=0;
	}
  }
}

/*****************/
//re-initialisation de la structure noeud pour le locus en cours de simulation
//effectuÈe si le locus venant d'etre simulÈ est monophorphe et ne nous interesse pas
void ini_struct_noeud2()
{int j;
 for(int i=1;i<=2*n_genes;i++)
  {j=locus;
  noeud[i][j].etat_allele=111;
  noeud[i][j].generation=noeud[i][j].
  nbre_descendant=noeud[i][j].ancetre=0;
  for(int k=0;k<10;k++) noeud[i][j].descendant[k]=0;
  }
}


/*-------------------------------------------------------------------------*/
/*--------------------dispersion-------------------------------------------*/

/*****************/
//initialisation des diffÈrents parametres dÈmographiques en fonction des changement temporels planifiÈs
//prÈcise aussi si l'on doit ou non changer certains parametres de migration (remet deja et deja1 a 0)
//crÈÈ une translation en x et y si les genes suivis doivent etre placÈs sur un nouveau reseau plus grand

///appellÈes dans new_disp()
char migra_tps(long int G)
{char mod;
//if (locus ==2) cout<<"migra_tps begin"<<flush;

if((G==1)||(G==Gn1)||(G==Gn2)||(G==Gn3)||(deja3==0))
  {
//if (locus ==2) {cout<<"migra_tps if"<<flush;}
  if(G>=Gn3)
  	{
//if (locus ==2) cout<<"migra_tps (G>=Gn3"<<flush;
  	ini_migra();deja3=1;fixe=fixe3;vide=vide3;
	dens=dens3;zone=zone3;vide_zone=vide_zone3;
	dens_zone=dens_zone3;Mig=Mig3;GeoG=GeoG3;mod=mod3;DX_max=DX_max3;Pareto_Shape=Pareto_Shape3;
	Sichel_Gamma=Sichel_Gamma3,Sichel_Xi=Sichel_Xi3,Sichel_Omega=Sichel_Omega3;
	if(dimRes1G3>dimRes1)//translation sur x
		{translationx=(dimRes1G3-dimRes1)/2;
		if(random_translation==1) translationx=int(floor(alea()*translationx));
		translationx-=int(fmod(double(translationx),double(vide)));
		}
	if(dimRes2G3>dimRes2)//translation sur y
		{translationy=(dimRes2G3-dimRes2)/2;
		if(random_translation==1) translationy=int(floor(alea()*translationy));
		translationy-=int(fmod(double(translationy),double(vide)));
		}
	dimRes1=dimRes1G3;dimRes2=dimRes2G3;
	}//fin if Gn>Gn3
	else
	  {if(G>=Gn2)
	  	{ini_migra();deja3=1;fixe=fixe2;vide=vide2;
		dens=dens2;zone=zone2;vide_zone=vide_zone2;
		dens_zone=dens_zone2;Mig=Mig2;GeoG=GeoG2;mod=mod2;DX_max=DX_max2;Pareto_Shape=Pareto_Shape2;
		Sichel_Gamma=Sichel_Gamma2,Sichel_Xi=Sichel_Xi2,Sichel_Omega=Sichel_Omega2;
		ContSizeChange=ContSizeChange2;
		if(ContSizeChange==1) {//continuous linear change in deme size through time
                 growthRate=(dens3-dens2)/(Gn3-Gn2);
                 startingSize=dens2;
                 growthStart=Gn2;
                }
              else if(ContSizeChange==2) {//continuous exponential change in deme size through time
                       growthRate=log(dens3/dens2)/(Gn3-Gn2);//-1* ???
                       startingSize=dens2;
                       growthStart=Gn2;
                    }
                    else if(ContSizeChange==3) {//continuous logistic change in deme size through time
                        KLogistic=dens3;
                        P0Logistic=dens2;
                        LogisticGrowthRate=LogisticGrowthRate2;
                        growthStart=Gn2;

                    }
		if(dimRes1G2>dimRes1)//translation sur x
				{translationx=(dimRes1G2-dimRes1)/2;
				if(random_translation==1) translationx=int(floor(alea()*translationx));
				translationx-=int(fmod(double(translationx),double(vide)));
				}
		if(dimRes2G2>dimRes2)//translation sur y
			{translationy=(dimRes2G2-dimRes2)/2;
			if(random_translation==1) translationy=int(floor(alea()*translationy));
			translationy-=int(fmod(double(translationy),double(vide)));
			}
		//printf("\n Gn2 translation_x=%d; translation_y=%d",translationx,translationy);
		//getchar();
		dimRes1=dimRes1G2;dimRes2=dimRes2G2;
		}//fin if Gn>=Gn2
		else
		 {if(G>=Gn1)
			{ini_migra();deja3=1;fixe=fixe1;vide=vide1;
			dens=dens1;zone=zone1;vide_zone=vide_zone1;dens_zone=dens_zone1;
			Mig=Mig1;GeoG=GeoG1;mod=mod1;DX_max=DX_max1;Pareto_Shape=Pareto_Shape1;
			Sichel_Gamma=Sichel_Gamma1,Sichel_Xi=Sichel_Xi1,Sichel_Omega=Sichel_Omega1;
			ContSizeChange=ContSizeChange1;
			 if(ContSizeChange==1) {//continuous linear change in deme size through time
                 growthRate=(dens2-dens1)/(Gn2-Gn1);
                 startingSize=dens1;
                 growthStart=Gn1;
                }
              else if(ContSizeChange==2) {//continuous exponential change in deme size through time
                       growthRate=log(dens2/dens1)/(Gn2-Gn1);//-1* ???
                       startingSize=dens1;
                       growthStart=Gn1;
                    }
                    else if(ContSizeChange==3) {//continuous logistic change in deme size through time
                        KLogistic=dens2;
                        P0Logistic=dens1;
                        LogisticGrowthRate=LogisticGrowthRate1;
                        growthStart=Gn1;

                    }
			if(dimRes1G1>dimRes1)//translation sur x
				{translationx=(dimRes1G1-dimRes1)/2;
				if(random_translation==1) translationx=int(floor(alea()*translationx));
				translationx-=int(fmod(double(translationx),double(vide)));
				}
			if(dimRes2G1>dimRes2)//translation sur y
				{translationy=(dimRes2G1-dimRes2)/2;
				if(random_translation==1) translationy=int(floor(alea()*translationy));
				translationy-=int(fmod(double(translationy),double(vide)));
				}
			//printf("\n Gn1 translation_x=%d; translation_y=%d",translationx,translationy);
			//getchar();
			dimRes1=dimRes1G1;dimRes2=dimRes2G1;
			}//fin if Gn>=Gn1
			else//pour Gn=1
			 {
//if (locus ==2) {cout<<"migra_tps Gn=1"<<flush;}
			 ini_migra();
//if (locus ==2) {cout<<"migra_tps paf"<<flush;}
			 deja3=1;fixe=fixe0;vide=vide0;
			 dens=dens0;zone=zone0;vide_zone=vide_zone0;dens_zone=dens_zone0;
			 DX_max=DX_max0;Pareto_Shape=Pareto_Shape0;
			 Mig=Mig0;GeoG=GeoG0;mod=mod0;dimRes1=dimRes1G0;dimRes2=dimRes2G0;
			 Sichel_Gamma=Sichel_Gamma0,Sichel_Xi=Sichel_Xi0,Sichel_Omega=Sichel_Omega0;
			 ContSizeChange=ContSizeChange0;
			 if(ContSizeChange==1) {//continuous linear change in deme size through time
                 growthRate=(dens1-dens0)/Gn1;
                 startingSize=dens0;
                 growthStart=0;
                }
              else if(ContSizeChange==2) {//continuous linear change in deme size through time
					   growthRate=log((float) dens1/dens0)/Gn1;//-1* ???
                       startingSize=dens0;
                       growthStart=0;
                    }
                    else if(ContSizeChange==3) {//continuous logistic change in deme size through time
                        KLogistic=dens1;
                        P0Logistic=dens0;
                        LogisticGrowthRate=LogisticGrowthRate0;
                        growthStart=0;

                    }
			 translationx=translationy=0;
//if (locus ==2) {cout<<"migra_tps pof"<<flush;}
			 }//pour Gn=1
		}//fin else if Gn>=Gn1
	}//fin else if Gn>=Gn2
  }// fin if((G==1)||(G==Gn1)||(G==Gn2)||(G==Gn3)||(deja3==0))
/*printf("mod: %c",mod);
getchar();*/
//cout<<"migra_tps end"<<flush;
return(mod);
}

/*****************/
//dÈfini les probabilitÈ de migration en fonction du modele de dispersion choisi
//dÈfini dx_max et dy_max = migration maximal considÈrÈe
//accessoirement calcul sigma et kurtosis pour vÈrification
//appelÈe dans new_disp()
void forw()
{//cout<<"debut forw"<<flush;
 double mig,kpar;
/*gotoxy(1,18);
printf("model mig:%c",model_mig);*/
//if (locus ==2) cout<<"deja="<<deja<<flush;
if(deja==0) // remis ‡ 0 en de multiples endroits eg pour Gn=1 dans migra_tps
  {

      norm=0;
switch(model_mig)
	{case'0':/*sigma≤=4 pour analyses a petite distance cf FR (c) (d)*/
	  {if(total_disp) {
	  		if(true /*twoD_disp=="Simple1DProduct"*/) dy_min=dx_min=-15; else dy_min=dx_min=1;
	   		dy_max=dx_max=15;
		}
		else {
			dx_max=dimRes1-1;
			dy_max=min(dimRes2-1,dx_max);
	  		if(true /*twoD_disp=="Simple1DProduct"*/) {
				dx_min=-dx_max;
				dy_min=-dy_max; //obligatoire
			} else dx_min=dy_min=1;
	  	}
	  	//migra=ldvector(dx_max+1);
		//new_disdis(dx_max);
		migra=ldvector(dx_max+1);
		new_disdis(dx_max,dy_max);// ceci et dy_max utilisÈ slmt pour cette distrib... ‡ gÈnÈraliser
		if(true /*twoD_disp=="Simple1DProduct"*/) {
		  cum_fixex=ldvector(2*dx_max+2);//obsolete car maintenant deux tableau pour x et y
		  cum_fixey=ldvector(2*dy_max+2);
		} else cum_fixex=ldvector(dx_max+1);
	  	mig=0.3;
	  	kpar=2.51829;
	  	migra[0]=(double)(1-mig);
	  	migra[1]=(double) 0.06;
	  	migra[2]=(double) 0.03;
	  	for(int i=3;i<=dx_max;i++) norm+=((double) (pow(1.0/i,kpar)));
	  	for(int i=3;i<=dx_max;i++)
		migra[i]=((double) ((mig-2*migra[1]-2*migra[2])*pow(1.0/i,kpar)/(2*norm)));
		deja=1;
	  }
	  break;
	 case'1':/*stepping stone, mig=2/3*/
	  {if(true /*twoD_disp=="Simple1DProduct"*/) dy_min=dx_min=-1; else dy_min=dx_min=1;
	   dy_max=dx_max=1;
	  	//migra=ldvector(dx_max+1);
	 	//new_disdis(dx_max);
	  	migra=ldvector(dx_max+1);
	  	new_disdis(dx_max,dy_max);// ceci et dy_max utilisÈ slmt pour cette distrib... ‡ gÈnÈralise
		if(true /*twoD_disp=="Simple1DProduct"*/) {
			cum_fixex=ldvector(2*dx_max+2);//obsolete car maintenant deux tableau pour x et
			cum_fixey=ldvector(2*dy_max+2);
		} else cum_fixex=ldvector(dx_max+1);
	  	migra[1]=((double) 1/3);
	  	migra[0]=((double) 1/3);
	  	deja=1;
	  }
	  break;
	 case'2':/*kurtosis forte cf waser dipodomys sigma2=1*/
	  {if(total_disp) {
	  		if(true /*twoD_disp=="Simple1DProduct"*/) dy_min=dx_min=-49; else dy_min=dx_min=1;
			dy_max=dx_max=49;
		}
		else {
			dx_max=dimRes1-1;
	  		dy_max=min(dimRes2-1,dx_max);
			if(true /*twoD_disp=="Simple1DProduct"*/) {
				dx_min=-dx_max;
				dy_min=-dy_max; //obligatoire
			} else dx_min=dy_min=1;
	  	}
		migra=ldvector(dx_max+1);
		new_disdis(dx_max,dy_max);// ceci et dy_max utilisÈ slmt pour cette distrib... ‡ gÈnÈraliser
		if(true /*twoD_disp=="Simple1DProduct"*/) {
			  cum_fixex=ldvector(2*dx_max+2);//obsolete car maintenant deux tableau pour x et
			  cum_fixey=ldvector(2*dy_max+2);
		} else cum_fixex=ldvector(dx_max+1);
	  	mig=0.599985;
		kpar=3.79809435;
		for(int i=1;i<=dx_max;i++) norm+=((double) (pow(1.0/i,kpar)));
		for(int i=1;i<=dx_max;i++)
		migra[i]=((double) (mig*pow(1.0/i,kpar)/(2*norm)));
		migra[0]=(double) (1-mig);
		deja=1;
	  }
	  break;
	 case'3':/*sigma2=100*/
	  {if(total_disp) {
	  		if(true /*twoD_disp=="Simple1DProduct"*/) dy_min=dx_min=-48; else dy_min=dx_min=1;
	    	dy_max=dx_max=48;
		}
		else {
			dx_max=dimRes1-1;
	  		dy_max=min(dimRes2-1,dx_max);
	  		if(true /*twoD_disp=="Simple1DProduct"*/) {
				dx_min=-dx_max;
				dy_min=-dy_max; //obligatoire
			} else dx_min=dy_min=1;
	  	}
		migra=ldvector(dx_max+1);
		new_disdis(dx_max,dy_max);// ceci et dy_max utilisÈ slmt pour cette distrib... ‡ gÈnÈraliser
		if(true /*twoD_disp=="Simple1DProduct"*/) {
			cum_fixex=ldvector(2*dx_max+2);//obsolete car maintenant deux tableau pour x et
			cum_fixey=ldvector(2*dy_max+2);
		} else cum_fixex=ldvector(dx_max+1);
	    //migra=ldvector(dx_max+1);
		//new_disdis(dx_max);
	  	mig=0.6;
	  	kpar=1.246085;
	  	migra[0]=(double) (1-mig);
	  	for(int i=1;i<=dx_max;i++) norm+=((double) (pow(1.0/i,kpar)));
	  	for(int i=1;i<=dx_max;i++)
	  	migra[i]=((double) (mig*pow(1.0/i,kpar)/(2*norm)));
	  	deja=1;
	  }
	  break;
	 case'4':/*sigma=1 pour un noeud sur deux*/
	  {if(total_disp) {
	  		if(true /*twoD_disp=="Simple1DProduct"*/) dx_min=-24; else dx_min=1;//modifié ensuite
	   		dx_max=24;
	   		dy_max=2*dx_max;
	   		dy_min=2*dx_min;

		}
		else {
			dx_max=dimRes1-1;
	  		dy_max=min(dimRes2-1,2*dx_max);
	  		if(true /*twoD_disp=="Simple1DProduct"*/) {
				dx_min=-dx_max;
				dy_min=-dy_max; //obligatoire
			} else dx_min=dy_min=1;
	  	}
		migra=ldvector(2*(dx_max+1));
		new_disdis(2*dx_max,dy_max);// ceci et dy_max utilisÈ slmt pour cette distrib... ‡ gÈnÈraliser
		if(true /*twoD_disp=="Simple1DProduct"*/) {
			cum_fixex=ldvector(2*2*dx_max+2);//obsolete car maintenant deux tableau pour x et
			cum_fixey=ldvector(2*dy_max+2);
		} else cum_fixex=ldvector(2*dx_max+1);
	  	//migra=ldvector(2*(dx_max+1));	//le 2* est la acause des noeuds vides
		//new_disdis(2*dx_max);
	  	kpar=4.1078739681;
	 	migra[0]=migra[1]=(double)0.824095;
	  	mig=1-migra[0];
	  	for(int i=1;i<=dx_max;i++) norm+=((double) (pow(1.0/i,kpar)));
	  	for(int i=2;i<=2*dx_max;i+=2)
	  	migra[i]=migra[i+1]=((double) (mig*pow(1.0/(i/2),kpar)/(2*norm)));
	  	dx_min=2*dx_min;
	  	dx_max=2*dx_max;
	  	deja=1;
	  }
	  break;
	 case'5':/*sigma=1 pour un noeud sur trois*/
	  {if(total_disp) {
	  		if(true /*twoD_disp=="Simple1DProduct"*/) dx_min=-16; else dx_min=1;//attention modifie apres
	   		dx_max=16;
	   		dy_max=3*dx_max;
	   		dy_min=3*dx_min;

		}
		else {
			dx_max=dimRes1-1;
	  		dy_max=min(dimRes2-1,3*dx_max);
	  		if(true /*twoD_disp=="Simple1DProduct"*/) {
				dx_min=-dx_max;
				dy_min=-dy_max; //obligatoire
			} else dx_min=dy_min=1;
	  	}
		migra=ldvector(3*(dx_max+1));
		new_disdis(3*dx_max,dy_max);// ceci et dy_max utilisÈ slmt pour cette distrib... ‡ gÈnÈraliser
		if(true /*twoD_disp=="Simple1DProduct"*/) {
			cum_fixex=ldvector(2*3*dx_max+2);//obsolete car maintenant deux tableau pour x et
			cum_fixey=ldvector(2*dy_max+2);
		} else cum_fixex=ldvector(3*dx_max+1);
		//migra=ldvector(3*(dx_max+1));
		//new_disdis(3*dx_max,dy_max);
		//migra.resize(3*(dx_max+1));
		//new_disdis(3*dx_max);
	  	kpar=4.43153111547;
	  	migra[0]=migra[1]=migra[2]=(double)0.913378;
	  	mig=1-migra[0];
	  	for(int i=1;i<=dx_max;i++) norm+=((double) (pow(1.0/i,kpar)));
	  	for(int i=3;i<=3*dx_max;i+=3)
	  	migra[i]=migra[i+1]=migra[i+2]=((double) (mig*pow(1.0/(i/3),kpar)/(2*norm)));
	  	dx_min=3*dx_min;
	  	dx_max=3*dx_max;
	  	deja=1;
	  }
	  break;
	 case'6':/*sigma2=20*/
	  {if(total_disp) {
	  		if(true /*twoD_disp=="Simple1DProduct"*/) dy_min=dx_min=-48; else dy_min=dx_min=1;
	   		dy_max=dx_max=48;

		}
		else {
			dx_max=dimRes1-1;
	  		dy_max=min(dimRes2-1,dx_max);
	  		if(true /*twoD_disp=="Simple1DProduct"*/) {
				dx_min=-dx_max;
				dy_min=-dy_max; //obligatoire
			} else dx_min=dy_min=1;
	  	}
		migra=ldvector(dx_max+1);
		new_disdis(dx_max,dy_max);// ceci et dy_max utilisÈ slmt pour cette distrib... ‡ gÈnÈraliser
		if(true /*twoD_disp=="Simple1DProduct"*/) {
			cum_fixex=ldvector(2*dx_max+2);//obsolete car maintenant deux tableau pour x et
			cum_fixey=ldvector(2*dy_max+2);
		} else cum_fixex=ldvector(dx_max+1);
	  	//migra=ldvector(dx_max+1);
		//new_disdis(dx_max);
	  	mig=0.719326;
	  	kpar=2.0334337244;
	  	migra[0]=(double) (1-mig);
	  	for(int i=1;i<=dx_max;i++) norm+=((double) (pow(1.0/i,kpar)));
	  	for(int i=1;i<=dx_max;i++)
	  		migra[i]=((double) (mig*pow(1.0/i,kpar)/(2*norm)));
	  	deja=1;
	  }
	  break;
	 case'7':/*sigma2=10*/
	  {if(total_disp) {
	  		if(true /*twoD_disp=="Simple1DProduct"*/) dy_min=dx_min=-49; else dy_min=dx_min=1;
	   		dy_max=dx_max=49;

		}
		else {
			dx_max=dimRes1-1;
	  		dy_max=min(dimRes2-1,dx_max);
	  		if(true /*twoD_disp=="Simple1DProduct"*/) {
				dx_min=-dx_max;
				dy_min=-dy_max; //obligatoire
			} else dx_min=dy_min=1;
	  	}
		migra=ldvector(dx_max+1);
		new_disdis(dx_max,dy_max);// ceci et dy_max utilisÈ slmt pour cette distrib... ‡ gÈnÈraliser
		if(true /*twoD_disp=="Simple1DProduct"*/) {
			cum_fixex=ldvector(2*dx_max+2);//obsolete car maintenant deux tableau pour x et
			cum_fixey=ldvector(2*dy_max+2);
		} else cum_fixex=ldvector(dx_max+1);
		//migra=ldvector(dx_max+1);
		//new_disdis(dx_max);
	  	mig=0.702504;
	  	kpar=2.313010658;
	  	migra[0]=(double) (1-mig);
	  	for(int i=1;i<=dx_max;i++) norm+=((double) (pow(1.0/i,kpar)));
	  	for(int i=1;i<=dx_max;i++)
	  		migra[i]=((double) (mig*pow(1.0/i,kpar)/(2*norm)));
	  	deja=1;
	  }
	  break;
	 case'8':/*sigma≤=4 pour un noeud sur trois*/
	  {if(total_disp) {
	  		if(true /*twoD_disp=="Simple1DProduct"*/) dx_min=-16; else dx_min=1;//attention modifiÈ apres
	   		dx_max=16;
	   		dy_max=3*dx_max;
	   		dy_min=3*dx_min;

		}
		else {
			dx_max=dimRes1-1;
	  		dy_max=min(dimRes2-1,3*dx_max);
	  		if(true /*twoD_disp=="Simple1DProduct"*/) {
				dx_min=-dx_max;
				dy_min=-dy_max; //obligatoire
			} else dx_min=dy_min=1;
	  	}
		migra=ldvector(3*(dx_max+1));
		new_disdis(3*dx_max,dy_max);// ceci et dy_max utilisÈ slmt pour cette distrib... ‡ gÈnÈraliser
		if(true /*twoD_disp=="Simple1DProduct"*/) {
			cum_fixex=ldvector(2*3*dx_max+2);//obsolete car maintenant deux tableau pour x et
			cum_fixey=ldvector(2*dy_max+2);
		} else cum_fixex=ldvector(3*dx_max+1);
		//migra=ldvector(3*(dx_max+1));
		//new_disdis(3*dx_max);
	  	kpar=4.1598694692;
	  	migra[0]=migra[1]=migra[2]=(double)0.678842;
	  	mig=1-migra[0];
	  	for(int i=1;i<=dx_max;i++) norm+=((double) (pow(1.0/i,kpar)));
	  	for(int i=3;i<=3*dx_max;i+=3)
	  		migra[i]=migra[i+1]=migra[i+2]=((double) (mig*pow(1.0/(i/3),kpar)/(2*norm)));
	 	dx_min=3*dx_min;
	  	dx_max=3*dx_max;
	  	deja=1;}
	  break;
	 case'9':/*sigma2=4 mais sur 48 pas*/
	  {	if(total_disp) {
	  		if(true /*twoD_disp=="Simple1DProduct"*/) dy_min=dx_min=-48; else dy_min=dx_min=1;
	   		dy_max=dx_max=48;
		}
		else {
			dx_max=dimRes1-1;
	  		dy_max=min(dimRes2-1,dx_max);
	  		if(true /*twoD_disp=="Simple1DProduct"*/) {
				dx_min=-dx_max;
				dy_min=-dy_max; //obligatoire
			} else dx_min=dy_min=1;
	  	}
		migra=ldvector(dx_max+1);
		new_disdis(dx_max,dy_max);// ceci et dy_max utilisÈ slmt pour cette distrib... ‡ gÈnÈraliser
		if(true /*twoD_disp=="Simple1DProduct"*/) {
			cum_fixex=ldvector(2*dx_max+2);//obsolete car maintenant deux tableau pour x et
			cum_fixey=ldvector(2*dy_max+2);
		} else cum_fixex=ldvector(dx_max+1);
	  	mig=0.700013;
	  	kpar=2.74376568;
	  	migra[0]=(double)(1.0-mig);
	  	for(int i=1;i<=dx_max;i++) norm+=((double) (pow(1.0/i,kpar)));
	  	for(int i=1;i<=dx_max;i++)
		migra[i]=((double) (mig*pow(1.0/i,kpar)/(2*norm)));
	 	deja=1;}
	break;
	case'P':/*Pareto custom*/
		  {	if(total_disp) {
		  		if(true /*twoD_disp=="Simple1DProduct"*/) dy_min=dx_min=-DX_max; else dy_min=dx_min=1;
		   		dy_max=dx_max=DX_max;
			}
			else {
				dx_max=dimRes1-1;
		  		dy_max=min(dimRes2-1,dx_max);
		  		if(true /*twoD_disp=="Simple1DProduct"*/) {
					dx_min=-dx_max;
					dy_min=-dy_max; //obligatoire
				} else dx_min=dy_min=1;
		  	}
			migra=ldvector(dx_max+1);
			new_disdis(dx_max,dy_max);// ceci et dy_max utilisÈ slmt pour cette distrib... ‡ gÈnÈraliser
			if(true /*twoD_disp=="Simple1DProduct"*/) {
				cum_fixex=ldvector(2*dx_max+2);//obsolete car maintenant deux tableau pour x et
				cum_fixey=ldvector(2*dy_max+2);
			} else cum_fixex=ldvector(dx_max+1);
		  	mig=Mig;
		  	kpar=Pareto_Shape;
		  	migra[0]=(double)(1.0-mig);
		  	for(int i=1;i<=dx_max;i++) norm+=((double) (pow(1.0/i,kpar)));
		  	for(int i=1;i<=dx_max;i++)
			migra[i]=((double) (mig*pow(1.0/i,kpar)/(2*norm)));
		 	deja=1;}
	break;
	 case'a':/*stepping stone mig=1/3*/
	  {if(true /*twoD_disp=="Simple1DProduct"*/) dy_min=dx_min=-1; else dy_min=dx_min=1;
	   dy_max=dx_max=1;
		migra=ldvector(dx_max+1);
		new_disdis(dx_max,dy_max);// ceci et dy_max utilisÈ slmt pour cette distrib... ‡ gÈnÈraliser
		if(true /*twoD_disp=="Simple1DProduct"*/) {
			cum_fixex=ldvector(2*dx_max+2);//obsolete car maintenant deux tableau pour x et
			cum_fixey=ldvector(2*dy_max+2);
		} else cum_fixex=ldvector(dx_max+1);
		//migra=ldvector(dx_max+1);
		//new_disdis(dx_max);
		mig=1/3;
	  	migra[1]=((double) 1/6);
	  	migra[0]=((double) 2/3);
	  	deja=1;
	  }
	  break;
	 case'b':/*general stepping stone*/
	  {if(true /*twoD_disp=="Simple1DProduct"*/) dy_min=dx_min=-1; else dy_min=dx_min=1;
	   dy_max=dx_max=1;
		migra=ldvector(dx_max+1);
		//*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		// NOUVELLE VERSION
		new_disdis(dx_max,dy_max);// ceci et dy_max utilisÈ slmt pour cette distrib... ‡ gÈnÈraliser
		if(cmp_nocase(twoD_disp,"Simple1DProduct")==0) {
			cum_fixex=ldvector(2*dx_max+2);//obsolete car maintenant deux tableau pour x et
			cum_fixey=ldvector(2*dy_max+2);
		} else cum_fixex=ldvector(dx_max+1);
		// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
	  	//printf("\n distrib stepping stone 0.01");
	  	mig=Mig;
	  	migra[1]=((double) mig/2);
	  	migra[0]=((double) 1-mig);
	  	deja=1;
	  }
	  break;
	 case'g':/*geometric*/
	  {if(total_disp) {
		    dy_min=dx_min=-DX_max;
	   		dy_max=dx_max=DX_max;
		}
		else {
			dx_max=dimRes1-1;
	  		dy_max=min(dimRes2-1,dx_max);
	  		if(true /*twoD_disp=="Simple1DProduct"*/) {
				dx_min=-dx_max;
				dy_min=-dy_max; //obligatoire
			} else dx_min=dy_min=1;
	  	}
		//*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		// NOUVELLE VERSION
		migra=ldvector(dx_max+1);
		new_disdis(dx_max,dy_max);// ceci et dy_max utilisÈ slmt pour cette distrib... ‡ gÈnÈraliser
		if(true /*twoD_disp=="Simple1DProduct"*/) {
			cum_fixex=ldvector(2*dx_max+2);//obsolete car maintenant deux tableau pour x et
			cum_fixey=ldvector(2*dy_max+2);
		} else cum_fixex=ldvector(dx_max+1);
		// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
		//
		/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		// ANCIENNE VERSION
        dy_min=dx_min=-48;
	   	dy_max=dx_max=48;
		new_disdis(dx_max);
		//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
		//	  mig=0.6;//(339.-sqrt(1353.))/336.;//(33801. - sqrt(135201.))/33798.;/*was 0.01 puis 0.25; 0.01 pour island model*/
		//	  kpar=(339.-sqrt(1353.))/336.;//(33801. - sqrt(135201.))/33798.; //0.2 0.5 0.75; 1! pour island model
     	 mig=Mig;
      	 kpar=GeoG;
		  //printf("\n distrib geometric m=%f; alpha=%f",1-migra[0],alpha);
		  if(cmp_nocase(twoD_disp,"1DProductWithoutm0")==0) {
			  migra0=(double) (1.0-mig);

			  for(int i=0;i<=dx_max;i++) norm+=(double)pow(kpar,i); //+1 if kpar=1
			  for(int i=0;i<=dx_max;i++) {
				  migra[i]=(double) pow(kpar,i)/(2.0*norm-1.0); //1/(2*(dx_max+1)-1)= 1/(2*dx_max+1)
                  // migra["-dx_max"] to [dx_max] ([0] included) should sum to 1; migra[0] is NOT 1-mig.
			  }
		  } else {
			  migra[0]=(double) (1.0-mig);
			if (kpar==1) { //disp en ile ATTENTION PAS CONTINUITE ENTRE LES 2 CAS
				for(int i=1;i<=dx_max;i++) migra[i]=(double) mig/(dx_max-1); //aucune perte sur bord !!
			} else {
				for(int i=1;i<=dx_max;i++) norm+=(double) pow(kpar,i-1.0);
				for(int i=1;i<=dx_max;i++)
					migra[i]=(double) pow(kpar,i-1.0)*(1-migra[0])/(2.0*norm); //so migra[<>0] sum to 1-migra[0]=mig. "Cross migration pattern" for low mig
			}
		}
        /****** in the original version of IBDsim there is no further change on migra[] ******/
 	     float Dhs2;
 	     int maxdd=max(dimRes1,dimRes2)-1;
	     double maxcumul=0;

         double sillyfactor;

         /*In 1D without boundary effect:

         \sum_{-\infty}^{\infty} g^{|x|} =2/(1-g)-1  [-1 is because there is only one instance of (0,0)...]

        hence zero fraction is 1/(2/(1-g)-1)=(1-g)/(1+g) and remainder is 2g/(1+g)

        Realized m is then mig * [\sum_{real lattice positions} g^k (1+g)/2 g]



        Same computation in 2D:

        \sum_{-\infty}^{\infty}\sum_{-\infty}^{\infty} g^{|x|+|y|} =(2/(1-g)-1)^2

        Hence (0,0) fraction is 1/((2/(1-g)-1)^2)=[(1-g)/(1+g)]^2 and remainder is 4g/(1+g)^2

        */

          if(dimRes2/vide>1) { // this test matches the one in the sampling algorithm

              sillyfactor=(1-migra0)*(1.+GeoG)*(1+GeoG)/(4*GeoG);

          } else sillyfactor=(1-migra0)*(1.+GeoG)/(2*GeoG);

         {
			  if (! simulparsWrittenBool) simulpars<<"UNCORRECTED immigration rates in the different demes:"<<endl;

		      int a=0;int b; double cumul;
			  if(dimRes2/vide>1) { // this test matches the one in the sampling algorithm

			    for(int xpos=0;xpos<dimRes1;xpos++) {
				  for(int ypos=0;ypos<dimRes2;ypos++) {
					  b=0;cumul=0;
					  for(int xxpos=0;xxpos<dimRes1;xxpos++){
						  for(int yypos=0;yypos<dimRes2;yypos++){
							  if(a!=b) { // different pops => not the migra[0]*migra[0] term
								  // distances between a and b for absorbing boundaries:
								  dx=abs(xpos-xxpos);
								  dy=abs(ypos-yypos);
								  cumul+=migra[dx]*migra[dy];
							  }
							  b++;
						  }// yypos
					  }// xxpos

		              if(cmp_nocase(twoD_disp,"1DProductWithoutm0")==0) {

					      cumul*=sillyfactor/(sillyfactor*cumul+migra0); // migration terms over all terms => the real immigration proba into position (xpos,ypos) before correction
// the sillyfactor must not affect the final result, but the simulpars output is more logical with it

					  } else {

					      cumul/=(cumul+migra[0]*migra[0]); // migration terms over all terms => the real immigration proba into position (xpos,ypos)

					  }

					  if (! simulparsWrittenBool) {
						  simulpars<<cumul<<" ";
					  }
					  if (cumul>maxcumul) {
						  maxcumul=cumul; // the maximal immigration proba into one position
						  //    cout<<maxcumul;getchar();
					  }
					  a++;
				  } // for ypos ...
				  if (! simulparsWrittenBool) simulpars<<endl;

			    } // for xpos ...
         } else { // 1D...

			    for(int xpos=0;xpos<dimRes1;xpos++) {

					  b=0;cumul=0;

					  for(int xxpos=0;xxpos<dimRes1;xxpos++){

							  if(a!=b) { // different pops => not the migra[0]*migra[0] term

								  // distances between a and b for absorbing boundaries:

								  dx=abs(xpos-xxpos);

								  cumul+=migra[dx];

							  }

							  b++;

					  }// xxpos

		              if(cmp_nocase(twoD_disp,"1DProductWithoutm0")==0) {

					      cumul*=sillyfactor/(sillyfactor*cumul+migra0); // migration terms over all terms => the real immigration proba into position (xpos,ypos)

					  } else {

					      cumul/=(cumul+migra[0]*migra[0]); // migration terms over all terms => the real immigration proba into position (xpos,ypos)

					  }

					  if (! simulparsWrittenBool) {

						  simulpars<<cumul<<" ";

					  }

					  if (cumul>maxcumul) {

						  maxcumul=cumul; // the maximal immigration proba into one position

						  //    cout<<maxcumul;getchar();

					  }

					  a++;

			    } // for xpos ...

             } //2D else 1D

         } // block a ,b
        /****** However, if we want to control the maximal dispersal rate, we will change the migra[]: ******/
		  if(cmp_nocase(twoD_disp,"1DProductWithoutm0")==0) {
			  if (! simulparsWrittenBool) {
			      simulpars<<endl<<"maximal immigration rate before correction: "<<maxcumul<<endl;
			  }
              //normalization of maximal dispersal
 // tmp is first such that tmp^dim:=f defined as the solution of f sillyfactor S/(f sillyfactor S+m0) = mig where we know sillyfactor S/(sillyfactor S+m0)=maxcumul

              double tmp=(1.-1./maxcumul)/(1.-1./mig);

              tmp*=sillyfactor; //now tmp=f sillyfactor so that there's no need for sillyfactor factor in the later computations (in particular, actual sampling)

   			  if(dimRes2/vide>1) tmp=sqrt(tmp); // now tmp=f; test matches the one in the sampling algorithm

//cout<<tmp;getchar();
			  for(int i=0;i<=dx_max;i++) {
				  migra[i]*=tmp; /* now the sum of the 2D terms over feasible dispersal positions must be mig for the maximal deme
				  and the sum of the migra[] terms must be > sqrt(mig) (and somewhat opaque). */
			  }
		      int a=0;int b; double cumul;
			  if (! simulparsWrittenBool) {
			      // recomputation of the the cumul: not economical, but safe check
			      a=0;
				  simulpars<<"immigration rates in the different demes:"<<endl;
			      if(dimRes2/vide>1) { // this test matches the one in the sampling algorithm

			        for(int xpos=0;xpos<dimRes1;xpos++) {
				      for(int ypos=0;ypos<dimRes2;ypos++) {
					      b=0;cumul=0;
					      for(int xxpos=0;xxpos<dimRes1;xxpos++){
						      for(int yypos=0;yypos<dimRes2;yypos++){
							      if(a!=b) { // different pops => not the migra[0]*migra[0] term
								       // distances between a and b for absorbing boundaries:
								       dx=abs(xpos-xxpos);
								       dy=abs(ypos-yypos);
								       cumul+=migra[dx]*migra[dy];
							      }
							      b++;
                              }// yypos
					      }// xxpos
						  simulpars<<cumul/(cumul+migra0)<<" ";

					      a++;
				      } // for ypos ...
					  simulpars<<endl;
			        } // for xpos ...

			     } else { //1D...

			        for(int xpos=0;xpos<dimRes1;xpos++) {

					      b=0;cumul=0;

					      for(int xxpos=0;xxpos<dimRes1;xxpos++){

							      if(a!=b) { // different pops => not the migra[0]*migra[0] term

								       // distances between a and b for absorbing boundaries:

								       dx=abs(xpos-xxpos);

								       cumul+=migra[dx];

							      }

							      b++;

					      }// xxpos

						  simulpars<<cumul/(cumul+migra0)<<" ";

					      a++;

					  simulpars<<endl;

			        } // for xpos ...

                 }
              }// if (! simulpars...
		  } else { //computation of maximal dispersal rate in original version of IBDsim
// rien ?
          }
		  if (! simulparsWrittenBool) {
			  simulpars<<endl<<"Dispersal proba (if 2D: NOT axial !): "<<mig<<endl;
    		  simulpars<<"Geometric param: "<<kpar<<endl;
			  if(cmp_nocase(twoD_disp,"1DProductWithoutm0")==0) {
			      float condsig2;
			      if (dimRes2/vide>1) { //2D
			          /*cf code R
			            condaxialS2fromg<-function(gv) {\n\
                            return((1+gv)/((2-gv)*(1-gv)^2))\n\
                        }\n\                      */
			          condsig2=(1.+kpar)/((2-kpar)*(1.-kpar)*(1.-kpar));
			      } else {
			          condsig2=(1.+kpar)/((1.-kpar)*(1.-kpar));
                  }
			      float Nhm=ploidy*dens0*mig;
			      Dhs2=Nhm*condsig2;
    			  simulpars<<"effective (2D) 2N_h m parameter accounting for edge effects: "<<2*Nhm<<endl;
			  } else {
			      float sig2=mig*(1.+kpar)/((1.-kpar)*(1.-kpar));
			      Dhs2=ploidy*dens0*sig2;
		    	  simulpars<<"axial sigma2 (no edges): "<<sig2<<endl;
			  }
		      simulpars<<"D_h sigma2 : "<<Dhs2<<endl;
		      simulpars<<"Neighborhood : "<<(2*Dhs2)<<"(1D) or "<<(2*PI*Dhs2)<<" (2D)."<<endl<<endl;
			  if(cmp_nocase(twoD_disp,"1DProductWithoutm0")==0) {
			      simulpars<<"marginal terms and checksum "<<endl;
			      double bordel=0,sumNonzero;
			      bordel= migra0;
			     simulpars<<"x=y=0:  "<<migra0<<" "<<bordel<<endl;
			      if(dimRes2/vide>1) { // this test matches the one in the sampling algorithm
			         /*Now the maximal \sum\sum_{x,y\neq0,0}=1-migra0
			         =>\sum\sum_{x,y}-migra[0]^2=(\sum_x)^2-migra[0]^2=1-migra0
			         =>\sum_{y<>0}= sqrt[1-migra0+migra[0]^2]-migra[0]
			         */
			         sumNonzero=sqrt(1-migra0+migra[0]*migra[0])-migra[0];
			         bordel+=migra[0]*sumNonzero;
			         simulpars<<" x=0,y<>0 :"<< migra[0]*sumNonzero<<" "<<bordel<<endl;
			      } else sumNonzero=1;
			      for(int i=1;i<=maxdd;i++) { // up to maxdd=dimRes1-1
				     bordel+=2*migra[i]*sumNonzero;
				     simulpars<<"x="<<i<<": "<<migra[i]*sumNonzero    <<" "<<bordel<<endl;
			      }
			  } else { //pas 1D...withoutm0
			      simulpars << "1D dispersal distribution and checksum:" << endl;
			      double bordel=0;
			      bordel= - migra[0];
			      for(int i=0;i<=maxdd;i++) { // up to maxdd=dimRes1-1
				     bordel+=2*migra[i];
				     simulpars<<i<<" "<<migra[i]<<" "<<bordel<<endl;
			      }
			  }
		  }
	  	deja=1;
	  }
	  break;
		case'f':/*geometric as FR coded it*/
		{if(total_disp) {
	  		dy_min=dx_min=-DX_max;
	   		dy_max=dx_max=DX_max;
		}
		else {
			dx_max=dimRes1-1;
	  		dx_min=-dx_max;
	  		dy_max=min(dimRes2-1,dx_max);
	  		dy_min=-dy_max; //obligatoire
	  	}
			//*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
			// NOUVELLE VERSION
			migra=ldvector(dx_max+1);
			new_disdis(dx_max,dy_max);// ceci et dy_max utilisÈ slmt pour cette distrib... ‡ gÈnÈraliser
			cum_fixex=ldvector(2*dx_max+2);//obsolete car maintenant deux tableau pour x et y
			cum_fixey=ldvector(2*dy_max+2);
			// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
			//
			/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
			 // ANCIENNE VERSION
			 dy_min=dx_min=-48;
			 dy_max=dx_max=48;
			 new_disdis(dx_max);
			 //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
			//	  mig=0.6;//(339.-sqrt(1353.))/336.;//(33801. - sqrt(135201.))/33798.;/*was 0.01 puis 0.25; 0.01 pour island model*/
			//	  kpar=(339.-sqrt(1353.))/336.;//(33801. - sqrt(135201.))/33798.; //0.2 0.5 0.75; 1! pour island model
			mig=Mig;
			kpar=GeoG;
			double maxcumul=0;
			int maxdd=max(dimRes1,dimRes2)-1;
			//int mindd=min(dimRes1,dimRes2)-1;
			migra[0]=(double) (1.0-mig); // ancienne version; absurd in 1D as this would reduce maxcumul (hence 2Nm) by migra[0]<1, which is silly.
			/* below :
			 (1) normalization so that the relationship between user input value for 'm' and some part of the algo is not too complicated
			 (2) computation of effective 2D 2Nm (the value which migraine should estimate) which is always complicated
			 Concerning (1) we could do no normalization at all, we would still know (2D) 2Nm and g. But for a bit of consistency we normalize so that
			 there is continuity with the island model with parameter m, and that the computed 2Nm is the input value in the 1D cas.
			 */
			// PROBLEME dx_max, dy_max peuvent etre > à taille réseau
			/*	            // ancienne version; dx_max was not a good idea!! But two 'errors' compensated each other...
			 for(int i=1;i<=dx_max;i++) norm+=(double) mig/2.0*(1.0-kpar)*pow(kpar,i-1.0); // should approach mig/2 particularly as dxmax was much larger than true lattice dim
			 for(int i=1;i<=dx_max;i++)
			 migra[i]=(double) mig/2.0*(1.0-kpar)*pow(kpar,i-1.0)/(2.0*norm+migra[0]); /* denom is slightly below one, so that
			 this slightly increases the m_i terms; migra[0] was unchanged, and m terms do not sum to one. Only their relative values matter,
			 but it's not clear what they mean by this code           */

			// NOUVELLE VERSION normalization of the geometric so that the axial (unbounded) m is the user declared m
			for(int i=1;i<=maxdd;i++) norm+= pow(kpar,i);
			for(int i=1;i<=maxdd;i++) // I leave dx_max here because variance and kurtosis computed later may be NaN otherwise (poor code!)
				migra[i]= mig/2.0*pow(kpar,i)/norm;
			for(int i=maxdd+1;i<=dx_max;i++) // variance and kurtosis computed later may be NaN otherwise (poor code!)
				migra[i]=0;
			//in this way the 1D migration terms (2*sum migra[i]) sum to mig and this plus migra[0] sums to 1. Transparent.
			// note that this works with kpar=1 but that kpar=1 does not lead to an island model unless mindd=0
			{// bloc local variables
                // computation of maximal 2D dispersal rate as in Migraine (affects only the info displayed below, not the simulations, as migra[] is already set)
	            int a=0;int b; double cumul;
				if (! simulparsWrittenBool) {
					simulpars<<"immigration rates in the different demes:"<<endl;
				}
				for(int xpos=0;xpos<dimRes1;xpos++) {
					for(int ypos=0;ypos<dimRes2;ypos++) {
						b=0;cumul=0;
						for(int xxpos=0;xxpos<dimRes1;xxpos++){
							for(int yypos=0;yypos<dimRes2;yypos++){
			                    if(a!=b) { // different pops
									// distances between a and b for absorbing boundaries:
									dx=abs(xpos-xxpos);
									dy=abs(ypos-yypos);
									cumul+=migra[dx]*migra[dy];
                                }
                                b++;
		                    }// yypos
						}// xxpos
						cumul/=(cumul+migra[0]*migra[0]); // migration terms over all terms => the real immigration proba into position (xpos,ypos)
						if (! simulparsWrittenBool) {
							simulpars<<cumul<<" ";
						}
						if (cumul>maxcumul) {
							maxcumul=cumul; // the maximal immigration proba into one position
							//    cout<<maxcumul;getchar();
						}
						a++;
					} // for ypos ...
					if (! simulparsWrittenBool) {
						simulpars<<endl;
					}
				} // for xpos ...
			}// bloc local variables
			if (! simulparsWrittenBool) {
				float Ds2;
				simulpars<<endl<<"Dispersal proba: "<<mig<<endl;
				simulpars<<"half axial Dispersal distribution: "<<endl;
				double bordel=0;
				for(int i=0;i<=maxdd;i++) {
					simulpars<<i<<" "<<migra[i]<<endl;
					bordel+=migra[i];
				}
				bordel=2*bordel-migra[0];
				simulpars<<"checksum of axial distribution: "<<bordel<<endl;
				simulpars<<"effective (2D) 2N_h m parameter accounting for absorbing boundaries as in Migraine: "<<2*ploidy*dens0*maxcumul<<endl;
				simulpars<<"Geometric param: "<<kpar<<endl;
				simulpars<<"axial sigma2 (no edges): "<<mig*(1.+kpar)/((1.-kpar)*(1.-kpar))<<endl;
				Ds2=ploidy*dens0*maxcumul*(1.+kpar)/((1.-kpar)*(1.-kpar)); //haploid
				simulpars<<"D sigma2 (no edges): "<<Ds2<<endl;
				simulpars<<"expected slope: "<<1./(2*Ds2)<<"(1D) or "<<1./(2*PI*Ds2)<<" (2D)."<<endl;
			}
			deja=1;
		}
			break;
	 case'S':/*Sichel and inverse gamma mixtures*/
	  {if(total_disp) {
		  if(true /*twoD_disp=="Simple1DProduct"*/) dy_min=dx_min=-DX_max; else {
			  cout << "The Sichel distribution is yet ready for Simple1Dproduct but not other forms of 2D dispersal. I must exit." << endl;
			  getchar();
			  exit(-1);
			  dy_min=dx_min=0;
		  }
	   		dy_max=dx_max=DX_max;
		}
		else {
			dx_max=dimRes1;
	  		dy_max=min(dimRes2,dx_max);
	  		if(true /*twoD_disp=="Simple1DProduct"*/) {
				dx_min=-dx_max;
				dy_min=-dy_max; //obligatoire
			} else dx_min=dy_min=0;
	  	}
		//*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		// NOUVELLE VERSION
		migra=ldvector(dx_max+1);
		new_disdis(dx_max,dy_max);// ceci et dy_max utilisÈ slmt pour cette distrib... ‡ gÈnÈraliser
		if(true /*twoD_disp=="Simple1DProduct"*/) {
			cum_fixex=ldvector(2*dx_max+2);//obsolete car maintenant deux tableau pour x et
			cum_fixey=ldvector(2*dy_max+2);
		} else cum_fixex=ldvector(dx_max+1);
		// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
		//
		/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		// AUTRE VERSION QUI DOIT SE COMPORTER COMME l'ANCIEN PROGRAMME
	  	dy_max=dx_max;
	  	dy_min=-dy_max; //obligatoire
		new_disdis(dx_max);//
		//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
		if (! simulparsWrittenBool) simulpars<<"(dx_max,dy_max)=("<<dx_max<<","<<dy_max<<")"<<endl ;
		//cout<<"apres new_disdis"<<flush;
		vector<long double>DispPars(4);
	  	vector<long double>costable;
		//DispPars[0]: Sichel gamma
	  	DispPars[0]=Sichel_Gamma;
	  				//-170./79.;
	  				//-2.;
	  				//-385./179.; //{3,20}
	  				//-1073./499.; //{5,20}
	  				//-41./8.; //{5,1}
	  				//-26873./12499.; //{25,20}
	  				//-726698./337999.; //{130,20}
	  				//-4223./844.;//-19433./8449.;//-12111./5633.;//-428./199.;
		//DispPars[1]: Sichel xi (or reciprocal gamma's kappa\sim xi omega)
	  	DispPars[1]=Sichel_Xi;
	  				//728./79.;
	  				//33800.;
	  				//3708./179.; //{3,20}
	  				//28700./499.; //{5,20}
	  				//825./4.; //{5,1}
	  				//17967500./12499.; //{25,20}
	  				//13138026200./337999.; //{130,20}
	  				//2855255./422.;//18562960./8449.;//10947820./5633.;//4580./199.; //
		//DispPars[2]: Sichel omega (or something negative for reciprocal gamma)
	  	DispPars[2]=Sichel_Omega;
	  				//-1; //
		/*DispPars[3]: island (total) dispersal rate: with proba DispPars[3]
		the propagule disperses somewhere (staying excluded)
		with proba DispPars[3] the propagule follows the Sichel dist.*/
	  	DispPars[3]=0.; //non charfunc fraction
	  	if (DispPars[0]>0) {cout<<"gamma arg. must be negative";getchar();exit(-1);}
		//what follows somehow assumes dim_reseau1=dim_reseau2 ?
		long int lPSON;
		if (EdgeEffect==0) {lPSON=dim_reseau1;} /*ca donne des transformÈes sur un habitat fermÈ
		=> Sicheltable[->lPSON]->Sicheltable[1]... pas terrible quand on veut calculer var et kurtosis;
		ou bien il faut que lPSON>2 dxmax...*/
		else {lPSON=100*dx_max;} // pour Èviter effet repliement
	  	long double DeuxPiSurNx=2.*PI/lPSON;
		costable.resize(lPSON);
		for(long int ii=0;ii<lPSON;ii++) costable[ii]=cos(DeuxPiSurNx*ii);
		Sicheltable=ldvector(lPSON/2+1);
	  	for(long int ii=0;ii<lPSON/2+1;ii++) {  //la valeur en lPSON/2+1 est utilisÈe
			Sicheltable[ii]=Sichelcharfunc((long double)(2.*PI*ii/lPSON),DispPars);
		//if (ii%500==0) {cout<<ii<<" "<<Sicheltable[ii]<<endl;getchar();}
			}
		//cout<<endl;
		//long double temp2=1.0;
		for(long int _dx=0;_dx<=dx_max;_dx++) {
			long double temp=1.0; // c'est charfn[0]
			for(long int ii=1;ii<lPSON/2;ii++) {
				//2 parce que les 2 termes sym de la transformÈe. mais c'est la valeur en |ii|
				temp+=2*Sicheltable[ii]*costable[(_dx*ii)%lPSON];
				//if ((_dx==3500) && (ii%500==0)) {cout<<ii<<" "<<temp<<endl;getchar();}
				}
			if(lPSON%2==0) temp+=Sicheltable[lPSON/2]*costable[(_dx%2)*lPSON/2];
			temp/=lPSON;
			//if ((_dx==3500)) {cout<<3500<<" "<<temp<<endl;getchar();}
			//if (_dx<10) cout<<_dx<<" "<<temp<<endl;//getchar();
			// fin circularfourierinv
			// island part:
			temp*=(1.-DispPars[3]);
			//cout<<_dx<<" "<<temp<<" in Sichel; "<<endl<<flush;
			if (_dx>0) temp+=DispPars[3]/lPSON;
			//cout<<DispPars[3]<<" "<<"la "<<endl<<flush;
			//cout<<DispPars[3]<<" "<<lPSON<<" "<<DispPars[3]/lPSON;//getchar();
			// numerical precision doesn't get better
			//if (temp<0.0000000001) temp=0;
			norm+=(_dx==0?1.:2.)*temp;
			// final copy
			//cout<<migra.size()<<" "<<"la "<<endl<<flush;
			migra[_dx]=temp;
			//cout<<_dx<<" "<<migra[_dx]<<endl;
		} // for _dx ...dx_max
	  	delete Sicheltable;
		for(int _dx=0;_dx<=dx_max;_dx++) migra[_dx]/=norm;
		if (!simulparsWrittenBool) {
		double sig2;
 	  	simulpars<<"non charfunc fraction: "<<DispPars[3]<<endl;
		//cout<<"non charfunc fraction: "<<DispPars[3]<<endl;
  	  	if (DispPars[2]<0) {
		  	simulpars<<"Inverse Gamma mixture: "<<endl ;
		  	simulpars<<"gamma="<<DispPars[0]<<endl ;
		  	simulpars<<"kappa (i.e. lim (omega xi))= "<<DispPars[1]<<endl ;
		  	sig2=-(1.-DispPars[3])*DispPars[1]/(2.*(1.+DispPars[0]));
  	  		}
  	  	else {
		  	simulpars<<"Sichel mixture:"<<endl ;
		  	simulpars<<"gamma="<<DispPars[0]<<endl ;
		  	simulpars<<"xi="<<DispPars[1]<<endl ;
		  	simulpars<<"omega="<<DispPars[2]<<endl ;
	      	sig2=-(1.-DispPars[3])*DispPars[1]*bessel_k(1.+DispPars[0],DispPars[2],1)
	      		/(2.*bessel_k(DispPars[0],DispPars[2],1));
  	  	}
      	simulpars<<"axial sigma2 (no edges): "<<sig2<<endl;
      	double Ds2=ploidy*dens0*sig2;
      	simulpars<<"D sigma2 (no edges): "<<Ds2<<endl;
      	simulpars<<"expected slope: "<<1./(2*Ds2)<<"(1D) or "<<1./(2*PI*Ds2)<<" (2D)."<<endl;
		}
	  deja=1;
	  }// end case S
	  break;
	}
  if((model_mig=='5')||(model_mig=='8'))
  {sig=kurt=0.0;for(long int i=3;i<=dx_max;i+=3) {
	  sig+=2*migra[i]*i*i;/*calcul sigma2*/ /**2 car aussi dx negatif*/
	}
  for(long int i=3;i<=dx_max;i+=3) {
	kurt+=2*migra[i]*i*i*i*i;/*calcul la kurtosis en x*/
	//if ((i%500==0)) {cout<<i<<" "<<kurt<<endl;getchar();}
	}
  }
  else
  {	sig=kurt=0.0;
	  int start;
	  if(twoD_disp!="1DProductWithoutm0") {
		  checksum=migra[0];
		  start=1;
	  } else start=0;
   	//cout << endl;
   	//for(long int i=0;i<=dx_max;i++)  cout << "migra[" << i << "]=" << migra[i] << endl;;
  	for(long int i=start;i<=dx_max;i++)  checksum+=2.*migra[i];
	if(cmp_nocase(twoD_disp,"1DProductWithoutm0")==0) checksum-=migra[0];
	//cout<<endl<<"checksum = "<<checksum<<endl;
	//getchar();
  	for(long int i=1;i<=dx_max;i++) {
		sig+=2.*(long double)(migra[i])*i*i;/*calcul sigma2*/ /**2 car aussi dx negatif*/
		//cout << "migra[" << i << "]=" <<migra[i] << " *i*i*2 =" << 2.*(long double)(migra[i])*i*i << endl;
		//cout << "\t-> sig=" << sig << endl;
	}

  	for(long int i=1;i<=dx_max;i++) {
		kurt+=2.*(long double)(migra[i])*i*i*i*i;/*calcul la kurtosis en x*/
		//if ((i%500==0)) {cout<<i<<" "<<migra[i]<<" "<<kurt<<endl;getchar();}
	}
  }
  //if(rep==1 && locus==1) {_gotoxy(0,3);cout<<"4th moment: "<<kurt<<endl;}
  kurt=kurt/(sig*sig)-3.;
  //NOTA  CHECKSUM differe de 1 pour modËle en Óle...
  if(rep==1 && locus==1) {
#ifdef GOTO
	  _gotoxy(0,10);
#endif
	  cout << endl;
  	cout<<"model_mig: "<<model_mig<<"; checksum: "<<checksum<<"; sigma2: "<<sig<<"; kurtosis: "<<kurt<<flush;
  	//for(i=0;i<=dx_max;i++) printf("migra(%d): %g \n",i,migra[i]);
  	//getchar();
  }
}//fin if deja
if (( ! simulparsWrittenBool) && model_mig!='g' && model_mig!='S' && model_mig!='a' && model_mig!='b') {
	 		float Ds2;
  	 		simulpars<<"axial Dispersal proba (Pareto param M): "<<mig<<endl;
	  		simulpars<<"Pareto param n: "<<kpar<<endl;
      		simulpars<<"axial sigma2 (no edges): "<<sig<<endl;
      		simulpars<<"axial kurtosis (no edges): "<<kurt<<endl;
      		Ds2=ploidy*dens0*sig;
      		simulpars<<"D sigma2 (no edges): "<<Ds2<<endl;
      		simulpars<<"expected slope : "<<1./(2*Ds2)<<"(1D) or "<<1./(2*PI*Ds2)<<" (2D)."<<endl;
      		simulpars<<"\nIf kurtosis appears wrong there may be many reasons\n";
  	        simulpars<<"It may be because the dispersal distribution is not\n";
            simulpars<<"computed with enough precision.";
            simulpars << endl;
		}
else if(( ! simulparsWrittenBool) && (model_mig=='a' || model_mig=='b'))
 {
	 		float Ds2;
  	 		simulpars<<"axial Dispersal proba : "<<mig<<endl;
      		simulpars<<"axial sigma2 (no edges): "<<sig<<endl;
      		simulpars<<"axial kurtosis (no edges): "<<kurt<<endl;
      		Ds2=ploidy*dens0*sig;
      		simulpars<<"D sigma2 (no edges): "<<Ds2<<endl;
      		simulpars<<"expected slope : "<<1./(2*Ds2)<<"(1D) or "<<1./(2*PI*Ds2)<<" (2D)."<<endl;
      		simulpars<<"\nIf kurtosis appears wrong there may be many reasons\n";
  	        simulpars<<"It may be because the dispersal distribution is not\n";
            simulpars<<"computed with enough precision.";
            simulpars << endl;
		}
simulparsWrittenBool=true;
}


/*****************/
//procedure principale de migration des noeuds restants

void new_disp()
{int originex,originey,taille1,taille2;
 /*int j,kk,ll,ii,iii;/* pour affichages*/

// compile les caractÈristiques de dispersion si debut ou changement
if((currentGeneration==1)||(currentGeneration==Gn1)||(currentGeneration==Gn2)||(currentGeneration==Gn3)) {
	model_mig=migra_tps(currentGeneration);//change les parametres demographiques si planifiÈ
	//if(!isinf(Gn1))
	if ((rep==1 && locus==1) // calcule tjrs la distrib ‡ la premiËre rÈpÈt... sauf s constant disp
				||(!const_disp)) {//et aux autres repetition et moments de changement si on lui dit qu'elle n'est pas constante
		if((currentGeneration!=1) && (!const_disp)) {//si on est dans un changement temporel, libere les vecteurs avant de les rÈallouer
  			free_ldvector(migra);
			free_ldvector(cum_fixex);
			free_ldvector(cum_fixey);
            if(fixe_global==0) {
#ifdef DEBUG
#else
                for(int i=sym+1; i>=0; i--) {
    		  		for(int j=sym+1/*2*dx_max+2*/; j>=0; j--) {
    					//cout << "New_disp free memory for tabdis[" << i << "][" << j << "].cum2" << ends;
                        for(int k=2*dx_max+1/*2*dy_max+2*/; k>=0; k--) {
                            delete[] tabdis[i][j].cum2[k];
                            //cout << "k=" << k << "; " << ends;
                        }
    					delete[] tabdis[i][j].cum2;
    				}
    				//cout << endl;
    				//cout << endl;
    			}
            }//end if(fixe_global)
#endif
  		}//end if((currentGeneration!=1) && (!const_disp))
		forw();// recalcule distr disp sauf si
	}//end if ((rep==1 && locus==1) || (!const_disp))
}//end if((currentGeneration==1)||(currentGeneration==Gn1)||(currentGeneration==Gn2)||(currentGeneration==Gn3)) {
else {
	translationx=translationy=0;//que quand changement de taille
}
// fin de compilation des caractÈristiques de dispersion si debut ou changement

//dispersion sur un reseau non homogËne
if(fixe==0)//si il existe une source d'hÈtÈrogÈnitÈ sur le reseau = noeuds vides ou zone; sinon dispfixe()
 {
//coord_origine=ivector(2);
  if(((currentGeneration==Gn3)||(currentGeneration==Gn2)||(currentGeneration==Gn1)||(currentGeneration==1))
     &&((rep==1)&&(locus==1))) // rempli les tableaux tabdisb et densite une fois pour toute les repets
	//OK si l'on a qu'un changement planifiÈ dans le temps... ‡ modifier sinon
	{if(Specific_Density_Designbool) getDensityFromFile();
        else for(int cc=1;cc<=dimRes1;cc++) {
                for(int dd=1;dd<=dimRes2;dd++) {
                    densite[cc][dd]=calcul_densite(cc,dd);
		            //printf("coordx:%d, coordy:%d, densite:%d\n",cc,dd,densite[cc][dd]);
		            //getchar();
		        }
	        }
	/*for(i=1;i<=dx_max;i++) printf("migra(%d): %f",i,migra[i]);
	getchar();*/
	//	cc=1;
	//_gotoxy(0,15);
  	//cout << "!! check this procedure : why is there still dim_reseau1,dim_reseau2 and not dimRes1, dimRes2" << endl;
	if(sym<sup(dimRes1,dimRes2)) taille1=taille2=sym;//si il y a une "symetrie"= une homogÈnÈitÈ au sein de l'hÈtÈrogÈnÈitÈ...
															//, on peut alors en tenir compte pour simplifer,
															//ex : avec des noeuds vides rÈpartis de facon homogene sur le reseau,
	 else {taille1=dimRes1;taille2=dimRes2;}//sinon on doit considÈrer chaque point du reseau comme spÈcifique...
    //cout << endl;
    //cout << "sym=" << sym << endl;
    //cout << "taille1=" << taille1 << endl;
    //cout << "taille2=" << taille1 << endl;
	for(int cc=1;cc<=taille1;cc++)
	 {for(int dd=1;dd<=taille2;dd++)
		{//gotoxy(1,15);
		//printf("noeud considÈrÈ: %d;%d ::::",cc,dd);
		//getchar();
		coord_origine[x]=cc;
		coord_origine[y]=dd;
		cumul1();//calcul le dÈmonimateur des probabilitÈ de migration
				// (pour chaque points du reseau si pas de symetrie ou pour chaque point de la "symÈtrie")
		cumul2();//calcul le nominatuer et donc finalise les probabilitÈ de migration
		/*for(int kk=dx_min;kk<=dx_max;kk++)
		  {for(int ll=dx_min;ll<=dy_max;ll++)
		  printf("x:%d;y:%d cumule de dx:%d;dy:%d = %f"
					,cc,dd,kk,ll,tabdis[cc][dd].cum2[kk+dx_max][ll+dy_max]);
		  getchar();
		  }*/
		}
	 }

	}//fin if(currentgeneration==Gn3...)
//cout<<"ola3"<<flush;

 //migration de chaque noeud restant
 for(int i=1;i<=nbre_noeud_restant;i++)
   {//fait la translation si necessaire
    originex=coord_origine[x]=int(SortieSupfnPtr2(coord_noeud[no_noeud_restant[i]][x],dimRes1,translationx));
	originey=coord_origine[y]=int(SortieSupfnPtr2(coord_noeud[no_noeud_restant[i]][y],dimRes2,translationy));
	//if(currentGeneration==1 || currentGeneration==Gn1 || currentGeneration==Gn2) {
   	    //printf("\n at generation %d coord_x=%d ;  coord_y=%d ",currentGeneration,originex,originey);
   	    //getchar();
   	//}

   	//dispersion en x et y en fonction de la place du neoud sur le reseau (=originex et originey), calcul dispxx et dispyy
	dispxy();
	coord_origine[x]+=dispxx;
	coord_origine[y]+=dispyy;

	//for(int iii=0;iii<=2*dy_max;iii++)
	//  {for(int ii=0;ii<=2*dx_max;ii++) {
    //     cout << "at (x=" << originex << ",y=" << originey << ") cum pour dx=" << (ii-dx_max) << ", dy=" << (iii-dy_max) << " est de " << tabdis[originex][originey].cum2[ii][iii] << endl;
	//	 //getchar();
	//	 }
	//  }

	//ajuste les nouvelle coordonnÈes en fonction des effets de bords
	coord_ori[no_noeud_restant[i]][x]=
		 int(SortieSupfnPtr1(coord_origine[x],dimRes1));
	coord_ori[no_noeud_restant[i]][x]=
		 int(SortieInffnPtr1(coord_ori[no_noeud_restant[i]][x],dimRes1));
	if(EdgeEffect==2)//pour reflection multiples
		{while((coord_ori[no_noeud_restant[i]][x]<=0)||(coord_ori[no_noeud_restant[i]][x]>dimRes1))
		 	{coord_ori[no_noeud_restant[i]][x]=int(SortieInffnPtr1(coord_ori[no_noeud_restant[i]][x],dimRes1));
		 	 coord_ori[no_noeud_restant[i]][x]=int(SortieSupfnPtr1(coord_ori[no_noeud_restant[i]][x],dimRes1));
		 	}
		}
	coord_ori[no_noeud_restant[i]][y]=
		 int(SortieSupfnPtr1(coord_origine[y],dimRes2));
	coord_ori[no_noeud_restant[i]][y]=
		 int(SortieInffnPtr1(coord_ori[no_noeud_restant[i]][y],dimRes2));
	if(EdgeEffect==2)//pour reflection multiples
		{while((coord_ori[no_noeud_restant[i]][y]<=0)||(coord_ori[no_noeud_restant[i]][y]>dimRes2))
			{coord_ori[no_noeud_restant[i]][y]=int(SortieInffnPtr1(coord_ori[no_noeud_restant[i]][y],dimRes2));
		 	 coord_ori[no_noeud_restant[i]][y]=int(SortieSupfnPtr1(coord_ori[no_noeud_restant[i]][y],dimRes2));
		 	}
		}
	//cout << "dispxx=" << dispxx << "->coord_origine[x]=" << coord_ori[no_noeud_restant[i]][x] << endl;
	//cout << "dispyy=" << dispyy << "->coord_origine[y]=" << coord_ori[no_noeud_restant[i]][y] << endl;
	//getchar();
	if(effective_disp)//calcul de la dispersion "efficace"
		 {effective[grande_dim+(int) (coord_ori[no_noeud_restant[i]][x]-originex)][x]++;
		  effective[grande_dim+(int) (coord_ori[no_noeud_restant[i]][y]-originey)][y]++;
		  if((coord_ori[no_noeud_restant[i]][x]-originex)!=0 || (coord_ori[no_noeud_restant[i]][y]-originey)!=0) effectiveImmigration[originex][originey]++;
		  cumulEffectiveImmigration[originex][originey]++;
		  //cout << "Effective[grande_dim=" << grande_dim << "+dx=" << (int) (coord_ori[no_noeud_restant[i]][x]-originex) << "]++" << endl;
		  //cout << "Effective[grande_dim=" << grande_dim << "+dy=" << (int) (coord_ori[no_noeud_restant[i]][y]-originey) << "]++" << endl;
		  //if((coord_ori[no_noeud_restant[i]][x]-originex)!=0 || (coord_ori[no_noeud_restant[i]][y]-originey)!=0) cout << "EffectiveImmigration[originex=" << originex << "][originey" << originey << "]++=" << effectiveImmigration[originex][originey] << endl;
		  //cout << "CumulEffectiveImmigration[originex=" << originex << "][originey" << originey << "]++=" << cumuylEffectiveImmigration[originex][originey] << endl;
		  //getchar();
		 }
   }
//fin de la migration de chaque noeud
//cout<<"ola4"<<flush;

 //attribut les nouvelles coordonnÈes
 for(int i=1;i<=nbre_noeud_restant;i++)
  {coord_noeud[no_noeud_restant[i]][x]=coord_ori[no_noeud_restant[i]][x];
   coord_noeud[no_noeud_restant[i]][y]=coord_ori[no_noeud_restant[i]][y];
  }
 //free_ivector(coord_origine);
 }
else {
     disp_fixe();
     }//si reseau totalement homogene = ni vide ni zone = beaucoup plus simple et beaucoup plus rapide!!
} // end new_disp();

/*****************/
//calcul le denominateur des probabilitÈ cumulÈes de migration quand reseau non homogene (= fixe=0)
//appelÈe par disp_new() uniquement quand necessaire (= quand il y a un changement dÈmo)
void cumul1()
{int coordx,coordy;

 denom=0.0;
 for(int ddy=dy_min;ddy<=dy_max;ddy++)
 {for(int ddx=dx_min;ddx<=dx_max;ddx++)
	{
	if(EdgeEffect!=1)
	 {coordx=int(SortieSupfnPtr1(coord_origine[x]+ddx,dimRes1));
	  coordx=int(SortieInffnPtr1(coordx,dimRes1));
	  if(EdgeEffect==2)//pour reflection multiples
       {while((coordx<=0)||(coordx>dimRes1))
		 {coordx=int(SortieInffnPtr1(coordx,dimRes1));
          coordx=int(SortieSupfnPtr1(coordx,dimRes1));
         }
       }

	  coordy=int(SortieSupfnPtr1(coord_origine[y]+ddy,dimRes2));
	  coordy=int(SortieInffnPtr1(coordy,dimRes2));
	  if(EdgeEffect==2)//pour reflection multiples
       {while((coordy<=0)||(coordy>dimRes2))
		 {coordy=int(SortieInffnPtr1(coordy,dimRes2));
          coordy=int(SortieSupfnPtr1(coordy,dimRes2));
         }
       }

	  denom+= ((double) densite[coordx][coordy]*migra[abs(ddx)]*migra[abs(ddy)]);
	 }
	 else {
        if(((coord_origine[x]+ddx)>0)&&((coord_origine[x]+ddx)<=dimRes1)&&((coord_origine[y]+ddy)>0)&&((coord_origine[y]+ddy)<=dimRes2)) {
	     //cout << endl;
	     //cout << endl;
         //cout << "cumul1->(coord_origine[x]=" << coord_origine[x] << "+ddx=" << ddx << ")=" << coord_origine[x]+ddx << endl;
	     //cout << "cumul1->(coord_origine[y]=" << coord_origine[y] << "+ddy=" << ddy << ")=" << coord_origine[y]+ddy << endl;
	     //cout << "cumul1->migra[abs(ddx)=" << abs(ddx) << "]=" << migra[abs(ddx)] << endl;
	     //cout << "cumul1->migra[abs(ddy)=" << abs(ddy) << "]=" << migra[abs(ddy)] << endl;
	     //cout << "cumul1->densite[][]=" << densite[coord_origine[x]+ddx][coord_origine[y]+ddy] << endl;
	     denom+= ((double) densite[coord_origine[x]+ddx][coord_origine[y]+ddy]*migra[abs(ddx)]*migra[abs(ddy)]);
	     //cout << "cumul1->denom+" << ((double) densite[coord_origine[x]+ddx][coord_origine[y]+ddy]*migra[abs(ddx)]*migra[abs(ddy)]) << "->" << denom << endl;
       }
      }

	}
 }
}/*fin cumul1*/

/*****************/
//calcul le numerateur et finalise les probabilitÈ cumulÈes de migration pour chaque noeud du reseau ou pour une "symetrie" quand reseau non homogene (= fixe=0)
//appelÈe par new_disp() uniquement quand c'est necessaire (= quand il y a un changement dÈmo)
void cumul2()
{double numer,frac;
 int coordx,coordy;

 numer=0.0;
 for(int ddy=dy_min;ddy<=dy_max;ddy++)
  {for(int ddx=dx_min;ddx<=dx_max;ddx++)
	 {
	 if(EdgeEffect!=1)
	 {coordx=int(SortieSupfnPtr1(coord_origine[x]+ddx,dimRes1));
	  coordx=int(SortieInffnPtr1(coordx,dimRes1));
	  if(EdgeEffect==2)//pour reflection multiples
       {while((coordx<=0)||(coordx>dimRes1))
		 {coordx=int(SortieInffnPtr1(coordx,dimRes1));
          coordx=int(SortieSupfnPtr1(coordx,dimRes1));
         }
       }
	  coordy=int(SortieSupfnPtr1(coord_origine[y]+ddy,dimRes2));
	  coordy=int(SortieInffnPtr1(coordy,dimRes2));
	  if(EdgeEffect==2)//pour reflection multiples
       {while((coordy<=0)||(coordy>dimRes2))
		 {coordy=int(SortieInffnPtr1(coordy,dimRes2));
		  coordy=int(SortieSupfnPtr1(coordy,dimRes2));
		 }
       }
	  numer+= ((double) densite[coordx][coordy]*migra[abs(ddx)]*migra[abs(ddy)]);
	  if(denom!=0.0) frac= ((double) numer/denom);
	   else if(numer!=0.0) {printf("probleme : denom=0,numer=%f \n	the program must terminate",numer);getchar();exit(1);}
			 else frac=0.0;
   	  tabdis[coord_origine[x]][coord_origine[y]].cum2[ddx+dx_max][ddy+dy_max]=frac;
	 }
	 else
	  {if(((coord_origine[x]+ddx)>0)&&((coord_origine[x]+ddx)<=dimRes1)&&((coord_origine[y]+ddy)>0)&&((coord_origine[y]+ddy)<=dimRes2))
	    {numer+= ((double) densite[coord_origine[x]+ddx][coord_origine[y]+ddy]*migra[abs(ddx)]*migra[abs(ddy)]);
	     if(denom!=0.0) frac= ((double) numer/denom);
	       else if(numer!=0.0) {printf("probleme : denom=0,numer=%f \n	the program must terminate",numer);getchar();exit(1);}
			     else frac=0.0;
		 //cout << endl;
         //cout << "cumul2->(coord_origine[x]=" << coord_origine[x] << "+ddx=" << ddx << ")=" << coord_origine[x]+ddx << endl;
	     //cout << "cumul2->(coord_origine[y]=" << coord_origine[y] << "+ddy=" << ddy << ")=" << coord_origine[y]+ddy << endl;
	     //cout << "cumul2->migra[abs(ddx)=" << abs(ddx) << "]=" << migra[abs(ddx)] << endl;
	     //cout << "cumul2->migra[abs(ddy)=" << abs(ddy) << "]=" << migra[abs(ddy)] << endl;
	     //cout << "cumul2->densite[][]=" << densite[coord_origine[x]+ddx][coord_origine[y]+ddy] << endl;
	     //cout << "denom=" << denom << endl;
	     //cout << "numer+" << ((double) densite[coord_origine[x]+ddx][coord_origine[y]+ddy]*migra[abs(ddx)]*migra[abs(ddy)]) << "->" << numer << endl;
	     //cout << "frac=" << frac << endl;
         tabdis[coord_origine[x]][coord_origine[y]].cum2[ddx+dx_max][ddy+dy_max]=frac;
	    }
	   else tabdis[coord_origine[x]][coord_origine[y]].cum2[ddx+dx_max][ddy+dy_max]=0.0;
	  }
	 }
 }
}/*fin cumul2*/

/********************/
//for Specific_Density_Designbool : get density for each point of the lattice from file DensityMatrix.txt
int getDensityFromFile() {
    int pos;

ifstream inFile(SpecificDensityFilename.c_str(),ios::in);
if(!inFile.is_open()) {
	cout << "Unable to open file "<<SpecificDensityFilename << " in read_settings_file();" << endl;
	cerr << "Unable to open file "<<SpecificDensityFilename << " in read_settings_file();" << endl;
	cout << "Abnormal termination...Press any key to close the window..." << endl;
	cerr << "Abnormal termination...Press any key to close the window..." << endl;
	getchar();
	exit(-1);
	}
else {
    string locstring;
	int i=1;
	do {
        if(i>dimRes2G0) {
			cout << endl << endl << endl;
			cout << "Problem with column dimension in DensityMatrix.txt" << endl;
			cout << "There are " << i<< " rows in " << SpecificDensityFilename << endl;
			cout << "But Y dimension of the lattice is " << dimRes2G0 << endl;
			cout << "Programm aborted" << endl;
			getchar();
			exit(-1);
        }
        getline(inFile,locstring);
		if(locstring.length()==0) break;
		int j=1;
		do {
			if(j>dimRes1G0) {
				  cout << endl << endl << endl;
                  cout << "Problem with row dimension in DensityMatrix.txt" << endl;
    			  cout << "There are " << j << " column in " << SpecificDensityFilename << endl;
    			  cout << "But X dimension of the lattice is " << dimRes1G0 << endl;
    			  cout << "Programm aborted" << endl;
    			  getchar();
    			  exit(-1);
            }
            while((locstring[0]==' ')||(locstring[0]=='\t')) {locstring.erase(0,1);}//vire les blancs
			pos=std::min(locstring.find(' '),std::min(locstring.find('\t'),locstring.length()));
			densite[j][i]=atoi(locstring.substr(0,pos).c_str());
			//cout << "densite[" << j << "][" << i << "]" << densite[j][i] << endl;
			//getchar();
			locstring.erase(0,pos);
			j++;
			}while((locstring.length()>0)&&(locstring[0]!=';')&&(locstring[0]!='\0'));

		if((j-1)!=dimRes1G0) {
			cout << endl << endl << endl;
			cout << "Problem with row dimension in DensityMatrix.txt" << endl;
			cout << "There are " << j-1 << " column in " << SpecificDensityFilename << endl;
			cout << "But X dimension of the lattice is " << dimRes1G0 << endl;
			cout << "Programm aborted" << endl;
			getchar();
			exit(-1);
			}
		i++;
		}while(!inFile.eof());

		inFile.close();

	    if((i-1)!=dimRes2G0) {
		    cout << endl << endl << endl;
			cout << "Problem with column dimension in DensityMatrix.txt" << endl;
			cout << "There are " << i-1 << " rows in " << SpecificDensityFilename << endl;
			cout << "But Y dimension of the lattice is " << dimRes2G0 << endl;
			cout << "Programm aborted" << endl;
			getchar();
			exit(-1);
		}

}//else = file open

if(Specific_Sample_Designbool) {
    for(int i=0;i<Spec_SampleSize;i++) if(densite[Spec_Sample_Coord[x][i]][Spec_Sample_Coord[y][i]]==0) {
        cout << endl << endl << endl;
		cout<<"Deme (x=" << Spec_Sample_Coord[x][i] << ")(y=" << Spec_Sample_Coord[y][i] << ") is present in Specific_Sample_Designbool"<<endl;
	    cout<<"But density at this point is " << densite[Spec_Sample_Coord[x][i]][Spec_Sample_Coord[y][i]] << ";"<<endl;
	    cout<<"Be carrefull that both specific designs are compatible.\nProgram aborted"<<endl;
	    getchar();
	    exit(-1);
    }
}
if(!Specific_Sample_Designbool) {
    cout << endl << endl << endl;
	cout<<"Specific_Density_Designbool=true is usually used in combination with Specific_Sample_Designbool=true in " << SettingsFilename <<  " :"<<endl;
	cout<<"If it is not the case, be carrefull that both designs are compatible"<<endl;
	cout<<"Press any key to start simulations"<<endl;
	getchar();
}
return(0);
}
/********************/


/*****************/
//calcul la densitÈ en un point du reseau selon le model dÈmo
int calcul_densite(int coordx,int coordy)
{int densite_locale;//variable locale de la densite
 int vide_locale;//variable locale de vide

if(zone==1)
  {if((xmin_zone<=coordx)&&(coordx<=xmax_zone)&&(ymin_zone<=coordy)&&(coordy<=ymax_zone))
    {if(vide_zone==1) return(dens_zone);
      else {densite_locale=dens_zone;vide_locale=vide_zone;}
    }
    else {densite_locale=dens;vide_locale=vide;}
  }
 else {densite_locale=dens;vide_locale=vide;}

if(vide_locale!=1)
  {if((fmod(double(coordx),double(vide_locale))==0.0)&&(fmod(double(coordy),double(vide))==0.0)) return(densite_locale);
     else return(0);
  }
 else return(densite_locale);

}/*fin calcul densite*/

/*****************/
//donne la place d'un noeud (chaque coordonnÈe indÈpendament) dans une "symÈtrie" (ex 1, 2, ou 3 si sym=3)
int decim_tabdis(int coord)
{
if(sym<sup(dim_reseau1,dim_reseau2)){
	for(int i=sym;i>=1;i--) if(fmod(double(coord),double(i))==0.0) {
        //cout << "decim_tabdis(" << coord << ") returns " << i << endl;
        return(i);
    }
	return(0);
	}
 else return(coord);
}

/*****************/
//calcul dispxx et dispyy, les distance de migration quand le reseau est non homogene (= fixe=0) sinon c'est dispx()
void dispxy()
{double alea1;
 int ddx,ddy;

alea1=alea();
ddy=0;
//cout << "decim_tabdis(coord_origine[x])="  << decim_tabdis(coord_origine[x]) << "; decim_tabdis(coord_origine[y])="  << decim_tabdis(coord_origine[y]) << endl;
//cout << "2*dx_max="  << 2*dx_max << "; ddy+dy_max="  << ddy+dy_max << "; 2*dx_max="  << 2*dx_max << "; ddy-1+dy_max="  << ddy-1+dy_max << endl;
//cout << endl;
//fflush(stdout);
if((alea1<tabdis[decim_tabdis(coord_origine[x])][decim_tabdis(coord_origine[y])]
	  .cum2[2*dx_max][ddy+dy_max])&&(alea1>tabdis[decim_tabdis(coord_origine[x])]
	  [decim_tabdis(coord_origine[y])].cum2[2*dx_max][ddy-1+dy_max]))
		 {dy=0;goto fin1;}
if(alea1>tabdis[decim_tabdis(coord_origine[x])][decim_tabdis(coord_origine[y])]
	  .cum2[2*dx_max][ddy+dy_max]) goto fin1plus;
if(alea1<tabdis[decim_tabdis(coord_origine[x])][decim_tabdis(coord_origine[y])]
	  .cum2[2*dx_max][ddy-1+dy_max]) goto fin1moins;
fin1moins:
if(alea1<tabdis[decim_tabdis(coord_origine[x])][decim_tabdis(coord_origine[y])]
	  .cum2[2*dx_max][0]) {dy=dy_min;goto fin1;}
for(ddy=-1;ddy>dy_min;ddy--)
{/*printf("tabdis[%d][%d].cum2[%d][%d]= %f\n"
			  ,decim_tabdis(coord_origine[x]),decim_tabdis(coord_origine[y])
			  ,2*dx_max,ddy+dy_max,tabdis[decim_tabdis(coord_origine[x])]
				 [decim_tabdis(coord_origine[y])].cum2[2*dx_max][ddy+dy_max]);
 getchar();*/
 if(alea1>tabdis[decim_tabdis(coord_origine[x])][decim_tabdis(coord_origine[y])]
	  .cum2[2*dx_max][ddy-1+dy_max]) {dy=ddy;goto fin1;}
}
fin1plus:
for(ddy=1;ddy<=dy_max;ddy++)
{/*printf("tabdis[%d][%d].cum2[%d][%d]= %f\n"
			  ,decim_tabdis(coord_origine[x]),decim_tabdis(coord_origine[y])
			  ,2*dx_max,ddy+dy_max,tabdis[decim_tabdis(coord_origine[x])]
				 [decim_tabdis(coord_origine[y])].cum2[2*dx_max][ddy+dy_max]);
 getchar();*/
 if(alea1<tabdis[decim_tabdis(coord_origine[x])][decim_tabdis(coord_origine[y])]
	  .cum2[2*dx_max][ddy+dy_max]) {dy=ddy;goto fin1;}
}
fin1:
ddx=0;
if((alea1<tabdis[decim_tabdis(coord_origine[x])]
		  [decim_tabdis(coord_origine[y])].cum2[ddx+dx_max][dy+dy_max])
  &&(alea1>tabdis[decim_tabdis(coord_origine[x])]
		  [decim_tabdis(coord_origine[y])].cum2[ddx-1+dx_max][dy+dy_max]))
		 {dx=0;goto fin2;}
if(alea1>tabdis[decim_tabdis(coord_origine[x])][decim_tabdis(coord_origine[y])]
			.cum2[ddx+dx_max][dy+dy_max]) goto fin2plus;
if(alea1<tabdis[decim_tabdis(coord_origine[x])][decim_tabdis(coord_origine[y])]
			.cum2[ddx-1+dx_max][dy+dy_max]) goto fin2moins;
fin2moins:
if(alea1<tabdis[decim_tabdis(coord_origine[x])][decim_tabdis(coord_origine[y])]
			 .cum2[0][dy+dy_max]) {dx=dx_min;goto fin2;}

for(ddx=-1;ddx>dx_min;ddx--)
{/*printf("tabdis[%d][%d].cum2[%d][%d]= %f\n"
			  ,decim_tabdis(coord_origine[x]),decim_tabdis(coord_origine[y])
			  ,2*dx_max,ddy+dy_max,tabdis[decim_tabdis(coord_origine[x])]
				 [decim_tabdis(coord_origine[y])].cum2[2*dx_max][ddy+dy_max]);
 getchar();*/
 if(alea1>tabdis[decim_tabdis(coord_origine[x])][decim_tabdis(coord_origine[y])]
			 .cum2[ddx-1+dx_max][dy+dy_max]) {dx=ddx;goto fin2;}
}
fin2plus:
for(ddx=1;ddx<=dx_max;ddx++)
{/*printf("tabdis[%d][%d].cum2[%d][%d]= %f\n"
			  ,decim_tabdis(coord_origine[x]),decim_tabdis(coord_origine[y])
			  ,2*dx_max,ddy+dy_max,tabdis[decim_tabdis(coord_origine[x])]
				 [decim_tabdis(coord_origine[y])].cum2[2*dx_max][ddy+dy_max]);
 getchar();*/
 if(alea1<tabdis[decim_tabdis(coord_origine[x])][decim_tabdis(coord_origine[y])]
			 .cum2[ddx+dx_max][dy+dy_max]) {dx=ddx;goto fin2;}
}
fin2:
//printf("\n aleat %f",alea1);
//printf(";dx=  %d",dx);
//printf(";dy=  %d",dy);
//getchar();
dispxx=dx;
dispyy=dy;
} /*fin dispxy*/


/*****************/
//procÈdure principale de migration quand le reseau est homogene
//appellÈe par disp_new() si fixe!=0
void disp_fixe() {
	int i,disp,dispx=0,dispy=0;
	int originex,originey;
	double aleat1;

//lance le calcul des probabilitÈ cumulÈs de migration si ils ne sont pas deja calculÈ
if(deja1==0) {
 for(i=dx_min;i<=dx_max;i++) cumul_fixex(i);
 if(dimRes2/vide>1 && (cmp_nocase(twoD_disp,"Simple1DProduct")==0 || cmp_nocase(twoD_disp,"1DProductWithoutm0")==0)) for(i=dy_min;i<=dy_max;i++) cumul_fixey(i);
 deja1=1;
}

//coord_origine=ivector(2);

//migration de chaque noeud restant
for (i=1;i<=nbre_noeud_restant;i++) {//determination de l'origine, translation si necessaire
	//getchar();
	//cout << "noeud " << i << ":" <<  coord_noeud[no_noeud_restant[i]][x] << " , " << coord_noeud[no_noeud_restant[i]][y] << endl;

	 if(EdgeEffect==1) {//si bord dispersifs/absorbants avec masse de probabilité "inateignable" reportée sur toute la distribution de dispersion
						// = on migre (ou non) jusqu'a ce que l'on se retrouve dans le reseau
		 originex=coord_origine[x]=int(SortieSupfnPtr2(coord_noeud[no_noeud_restant[i]][x],dimRes1,translationx));
		 originey=coord_origine[y]=int(SortieSupfnPtr2(coord_noeud[no_noeud_restant[i]][y],dimRes2,translationy));

		if(cmp_nocase(twoD_disp,"Simple1DProduct")==0) {
			 //migration jsuq'a ce que l'on soit dans la pop pour bords dispersifs
			 do {coord_origine[x]=originex; coord_origine[x]+=dispx_fixe();}while((coord_origine[x]>dimRes1)||(coord_origine[x]<=0));
				  /*if(dimRes2/vide!=1)*/
			  do {coord_origine[y]=originey; coord_origine[y]+=dispy_fixe();} while((coord_origine[y]>dimRes2)||(coord_origine[y]<=0));
		} else if(cmp_nocase(twoD_disp,"1DProductWithoutm0")==0) {
			  aleat1=alea();
			  if(aleat1>migra0) {
				  //cout << "mig" << endl;
				  do {
					  if(dimRes2/vide>1) do {dispx=dispx_fixe();dispy=dispy_fixe();} while(dispx==0 && dispy==0);
					  else do {dispx=dispx_fixe();} while(dispx==0);
					  //cout << "dispx=" << dispx << "dispy=" << dispy << endl;
					  //cin.get();
					  coord_origine[x]=originex;
					  coord_origine[x]+=dispx;
				      coord_origine[y]=originey;
					  coord_origine[y]+=dispy;
				  } while((coord_origine[x]>dimRes1)||(coord_origine[x]<=0)||(coord_origine[y]>dimRes2)||(coord_origine[y]<=0));
			  } //else cout << "no mig;" << endl;
		} else if(cmp_nocase(twoD_disp,"X+YDistProb")==0) {
			do {disp=abs(dispx_fixe());
			    if(disp>0) {
			      if(dimRes2/vide>1) dispx= (int) floor(alea()*(disp+1));
				  else dispx=disp;
					if(dispx>0) {
			            if(alea()>0.5) dispx=-dispx;
				        coord_origine[x]=originex;
				        coord_origine[x]+=dispx;
			        }
				    dispy=disp-abs(dispx);
			        if(dispy>0) {
					     if(alea()>0.5) dispy=-dispy;
						 coord_origine[y]=originey;
				         coord_origine[y]+=dispy;
			        }
				}
			} while((coord_origine[y]+dispy>dimRes2)||(coord_origine[y]+dispy<=0)||(coord_origine[x]+dispx>dimRes1)||(coord_origine[x]+dispx<=0));
		}
		coord_ori[no_noeud_restant[i]][x]=coord_origine[x];
		coord_ori[no_noeud_restant[i]][y]=coord_origine[y];
	 } else if(EdgeEffect==3) {//si bord dispersifs/absorbants avec masse de probabilité "inatteignable" reporté sur m0
								// = on migre une fois, si l'on est en dehors du reseau alors on reste sur place.
		 //cout << "Edge Effects==3" << endl;
		 originex=coord_origine[x]=int(SortieSupfnPtr2(coord_noeud[no_noeud_restant[i]][x],dimRes1,translationx));
		 originey=coord_origine[y]=int(SortieSupfnPtr2(coord_noeud[no_noeud_restant[i]][y],dimRes2,translationy));

	   if(cmp_nocase(twoD_disp,"Simple1DProduct")==0) {
			dispx=dispx_fixe();
			if(!((coord_origine[x]+dispx>dimRes1)||(coord_origine[x]+dispx<=0))) coord_origine[x]+=dispx;
			/*if(dimRes2/vide!=1)*/
			dispy=dispy_fixe();
		   if(!((coord_origine[y]+dispy>dimRes2)||(coord_origine[y]+dispy<=0))) coord_origine[y]+=dispy;
	   } else if(cmp_nocase(twoD_disp,"1DProductWithoutm0")==0) {
		   aleat1=alea();
		   if(aleat1>migra0) {
			   if(dimRes2/vide>1) do {dispx=dispx_fixe();dispy=dispy_fixe();} while(dispx==0 && dispy==0);
			   else do {dispx=dispx_fixe();} while(dispx==0);
			   if(!((coord_origine[x]+dispx>dimRes1)||(coord_origine[x]+dispx<=0)
					||(coord_origine[y]+dispy>dimRes2)||(coord_origine[y]+dispy<=0))) {coord_origine[x]+=dispx;coord_origine[y]+=dispy;}
		   } //else cout << "no mig;" << endl;
	   } else if(cmp_nocase(twoD_disp,"X+YDistProb")==0) {
		   disp=abs(dispx_fixe());
		   //cout << "disp =" << disp << endl;
		   if(disp>0) {
			   if(dimRes2/vide>1) dispx= (int) floor(alea()*(disp+1));
			   else dispx=disp;
			   if(dispx>0) if(alea()>0.5) dispx=-dispx;

			   dispy=disp-abs(dispx);
				if(dispy>0) if(alea()>0.5) dispy=-dispy;
			   //cout << "dispx dispy = " << dispx << dispy << endl;

			   if(!((coord_origine[y]+dispy>dimRes2)||(coord_origine[y]+dispy<=0)||(coord_origine[x]+dispx>dimRes1)||(coord_origine[x]+dispx<=0))) {coord_origine[x]+=dispx;coord_origine[y]+=dispy;}
		   }
	   }

    coord_ori[no_noeud_restant[i]][x]=coord_origine[x];
    coord_ori[no_noeud_restant[i]][y]=coord_origine[y];
	//cout << "apres disp : " <<  coord_ori[no_noeud_restant[i]][x] << " , " << coord_ori[no_noeud_restant[i]][y] << endl;

	} else {//si torre ou reflectifs//pour remettre les individus a la bonne place sur le reseau quand reduction de surface
     originex=int(SortieSupfnPtr2(coord_noeud[no_noeud_restant[i]][x],dimRes1,translationx));
     coord_origine[x]=int(SortieSupfnPtr2(coord_noeud[no_noeud_restant[i]][x],dimRes1,translationx));
     originey=int(SortieSupfnPtr2(coord_noeud[no_noeud_restant[i]][y],dimRes2,translationy));
     coord_origine[y]=int(SortieSupfnPtr2(coord_noeud[no_noeud_restant[i]][y],dimRes2,translationy));
     /*if(currentGeneration==1 || currentGeneration==Gn1 || currentGeneration==Gn2)
	   	{printf("\n at genaration %d coord_x=%d ;  coord_y=%d ",Gn,originex,originey);
	   	 getchar();
	   	}*/
     if(originex>dimRes1 || originey>dimRes2)
	   	{printf("\n problem : at generation %ld originex=%d ;  originey=%d ",currentGeneration,originex,originey);
	   	 printf("\n coord_noeud_x=%d ;  coord_noeud_y=%d ",coord_noeud[no_noeud_restant[i]][x],coord_noeud[no_noeud_restant[i]][y]);
	   	 fflush(stdout);
	   	 getchar();
		}
	 //migration en x et en y
	 //dispx=dispx_fixe();
	 //dispy=dispy_fixe();
	 //cout << endl << "dispx=" << dispx << flush;
	 //cout << "; dispy=" << dispy << flush;
	 //getchar();
	if(cmp_nocase(twoD_disp,"Simple1DProduct")==0) {
		coord_origine[x]+=dispx_fixe();
		/*if(dimRes2/vide!=1)*/ coord_origine[y]+=dispy_fixe();
		} else if(cmp_nocase(twoD_disp,"1DProductWithoutm0")==0) {
			aleat1=alea();
			cout << "aleat=" << aleat1 << endl;
			if(aleat1>migra0) {
				if(dimRes2/vide>1) do {dispx=dispx_fixe();dispy=dispy_fixe();} while(dispx==0 && dispy==0);
				else do {dispx=dispx_fixe();} while(dispx==0);
				coord_origine[x]+=dispx;
				coord_origine[y]+=dispy;
			} //else cout << "no mig;" << endl;
		} else if(cmp_nocase(twoD_disp,"X+YDistProb")==0) {
			disp=abs(dispx_fixe());
			if(disp>0) {
				if(dimRes2/vide>1) dispx=(int) floor(alea()*(disp+1));
				else dispx=disp;
				if(dispx>0) if(alea()>0.5) dispx=-dispx;

				dispy=disp-abs(dispx);
				if(dispy>0) if(alea()>0.5) dispy=-dispy;
				//cout << "dispx dispy = " << dispx << dispy << endl;
			}
			coord_origine[x]+=dispx;
			coord_origine[y]+=dispy;
		}

     //sortie pour x
     //if((coord_origine[x]<=0)||(coord_origine[x]>dim_reseau1)) printf("\n coord X avant=%d",coord_origine[x]);
     coord_ori[no_noeud_restant[i]][x]=int(SortieSupfnPtr1(coord_origine[x],dimRes1));
     coord_ori[no_noeud_restant[i]][x]=int(SortieInffnPtr1(coord_ori[no_noeud_restant[i]][x],dimRes1));
     if(EdgeEffect==2)//pour reflection multiples
       {while((coord_ori[no_noeud_restant[i]][x]<=0)||(coord_ori[no_noeud_restant[i]][x]>dimRes1))
		 {coord_ori[no_noeud_restant[i]][x]=int(SortieInffnPtr1(coord_ori[no_noeud_restant[i]][x],dimRes1));
          coord_ori[no_noeud_restant[i]][x]=int(SortieSupfnPtr1(coord_ori[no_noeud_restant[i]][x],dimRes1));
         }
       }
     //
     //if((coord_origine[x]<=0)||(coord_origine[x]>dim_reseau1)) printf("coord X apres=%d",coord_ori[no_noeud_restant[i]][x]);
     //printf("transfo donne=%d",(int) ((coord_ori[no_noeud_restant[i]][x])-(floor(((double) coord_ori[no_noeud_restant[i]][x]/(double) dim_reseau1)-(1E-5))*dim_reseau1)));
     //getchar();

     //sortie pour y
     //if((coord_origine[y]<=0)||(coord_origine[y]>dim_reseau2)) printf("\n coord Y avant=%d",coord_origine[y]);
     coord_ori[no_noeud_restant[i]][y]=int(SortieSupfnPtr1(coord_origine[y],dimRes2));
     coord_ori[no_noeud_restant[i]][y]=int(SortieInffnPtr1(coord_ori[no_noeud_restant[i]][y],dimRes2));
     if(EdgeEffect==2)//pour reflection multiples
       {while((coord_ori[no_noeud_restant[i]][y]<=0)||(coord_ori[no_noeud_restant[i]][y]>dimRes2))
		 {coord_ori[no_noeud_restant[i]][y]=int(SortieInffnPtr1(coord_ori[no_noeud_restant[i]][y],dimRes2));
          coord_ori[no_noeud_restant[i]][y]=int(SortieSupfnPtr1(coord_ori[no_noeud_restant[i]][y],dimRes2));
         }
	}
     //if((coord_origine[y]<=0)||(coord_origine[y]>dim_reseau2)) {printf("coord Y apres=%d",coord_ori[no_noeud_restant[i]][y]);getchar();}
   }
  if(effective_disp)//calcul de la dispersion "efficace"
     {effective[grande_dim+ (coord_ori[no_noeud_restant[i]][x]-originex)][x]++;
      effective[grande_dim+ (coord_ori[no_noeud_restant[i]][y]-originey)][y]++;
	  if((coord_ori[no_noeud_restant[i]][x]-originex)!=0 || (coord_ori[no_noeud_restant[i]][y]-originey)!=0) effectiveImmigration[originex][originey]++;
	  cumulEffectiveImmigration[originex][originey]++;
      /*if((coord_ori[no_noeud_restant[i]][x]-originex>dx_max)||(coord_ori[no_noeud_restant[i]][y]-originey>dy_max)) {
      	printf("\n ****CurrentGn=%d,no_noeud_restant=%d",currentGeneration,no_noeud_restant[i]);
      	printf("\noriginex=%d new coordx=%d",originex,coord_ori[no_noeud_restant[i]][x]);
      	printf("\noriginey=%d new coordy=%d",originey,coord_ori[no_noeud_restant[i]][y]);
      	getchar();
      	}*/
      //printf("\n \n effective[%d]X=%lld ",grande_dim+ (coord_ori[no_noeud_restant[i]][x]-originex),effective[grande_dim+ (coord_ori[no_noeud_restant[i]][x]-originex)][x]);
      //printf("\n effective[%d]Y=%lld",grande_dim+ (coord_ori[no_noeud_restant[i]][y]-originey),effective[grande_dim+ (coord_ori[no_noeud_restant[i]][y]-originey)][y]);
	  //if((coord_ori[no_noeud_restant[i]][x]-originex)!=0 || (coord_ori[no_noeud_restant[i]][y]-originey)!=0) cout << "EffectiveImmigration[originex=" << originex << "][originey" << originey << "]++=" << effectiveImmigration[originex][originey] << endl;
      //cout << "cumulEffectiveImmigration[originex=" << originex << "][originey" << originey << "]++=" << cumulEffectiveImmigration[originex][originey] << endl;
	  //getchar();

     }
//cout << "apres disp : " <<  coord_ori[no_noeud_restant[i]][x] << " , " << coord_ori[no_noeud_restant[i]][y] << endl;
 }//fin boucle sur nbre noeud restant


for(i=1;i<=nbre_noeud_restant;i++)
 {coord_noeud[no_noeud_restant[i]][x]=coord_ori[no_noeud_restant[i]][x];
  coord_noeud[no_noeud_restant[i]][y]=coord_ori[no_noeud_restant[i]][y];
 }

//free_ivector(coord_origine);
} //ca doit etre la fin de disp fixe....

/*****************/
//calcul les probailitÈs cumulÈes de migration pour reseau homogene (= fixe!=0)
void cumul_fixex(int k)
{int ddx;
 double numer2,denom2,frac2;

//pour x
denom2=0.0;
numer2=0.0;
//cum_fixex.resize(2*dx_max+2);
for (ddx=dx_min;ddx<=dx_max;ddx++)
{denom2+=migra[abs(ddx)];
 if(ddx==k) numer2=denom2;
//cout<<numer2<<" "<<denom2<<endl;
}
frac2= ((double) numer2/denom2);
//cout<<k<<" "<<dx_max<<" "<<frac2<<endl;
cum_fixex[k+dx_max]=frac2;
//cout<<" alo";

}/*fin cumul_fixe*/

/*****************/
//calcul les probailitÈs cumulÈes de migration pour reseau homogene (= fixe!=0)
void cumul_fixey(int k)
{int ddy;
 double numer2,denom2,frac2;

//pour y
denom2=0.0;
numer2=0.0;
//cum_fixey.resize(2*dy_max+2);
for (ddy=dy_min;ddy<=dy_max;ddy++)
{denom2+=migra[abs(ddy)];
 if(ddy==k) numer2=denom2;
}
frac2= ((double) numer2/denom2);
cum_fixey[k+dy_max]=frac2;

}/*fin cumul_fixe*/



/*****************/
//procedure calcul la distance de migration en x quand reseau homogene (= fixe!=0)
int dispx_fixe()
{float alea1;
int ddx;
alea1=alea();
if((alea1<cum_fixex[dx_max])&&(alea1>cum_fixex[dx_max-1])) {ddx=0;goto finx;}
if(alea1>cum_fixex[dx_max])
{for(int k=1;k<=dx_max;k++)
  if(alea1<cum_fixex[k+dx_max])
	 {ddx=k;goto finx;
	 }
}
if( alea1 < cum_fixex[dx_max-1])
{if(alea1<cum_fixex[0]) {ddx=dx_min;goto finx;}
for(int k=-1;k>dx_min;k--)
  if(alea1>cum_fixex[k-1+dx_max]) {ddx=k;goto finx;}
}
finx:
	//cout << "dx=" << ddx << endl;
return ddx;
} /*fin dispx_fixe*/

/*****************/
//procedure calcul la distance de migration en y quand reseau homogene (= fixe!=0)
int dispy_fixe()
{float alea1;
int ddy;

alea1=alea();
if(dimRes2/vide==1 || ((alea1<cum_fixey[dy_max])&&(alea1>cum_fixey[dy_max-1]))) {ddy=0;goto finy;}
if(alea1>cum_fixey[dy_max])
{for(int k=1;k<=dy_max;k++)
  if(alea1<cum_fixey[k+dy_max])
	 {ddy=k;goto finy;
	 }
}
if( alea1 < cum_fixey[dy_max-1])
{if(alea1<cum_fixey[0]) {ddy=dy_min;goto finy;}
for(int k=-1;k>dy_min;k--)
  if(alea1>cum_fixey[k-1+dy_max]) {ddy=k;goto finy;}
}
finy:
	//cout << "dy=" << ddy << endl;
return ddy;
} /*fin dispy_fixe*/

/******************************/
int ComputeDemeSize() {
if(ContSizeChange==1) {
    dens=(int) floor(startingSize + growthRate*(currentGeneration-growthStart));
} else if(ContSizeChange==2) {
    dens=(int) floor(startingSize*exp(growthRate*(currentGeneration-growthStart)));
    //cout << "Gn=" << currentGeneration << " -> N=" << dens << endl; //vÈrif OK
} else if(ContSizeChange==3) {
    dens=(int) floor(KLogistic/(1+(KLogistic-P0Logistic)/P0Logistic*exp(-LogisticGrowthRate*(currentGeneration-growthStart))));
	 //cout << "Gn=" << currentGeneration << " -> N=" << dens << endl; //vÈrif OK
}
//_gotoxy(0,15);
//cout << "at Gn=" << currentGeneration << " deme size is " << dens << endl;
//getchar();
	return(0);
}
/******************************/

/*---------------------procedure nombre aleatoire des noeuds------------------*/

void nbre_aleat_noeud()
{ int n;
  float aleat;


for(int j=1;j<=nbre_noeud_restant;j++)
 {if(fixe==0) n=densite[coord_noeud[no_noeud_restant[j]][x]]
		  [coord_noeud[no_noeud_restant[j]][y]];
    else n=dens;
 /*printf("cordx:%d, coordy:%d"
          ,coord_noeud[no_noeud_restant[j]][x]
			 ,coord_noeud[no_noeud_restant[j]][y]);*/
 //printf("densi=n:%d\n",dens);
 //getchar();
 aleat=ploidy*n*alea();
 //pb : remplacer : doit etre bcp plus rapide quand grands demes
 //aleat_noeud[no_noeud_restant[j]]=( (int) aleat) +1;
 aleat_noeud[no_noeud_restant[j]]=( (int) aleat) +1;
 //for(jj=1;jj<=2*n;jj++)
 // {if (aleat<=jj) {aleat_noeud[no_noeud_restant[j]]=jj; break;/* goto fin;*/}
 // }
 /*fin:*/
// printf("aleat: %f %d nbre alea: %d"
//			  ,aleat,jj,aleat_noeud[no_noeud_restant[j]]);
// getchar();
 }
}
/*--------------------------------------------------------------------------*/
/*------------------procedure gamma_mut pour tx de mut variable-------------*/
/*------------------et loi binormale allant avec----------------------------*/

double gamma_mut(double rate)/*de parameres alpha=2,lambda=0.00025)*/
{
 float aleat1,aleat2;
 double x1,x2,mut,mutl;
do
 {mut=0;
 for(long int i=1;i<=2/*alpha*/;i++)
  {aleat1=alea();
  aleat2=alea();
  x1=sqrt(-2.0*log(aleat1))*cos(2*PI*aleat2);/*loi normale(0.1)*/
  x2=sqrt(-2.0*log(aleat2))*cos(2*PI*aleat1);/*idem*/
  mut+=x1*x1+x2*x2;
  }
 mutl=mut*rate/*lambda*//2;
 }while(mutl<=0);
//printf("mutl= %6f",mutl);
//getchar();
return(mutl);
}

/*-------------compter les alleles-------------------------------------------*/
void compter_allele()
{int j;

	nbre_allele_loc=1;
	for(int i=2;i<=n_genes;i++)
		{j=1;
		 while((j!=i-1)
				  &&(noeud[j][locus].etat_allele!=noeud[i][locus].etat_allele)) j++;
		 if (noeud[j][locus].etat_allele!=noeud[i][locus].etat_allele)
			  nbre_allele_loc++;
		}
nbre_allele[locus]=nbre_allele_loc;
nbre_allele_moy+= ((double) nbre_allele_loc)/ (double) n_locus;

allele_max[locus]=Kmin;
allele_min[locus]=Kmax;
for(int i=1;i<=n_genes;i++) {
	if(noeud[i][locus].etat_allele>allele_max[locus]) allele_max[locus]=noeud[i][locus].etat_allele;
	if(noeud[i][locus].etat_allele<allele_min[locus]) allele_min[locus]=noeud[i][locus].etat_allele;
}
}



/*---------------------------------------------------------------------------*/

/*-------------procedure Kini pour donner l'etat allelic du MRCA-------------*/
int K_ini()
{int ini;
double aleat;
aleat=alea();
//printf("\n aleat=%f,fraction=%f",aleat,(((double)i)/((double)(Kmax-Kmin+1))));
if(Kini==0){
for(int i=Kmin;i<=Kmax;i++) if(aleat <= (((double)i)/((double)(Kmax-Kmin+1)))) {ini=i;break;}
 }
else return Kini;
//printf("\n Kini=%d",ini);
//getchar();
return ini;
}
/*---------------------------------------------------------------------------*/

/*-------------procedure compter les alleles sous KAM------------------------*/

void compter_alleles_KAM()
{int aleat;
long int temps;
char lettre;

noeud[nbre_noeud_existant][locus].etat_allele=K_ini();/*etat du noeud ancestral*/
for(int i=nbre_noeud_existant;i>0;i--)
	for(int k=1;k<=noeud[i][locus].nbre_descendant;k++)
	{if(noeud[noeud[i][locus].descendant[k]][locus].etat_allele==111)
		{noeud[noeud[i][locus].descendant[k]][locus].etat_allele
						 =noeud[i][locus].etat_allele;
		 temps=noeud[i][locus].generation
		 -noeud[noeud[i][locus].descendant[k]][locus].generation;/*nbre generation
																	entre ancetre et descendant*/
		 n_mut=mutation(temps);
		 /*printf("%d", n_mut);
		 getchar();*/
		 if (n_mut!=0)
			{for(int j=1;j<=n_mut;j++)
				{do {aleat=(int) (Kmax*alea() +1);}
						while(aleat
							==noeud[noeud[i][locus].descendant[k]][locus].etat_allele);
				 noeud[noeud[i][locus].descendant[k]][locus].etat_allele=aleat;
				}
			}
		 }
	}
compter_allele();
if(migrate_lettre_oui)
 for(int i=1;i<=nbre_noeud_existant;i++)
  { if(noeud[i][locus].etat_allele==1) lettre='a';
	else if(noeud[i][locus].etat_allele==2) lettre='b';
	else if(noeud[i][locus].etat_allele==3) lettre='c';
	else if(noeud[i][locus].etat_allele==4) lettre='d';
	else if(noeud[i][locus].etat_allele==5) lettre='e';
	else if(noeud[i][locus].etat_allele==6) lettre='f';
	else if(noeud[i][locus].etat_allele==7) lettre='g';
	else if(noeud[i][locus].etat_allele==8) lettre='h';
	else if(noeud[i][locus].etat_allele==9) lettre='i';
	else if(noeud[i][locus].etat_allele==10) lettre='j';
	else if(noeud[i][locus].etat_allele==11) lettre='k';
	else if(noeud[i][locus].etat_allele==12) lettre='l';
	else if(noeud[i][locus].etat_allele==13) lettre='m';
	else if(noeud[i][locus].etat_allele==14) lettre='n';
	else if(noeud[i][locus].etat_allele==15) lettre='o';
	else if(noeud[i][locus].etat_allele==16) lettre='p';
	else if(noeud[i][locus].etat_allele==17) lettre='q';
	else if(noeud[i][locus].etat_allele==18) lettre='r';
	else if(noeud[i][locus].etat_allele==19) lettre='s';
	else if(noeud[i][locus].etat_allele==20) lettre='t';
	else if(noeud[i][locus].etat_allele==21) lettre='u';
	else if(noeud[i][locus].etat_allele==22) lettre='v';
	else if(noeud[i][locus].etat_allele==23) lettre='w';
	else if(noeud[i][locus].etat_allele==24) lettre='x';
	else if(noeud[i][locus].etat_allele==25) lettre='y';
	else if(noeud[i][locus].etat_allele==26) lettre='z';
	else if(noeud[i][locus].etat_allele==27) lettre='0';
	else if(noeud[i][locus].etat_allele==28) lettre='1';
	else if(noeud[i][locus].etat_allele==29) lettre='2';
	else if(noeud[i][locus].etat_allele==30) lettre='3';
	else if(noeud[i][locus].etat_allele==31) lettre='4';
	else if(noeud[i][locus].etat_allele==32) lettre='5';
	else if(noeud[i][locus].etat_allele==33) lettre='6';
	else if(noeud[i][locus].etat_allele==34) lettre='7';
	else if(noeud[i][locus].etat_allele==35) lettre='8';
	else if(noeud[i][locus].etat_allele==36) lettre='9';
	else {printf("probleme : too many alleles (>36) to translate to letter code");getchar();}
				 //printf("\n lettre=%c",lettre);
				 noeud[i][locus].etat_allele_lettre=lettre;

  }


}
/*---------------------------------------------------------------------------*/

/*-----------------compter les alleles sous SMM-------------------------------*/


void compter_alleles_SMM()
{
int etat_precedent;
long int temps;
double aleat;

for(int i=1;i<=nbre_noeud_existant;i++) noeud[i][locus].etat_allele=111;
noeud[nbre_noeud_existant][locus].etat_allele=K_ini();
				/*etat du noeud ancestral*/
for(int i=nbre_noeud_existant;i>0;i--)
	  { for(int k=1;k<=noeud[i][locus].nbre_descendant;k++)
		  {if(noeud[noeud[i][locus].descendant[k]][locus].etat_allele==111)
		{noeud[noeud[i][locus].descendant[k]][locus].etat_allele
			=noeud[i][locus].etat_allele;
					  temps=noeud[i][locus].generation
							  -noeud[noeud[i][locus].descendant[k]][locus].generation;
					  n_mut=mutation(temps);
		 if (n_mut!=0)
			{for(int j=1;j<=n_mut;j++)
				{etat_precedent
						=noeud[noeud[i][locus].descendant[k]][locus].etat_allele;
				 aleat=alea();
				 if (aleat<0.5)
					 noeud[noeud[i][locus].descendant[k]][locus].etat_allele
							=(etat_precedent-1);
				  else noeud[noeud[i][locus].descendant[k]][locus].etat_allele
									=(etat_precedent+1);
				 if (noeud[noeud[i][locus].descendant[k]][locus].etat_allele<Kmin)
					{noeud[noeud[i][locus].descendant[k]][locus].etat_allele
					 =etat_precedent;
					 /*goto precedent1;*/
					}
				 if (noeud[noeud[i][locus].descendant[k]][locus].etat_allele>Kmax)
					 {noeud[noeud[i][locus].descendant[k]][locus].etat_allele
						=etat_precedent;
					  /*goto precedent1;*/
					 }
				 /*elimine mutations depassant les bornes*/
				}
			}
		}
	}
	  }
compter_allele();
}
/*----------------------------------------------------------------------------*/

/*------------------compter les alleles sous IAM-----------------------------*/

void compter_alleles_IAM()
{
int nbre_etat;
char lettre;
long int temps;

for(int i=1;i<=nbre_noeud_existant;i++) noeud[i][locus].etat_allele=111;
nbre_etat=1;
noeud[nbre_noeud_existant][locus].etat_allele
	=nbre_etat;/*etat du noeud ancestral*/
for(int i=nbre_noeud_existant;i>0;i--)
 {for(int k=1;k<=noeud[i][locus].nbre_descendant;k++)
	{if(noeud[noeud[i][locus].descendant[k]][locus].etat_allele==111)
		{temps=(noeud[i][locus].generation
		  -noeud[noeud[i][locus].descendant[k]][locus].generation);
		 n_mut=mutation(temps);
		 if (n_mut!=0)
			{for(int j=1;j<=n_mut;j++)
				{nbre_etat++;
				 noeud[noeud[i][locus].descendant[k]][locus].etat_allele=nbre_etat;
				}
			 }
			else noeud[noeud[i][locus].descendant[k]][locus].etat_allele
				=noeud[i][locus].etat_allele;
		 }
	}
 }
compter_allele();
if(migrate_lettre_oui)
 for(int i=1;i<=nbre_noeud_existant;i++)
  { if(noeud[i][locus].etat_allele==1) lettre='a';
	else if(noeud[i][locus].etat_allele==2) lettre='b';
	else if(noeud[i][locus].etat_allele==3) lettre='c';
	else if(noeud[i][locus].etat_allele==4) lettre='d';
	else if(noeud[i][locus].etat_allele==5) lettre='e';
	else if(noeud[i][locus].etat_allele==6) lettre='f';
	else if(noeud[i][locus].etat_allele==7) lettre='g';
	else if(noeud[i][locus].etat_allele==8) lettre='h';
	else if(noeud[i][locus].etat_allele==9) lettre='i';
	else if(noeud[i][locus].etat_allele==10) lettre='j';
	else if(noeud[i][locus].etat_allele==11) lettre='k';
	else if(noeud[i][locus].etat_allele==12) lettre='l';
	else if(noeud[i][locus].etat_allele==13) lettre='m';
	else if(noeud[i][locus].etat_allele==14) lettre='n';
	else if(noeud[i][locus].etat_allele==15) lettre='o';
	else if(noeud[i][locus].etat_allele==16) lettre='p';
	else if(noeud[i][locus].etat_allele==17) lettre='q';
	else if(noeud[i][locus].etat_allele==18) lettre='r';
	else if(noeud[i][locus].etat_allele==19) lettre='s';
	else if(noeud[i][locus].etat_allele==20) lettre='t';
	else if(noeud[i][locus].etat_allele==21) lettre='u';
	else if(noeud[i][locus].etat_allele==22) lettre='v';
	else if(noeud[i][locus].etat_allele==23) lettre='w';
	else if(noeud[i][locus].etat_allele==24) lettre='x';
	else if(noeud[i][locus].etat_allele==25) lettre='y';
	else if(noeud[i][locus].etat_allele==26) lettre='z';
	else if(noeud[i][locus].etat_allele==27) lettre='0';
	else if(noeud[i][locus].etat_allele==28) lettre='1';
	else if(noeud[i][locus].etat_allele==29) lettre='2';
	else if(noeud[i][locus].etat_allele==30) lettre='3';
	else if(noeud[i][locus].etat_allele==31) lettre='4';
	else if(noeud[i][locus].etat_allele==32) lettre='5';
	else if(noeud[i][locus].etat_allele==33) lettre='6';
	else if(noeud[i][locus].etat_allele==34) lettre='7';
	else if(noeud[i][locus].etat_allele==35) lettre='8';
	else if(noeud[i][locus].etat_allele==36) lettre='9';
	else {printf("probleme : too many alleles (>36) to translate to letter code");
		  printf("\n allele number %d can not be translate",noeud[i][locus].etat_allele);
		  getchar();
		 }

	noeud[i][locus].etat_allele_lettre=lettre;

  }

}

/*----------------------------------------------------------------------------*/

/*----------------compter alleles sous TPM-----------------------------------*/

 void compter_alleles_TPM()
{
int delta_mut,etat_precedent;
double aleat;
long int temps;

for(int i=1;i<=nbre_noeud_existant;i++) noeud[i][locus].etat_allele=111;
noeud[nbre_noeud_existant][locus].etat_allele
	=K_ini();/*etat du noeud ancestral*/
for(int i=nbre_noeud_existant;i>0;i--)
 {for(int k=1;k<=noeud[i][locus].nbre_descendant;k++)
	{if(noeud[noeud[i][locus].descendant[k]][locus].etat_allele==111)
		{noeud[noeud[i][locus].descendant[k]][locus].etat_allele
			=noeud[i][locus].etat_allele;
		 temps=(noeud[i][locus].generation
			-noeud[noeud[i][locus].descendant[k]][locus].generation);
		 n_mut=mutation(temps);
		 if (n_mut!=0)
			{for(int j=1;j<=n_mut;j++)
				{etat_precedent
					  =noeud[noeud[i][locus].descendant[k]][locus].etat_allele;
				 //precedent1:
				 aleat=alea();
				 if (aleat<pSMM) delta_mut=1;/*strict SMM*/
				  else delta_mut=loi_geom(var_geom_TPM);/*loi geometrique*/
				  /*gotoxy(1,15);
				  printf("delta_mut= %d\n",delta_mut);
				  getchar();*/
				 aleat=alea();
				 if(aleat<0.5)
					 noeud[noeud[i][locus].descendant[k]][locus].etat_allele
						 =(etat_precedent-delta_mut);
				  else noeud[noeud[i][locus].descendant[k]][locus].etat_allele
					=(etat_precedent+delta_mut);
				 if (noeud[noeud[i][locus].descendant[k]][locus].etat_allele<Kmin)
					{noeud[noeud[i][locus].descendant[k]][locus].etat_allele
					 =etat_precedent;
					 /*goto precedent1;*/
					}
				 if (noeud[noeud[i][locus].descendant[k]][locus].etat_allele>Kmax)
					 {noeud[noeud[i][locus].descendant[k]][locus].etat_allele
						=etat_precedent;
					  /*goto precedent1;*/
					 }
				 /*elimine mutations depassant les bornes*/
				}
			}
		}
	}
 }
compter_allele();
}

/*----------------------------------------------------------------------------*/
/*----------------compter alleles sous GSM-----------------------------------*/

 void compter_alleles_GSM()
{
int delta_mut,etat_precedent;
double aleat;
long int temps;

for(int i=1;i<=nbre_noeud_existant;i++) noeud[i][locus].etat_allele=111;
noeud[nbre_noeud_existant][locus].etat_allele
	=K_ini();/*etat du noeud ancestral*/
for(int i=nbre_noeud_existant;i>0;i--)
 {for(int k=1;k<=noeud[i][locus].nbre_descendant;k++)
	{if(noeud[noeud[i][locus].descendant[k]][locus].etat_allele==111)
		{noeud[noeud[i][locus].descendant[k]][locus].etat_allele
			=noeud[i][locus].etat_allele;
		 temps=(noeud[i][locus].generation
			-noeud[noeud[i][locus].descendant[k]][locus].generation);
		 n_mut=mutation(temps);
		 if (n_mut!=0)
			{for(int j=1;j<=n_mut;j++)
				{etat_precedent
					  =noeud[noeud[i][locus].descendant[k]][locus].etat_allele;
				 //printf("\n etat initial:%d",etat_precedent);
				 //precedent1:
				 delta_mut=loi_geom(var_geom_GSM);/*loi geometrique*/
				  /*gotoxy(1,15);
				  printf("delta_mut= %d\n",delta_mut);
				  getchar();*/
				 aleat=alea();
				 if(aleat<0.5)
					 noeud[noeud[i][locus].descendant[k]][locus].etat_allele
						 =(etat_precedent-delta_mut);
				  else noeud[noeud[i][locus].descendant[k]][locus].etat_allele
					=(etat_precedent+delta_mut);
				 //printf("etat apres mut:%d",noeud[noeud[i][locus].descendant[k]][locus].etat_allele);
				 if (noeud[noeud[i][locus].descendant[k]][locus].etat_allele<Kmin)
					{noeud[noeud[i][locus].descendant[k]][locus].etat_allele
					 =etat_precedent;
					 /*goto precedent1;*/
					}
				 if (noeud[noeud[i][locus].descendant[k]][locus].etat_allele>Kmax)
					 {noeud[noeud[i][locus].descendant[k]][locus].etat_allele
						=etat_precedent;
					  /*goto precedent1;*/
					 }
				 //printf("etat apres elimination:%d",noeud[noeud[i][locus].descendant[k]][locus].etat_allele);
				 //getchar();
				 /*elimine mutations depassant les bornes*/
				}
			}
		}
	}
 }
compter_allele();
}
/*--------------------------------------------------------------------------*/


/*-----------------ecriture entetes fichiers genepop-------------------------*/

void entete_fichier()
{
 char ch1[100],fichier[50];


strcpy(fichier,fichier_genepop);
sprintf(ch1,"%d",rep);
strcat(fichier,ch1);
if(txt_extensionbool) strcat(fichier,".txt");

 if((fgenepop=fopen(fichier,"w"))==0)
	{printf("entete fichiers cannot open file: %s\n",fichier);
	 exit(1);
	}
 fprintf(fgenepop,"%s",fichier);
 switch(model_mut)
	{case'1':
	 fprintf(fgenepop," sous SMM; ");
	 break;
	 case'2':
	 fprintf(fgenepop," sous IAM; ");
	 break;
	 case'3':
	 fprintf(fgenepop," sous KAM; ");
	 break;
	 case'4':
	 fprintf(fgenepop," sous TPM; ");
	 break;
	 case'5':
	 fprintf(fgenepop," sous GSM; ");
	 break;
	}

 fprintf(fgenepop," comments: %s ",comments);
 fprintf(fgenepop,"; nbre de repetition=%d ",repet);
 fprintf(fgenepop,"; nbre de genes=%3d ",n_genes);
 fprintf(fgenepop,"; nbre de locus=%2d ",n_locus);
 if(!Specific_Sample_Designbool) fprintf(fgenepop,"; %d x %d individus",dim_sample1,dim_sample2);
   else fprintf(fgenepop,"; %d individus",Spec_SampleSize);
 if(diploidebool) fprintf(fgenepop," diploides ");
  else fprintf(fgenepop," haploides ");
if (EdgeEffect==0) fprintf(fgenepop," evolving at G=0 on a %d x %d torus",dimRes1G0,dimRes2G0);
if (EdgeEffect==1) fprintf(fgenepop," evolving at G=0 on a %d x %d lattice with absorbing boundaries",dimRes1G0,dimRes2G0);
if (EdgeEffect==2) fprintf(fgenepop," evolving at G=0 on a %d x %d lattice with reflecting boundaries",dimRes1G0,dimRes2G0);

 fprintf(fgenepop,"; Tx de mutation=%6f ",_mu);
 fprintf(fgenepop,"; repetition:%d",rep);
 fprintf(fgenepop,"; Mrca Moy= %6f; MRCA MAX=%5d\n",mrca_moy,mrca_max);
 for(int i=0;i<n_locus;i++) fprintf(fgenepop,"locus%d\n",(i+1));
/*fgenepop ferme dans procedure ecriture_fichier*/
 }
/*---------------------------------------------------------------------------*/
/*-------------------ecriture fichiers fgenepop-------------------------------*/
void ecriture_fichier()
{
entete_fichier();
/*fgenepop ouvert dans procedure entete_fichier*/
for(int i=1;i<=n_genes;i=i+ploidy)
	{if(((fmod(((double) (i-1)),ploidy*dens_sample))==0.0)||(i==1)) fprintf(fgenepop,"pop \n");
     fprintf(fgenepop,"%d ",coord_individus[i][x]);
	 fprintf(fgenepop,"%d,",coord_individus[i][y]);
	 for(int j=1;j<=n_locus;j++)
		{if(noeud[i][j].etat_allele<10)
			 fprintf(fgenepop," 00%d",noeud[i][j].etat_allele);
		  else if(noeud[i][j].etat_allele<100)
					  fprintf(fgenepop," 0%d",noeud[i][j].etat_allele);
		  else if(noeud[i][j].etat_allele>999) {
#ifdef GOTO
			  _gotoxy(0,15);
#endif
              cout << "An allelic state has been found to be larger than 999," << endl;
			  cout << "IBDSim can not write Genepop files with more than 3 digits" << endl;
			  cout << "Choose a lower mutation rate or a mutation model with bounds," << endl;
			  cout << "\nand start the program again...." << endl;
			  getchar();
			  exit(-1);
		  } else fprintf(fgenepop," %d",noeud[i][j].etat_allele);
		 if(diploidebool) {
			 if(noeud[i+1][j].etat_allele<10)
				fprintf(fgenepop,"00%d",noeud[i+1][j].etat_allele);
			  else if(noeud[i+1][j].etat_allele<100)
						fprintf(fgenepop,"0%d",noeud[i+1][j].etat_allele);
			  else if(noeud[i][j].etat_allele>999) {
#ifdef GOTO
				  _gotoxy(0,15);
#endif
				  cout << "An allelic state has been found to be larger than 999," << endl;
				  cout << "IBDSim can not write Genepop files with more than 3 digits" << endl;
				  cout << "Choose a lower mutation rate or a mutation model with bounds," << endl;
				  cout << "\nand start the program again...." << endl;
				  getchar();
				  exit(-1);
			  } else  fprintf(fgenepop,"%d",noeud[i+1][j].etat_allele);
		}
		 if(j==n_locus) fprintf(fgenepop," \n");
		}
	}

if(fclose(fgenepop)) printf("file close error.\n");
/*printf("ecriture du fichier %s OK;",fichier);*/
}

/*---------------------------------------------------------------------------*/
/*----------ecriture fichier migrate----------------------------------------*/
void ecriture_fichier_migrate()
{
char ch1[100],fichier1[50];

strcpy(fichier1,fichier_migrate);
sprintf(ch1,"%d",rep);
strcat(fichier1,ch1);
if(txt_extensionbool) strcat(fichier1,".txt");

/*printf("\n test ecriture avec nbre %s \n",fichier);*/
 if((fmigrate=fopen(fichier1,"w"))==0)
	{printf("entete fichiers cannot open file: %s\n",fichier1);
	 exit(1);
	}
 if(!Specific_Sample_Designbool) fprintf(fmigrate,"%d ",dim_sample1/vide_sampleX*dim_sample2/vide_sampleY);//nbre de pop echantillonnÈes
  else fprintf(fmigrate,"%d ",Spec_SampleSize);//nbre de pop echantillonnÈes
 fprintf(fmigrate,"%d ",n_locus);
 fprintf(fmigrate,". ");//pour microsat et locus codÈs par nombre
 fprintf(fmigrate,"%s",fichier1);

 switch(model_mut)
	{case'1':
	 fprintf(fmigrate," sous SMM; ");
	 break;
	 case'2':
	 fprintf(fmigrate," sous IAM; ");
	 break;
	 case'3':
	 fprintf(fmigrate," sous KAM; ");
	 break;
	 case'4':
	 fprintf(fmigrate," sous TPM; ");
	 break;
	 case'5':
	 fprintf(fmigrate," sous GSM; ");
	 break;
	}
 if(!Specific_Sample_Designbool) fprintf(fmigrate,"; %d x %d individus",dim_sample1,dim_sample2);
   else fprintf(fmigrate,"; %d individus",Spec_SampleSize);
 if(diploidebool) fprintf(fmigrate," diploides ");
  else fprintf(fmigrate," haploides ");
 fprintf(fmigrate," evoluant a G=0 sur tore de %d x %d",dimRes1G0,dimRes2G0);
 fprintf(fmigrate,"; Tx de mutation=%6f \n",_mu);

  for(int i=1;i<=n_genes;i=i+ploidy)
	{if(((fmod(((double) (i-1)),ploidy*dens_sample))==0.0)||(i==1)) fprintf(fmigrate,"%d pop%d%d\n",dens_sample,coord_individus[i][x],coord_individus[i][y]);
	 //fprintf(fmigrate,"%.3d",coord_individus[i][x]);
	 //fprintf(fmigrate,"%.3d",coord_individus[i][y]);
	 fprintf(fmigrate,"%.3d     ,",(i+1)/2);
	 for(int j=1;j<=n_locus;j++)
		{if(!migrate_lettre_oui) fprintf(fmigrate," %d",noeud[i][j].etat_allele);
		  else fprintf(fmigrate," %c",noeud[i][j].etat_allele_lettre);
		 fprintf(fmigrate,".");
		 if(diploidebool) {
			 if(!migrate_lettre_oui) fprintf(fmigrate,"%d",noeud[i+1][j].etat_allele);
			  else fprintf(fmigrate,"%c",noeud[i+1][j].etat_allele_lettre);
		 }
		 if(j==n_locus) fprintf(fmigrate,"\n");
		}
	}
if(fclose(fmigrate)) printf("file close error.\n");
/*printf("ecriture du fichier %s OK;",fichier);*/
}


/*--------------ecriture fichiers DG2002------------------------------------*/
void ecriture_fichiers_DG2002KAM()
{int pop,PopNbr,***nb_alleles_etat,*petit2,*grand,nb_etats;
//double ***nb_alleles_etat;
char fichier1[50];

nb_etats=Kmax-Kmin+1;

if(!Specific_Sample_Designbool) nb_alleles_etat=(int ***) itab3(nb_etats+1,n_locus+1,dim_sample1*dim_sample2+1);
  else nb_alleles_etat=(int ***) itab3(nb_etats+1,n_locus+1,Spec_SampleSize+1);
petit2=(int *) ivector(n_locus+1);
grand=(int *) ivector(n_locus+1);

strcpy(fichier1,fichier_stepsim);
char chaine[100];
sprintf(chaine, "%d", rep);
strcat(fichier1,chaine);
if(txt_extensionbool) strcat(fichier1,".txt");

/*if(dossier_nbre_allele) {
	//a=malloc(100*sizeof(char *));
//#ifdef WIN32
//	sprintf(chaine, ".\\%d alleles", nbre_allele[1]);
//	mkdir(chaine);
//    sprintf(chaine, ".\\%d alleles\\", nbre_allele[1]);
//#else //speculative but should allow compilation at least
#ifdef WIN32
//not really tested but avoids Dev-C++ error on mkdir()
	sprintf(chaine, "mkdir ./%d alleles", nbre_allele[1]);
	system(chaine);
#else
	sprintf(chaine, "./%d alleles", nbre_allele[1]);
	mkdir(chaine,0777);
#endif
    sprintf(chaine, "./%d alleles/", nbre_allele[1]);
//#endif
	strcat(chaine,fichier1);
	strcpy(fichier1,chaine);

}*/


if((fDG2002=fopen(fichier1,"w"))==0)
	{printf("ecriture_fichiers_DG2002KAM() cannot open file: %s\n",fichier1);
	 getchar();
	 //exit(1);
	}



//fprintf(fp5,"%d\n",n_locus);//nbre de pop echantillonnÈes
//printf("%d\n%d %d\n",n_locus,dens_sample,dens_sample);//nbre de pop echantillonnÈes
//getchar();

for(int j=1;j<=n_locus;j++) {
	petit2[j]=nb_etats;
	grand[j]=0;
}
pop=0;
if(!Specific_Sample_Designbool) {
    for(int j=1;j<=n_locus;j++)
	   for(int k=1;k<=dim_sample1;k++)
		for(int k2=1;k2<=dim_sample2;k2++){
			pop++;
			for(int l=1;l<=nb_etats;l++) nb_alleles_etat[l][j][pop]=0;
		}
} else {
   for(int j=1;j<=n_locus;j++)
	   for(int k=1;k<=Spec_SampleSize;k++) {
			for(int l=1;l<=nb_etats;l++) nb_alleles_etat[l][j][k]=0;
		}
}

 for(int j=1;j<=n_locus;j++)
	for(int i=1;i<=n_genes;i++){
		if(!Specific_Sample_Designbool) pop=(coord_individus[i][y]-ymin_sample)*dim_sample1+(coord_individus[i][x]-xmin_sample+vide_sampleX)/vide_sampleY;
		  else pop=(int) (floor(i/ploidy/dens_sample)+1);
		//printf("\n locus=%d; gene=%d;pop=%d;etat=%d",j,i,pop,noeud[i][j].etat_allele);
		//getchar();
		for(int l=1;l<=nb_etats;l++)
		  {	if(noeud[i][j].etat_allele==(Kmin+l-1)) {
				nb_alleles_etat[l][j][pop]+=1;
				//printf("nb_allele_etat[%d][%d][%d]=%d",l,j,pop,nb_alleles_etat[l][j][pop]);
				if(l<petit2[j]) petit2[j]=l;
				if(l>grand[j]) grand[j]=l;
			}
		  }
		}
//for(int j=1;j<=n_locus;j++) printf("\n Locus %d griffiths2() OK alleles between %d and %d\n",j,petit2[j],grand[j]);
//getchar();
if(!Specific_Sample_Designbool) PopNbr=dim_sample1*dim_sample2;
  else PopNbr=Spec_SampleSize;
for(int j=1;j<=n_locus;j++) {
 for(int i=1;i<=PopNbr;i++) {
  for(int l=1;l<=nb_etats;l++){
  	if(nb_alleles_etat[l][j][i]>0 || AllStates) {
            fprintf(fDG2002,"%d",nb_alleles_etat[l][j][i]);
  	        if(l!=nb_etats) fprintf(fDG2002," ");
    }
  }
  fprintf(fDG2002,";\n");
 }
}

free_itab3(nb_alleles_etat,nb_etats+1,n_locus+1);
free_ivector(petit2);
free_ivector(grand);

if(fclose(fDG2002)) printf("file close error.\n");
}
/*----------------------------------------------------------------------------*/

/*--------------ecriture fichiers DG2002, Stepsim et migraine pour SMM------------------------------------*/
void ecriture_fichiers_DG2002SMM()
{int pop,PopNbr,***nb_alleles_etat,*petit2,*grand,nb_etats;
//double ***nb_alleles_etat;
char fichier1[50];

nb_etats=Kmax-Kmin+1;

if(!Specific_Sample_Designbool) nb_alleles_etat=(int ***) itab3(nb_etats+1,n_locus+1,dim_sample1*dim_sample2+1);
  else nb_alleles_etat=(int ***) itab3(nb_etats+1,n_locus+1,Spec_SampleSize+1);
petit2=(int *) ivector(n_locus+1);
grand=(int *) ivector(n_locus+1);

strcpy(fichier1,fichier_stepsim);
char chaine[100];
sprintf(chaine, "%d", rep);
strcat(fichier1,chaine);
if(txt_extensionbool) strcat(fichier1,".txt");


/*if(dossier_nbre_allele) {
	//a=malloc(100*sizeof(char *));
//#ifdef WIN32
//	sprintf(chaine, ".\\%d alleles", nbre_allele[1]);
//	mkdir(chaine);
//    sprintf(chaine, ".\\%d alleles\\", nbre_allele[1]);
//#else //speculative but should allow compilation at least
#ifdef WIN32
//not really tested but avoids Dev-C++ error on mkdir()
//marche pas avec wxdevcpp... donc virer dans les nouvelles versions
	sprintf(chaine, "mkdir ./%d alleles", nbre_allele[1]);
	system(chaine);
#else
	sprintf(chaine, "./%d alleles", nbre_allele[1]);
	mkdir(chaine,0777);
#endif
    sprintf(chaine, "./%d alleles/", nbre_allele[1]);
//#endif
	strcat(chaine,fichier1);
	strcpy(fichier1,chaine);

}*/


if((fDG2002=fopen(fichier1,"w"))==0)
	{printf("ecriture_fichiers_DG2002SMM() cannot open file: %s\n",fichier1);
	 getchar();
	 //exit(1);
	}



//fprintf(fp5,"%d\n",n_locus);//nbre de locus echantillonnÈes
//printf("%d\n%d %d\n",n_locus,dens_sample,dens_sample);//nbre de pop echantillonnÈes
//getchar();
for(int j=1;j<=n_locus;j++) {
	petit2[j]=nb_etats;
	grand[j]=0;
}

pop=0;
if(!Specific_Sample_Designbool) {
    for(int j=1;j<=n_locus;j++)
	   for(int k=1;k<=dim_sample1;k++)
		for(int k2=1;k2<=dim_sample2;k2++){
			pop++;
			for(int l=1;l<=nb_etats;l++) nb_alleles_etat[l][j][pop]=0;
		}
} else {
   for(int j=1;j<=n_locus;j++)
	   for(int k=1;k<=Spec_SampleSize;k++) {
			for(int l=1;l<=nb_etats;l++) nb_alleles_etat[l][j][k]=0;
		}
}

for(int j=1;j<=n_locus;j++)
	for(int i=1;i<=n_genes;i++){
		if(!Specific_Sample_Designbool) pop=(coord_individus[i][y]-ymin_sample)*dim_sample1+(coord_individus[i][x]-xmin_sample+vide_sampleX)/vide_sampleY;
		  else pop=(int) (floor(i/ploidy/dens_sample)+1);
		//printf("\n locus=%d; gene=%d;pop=%d;etat=%d",j,i,pop,noeud[i][j].etat_allele);
		//getchar();
		for(int l=1;l<=nb_etats;l++)
		  {	if(noeud[i][j].etat_allele==(Kmin+l-1)) {
				nb_alleles_etat[l][j][pop]+=1;
				//printf("nb_allele_etat[%d][%d][%d]=%d",l,j,pop,nb_alleles_etat[l][j][pop]);
				if(l<petit2[j]) petit2[j]=l;
				if(l>grand[j]) grand[j]=l;
			}
		  }
		}
//for(int j=1;j<=n_locus;j++) printf("\n Locus %d griffiths2() OK alleles between %d and %d\n",j,petit2[j],grand[j]);
//getchar();
if(!Specific_Sample_Designbool) PopNbr=dim_sample1*dim_sample2;
  else PopNbr=Spec_SampleSize;
for(int j=1;j<=n_locus;j++) {
    if(j!=1) fprintf(fDG2002,"\n");
 for(int i=1;i<=PopNbr;i++) if(i==1) fprintf(fDG2002,"%d",ploidy*dens_sample); else fprintf(fDG2002," %d",ploidy*dens_sample);//nbre d'ind ÈchantillonnÈs par pop
 fprintf(fDG2002,"\n");
 for(int i=1;i<=PopNbr;i++) {
        fprintf(fDG2002,"pop\n");
  for(int l=petit2[j];l<=grand[j];l++){
  	if(nb_alleles_etat[l][j][i]>0 || AllStates) {
            fprintf(fDG2002,"%d %d\n",l-petit2[j],nb_alleles_etat[l][j][i]);
    }
  }
 }
}


free_itab3(nb_alleles_etat,nb_etats+1,n_locus+1);
free_ivector(petit2);
free_ivector(grand);

if(fclose(fDG2002)) printf("file close error.\n");
}
/*----------------------------------------------------------------------------*/

/*---------ecriture des moyennes des calculs ds fichiers moy_ et suiviQ_--------------*/

void ecriture_fichier_moyennes()
{char moy[50] = "Various_Statistics.txt",suiv[50]="Iterative_IdProb.txt";
 //long int  i;


//strcat(moy,fichier_genepop);
//strcat(suiv,fichier_genepop);
if(rep==1) {
if((fmoyenne=fopen(moy,"w"))==NULL)
	{printf("ecriture fichiers cannot open file: %s\n",moy);
	getchar();
	 exit(1);
	}
if(suiviQ && !Specific_Sample_Designbool) {
    if((fsuivi=fopen(suiv,"w"))==NULL) {
        printf("ecriture fichiers cannot open file: %s\n",suiv);
        getchar();
        exit(1);
   }
   fprintf(fsuivi,"#   ");
   for(int i=0;i<=(sup(dimRes1G0,sup(dim_sample1,dim_sample2))/vide_sample);i++)
        fprintf(fsuivi,"  Qr(%2d)     meanQr(%2d)   ",i,i);
    fprintf(fsuivi,"\n");
}
fprintf(fmoyenne,"run: %s with ",fichier_genepop);
fprintf(fmoyenne,"%d simulated data files of %d loci;\n",repet,n_locus);
}/*fin if(rep==1)*/

if(suiviQ) if(!Specific_Sample_Designbool) {
    fprintf(fsuivi,"%d ",rep);
    for(int i=0;i<=(sup(dimRes1G0,sup(dim_sample1,dim_sample2))/vide_sample);i++) {
        if(rep!=repet)fprintf(fsuivi,"%.10f %.10f ",Q1_moy[i],Q1_moy_glob[i]*repet/rep);
	     else fprintf(fsuivi,"%.10f %.10f ",Q1_moy[i],Q1_moy_glob[i]);
    }
    fprintf(fsuivi,"\n");
    fflush(stdout);
}

if(rep==repet) {
    mono=mono/mono2;
	fprintf(fmoyenne,"MRCA MOY = %6lf\n",mrca_moy_glob);
    fprintf(fmoyenne,"MRCA MAX = %d\n",mrca_max);
	if(!Specific_Sample_Designbool) if(diploidebool) fprintf(fmoyenne,"Mean within-individual identity prob. (Q0) = %.12lf;\n",Qind_moy_glob);
	if(!Specific_Sample_Designbool) fprintf(fmoyenne,"Mean within-population identity prob. (Q1)  = %11.8lf \n",Qpop_moy_glob);
	if(!Specific_Sample_Designbool) for(int i=0;i<=(sup(dimRes1G0,sup(dim_sample1,dim_sample2))/vide_sample);i++)
		fprintf(fmoyenne,"Mean identity prob. for genes at %2d steps (Qr%2d) = %.12f;\n",i,i,Q1_moy_glob[i]);
	if(diploidebool) fprintf(fmoyenne,"Mean intra-individual coalescence time = %.8f\n",coa_moy_glob);
	if(!Specific_Sample_Designbool) if(diploidebool) fprintf(fmoyenne,"Mean Observed heterozygosity = %11.8lf\n",hetero_moy_glob);
	if(!Specific_Sample_Designbool) if(HexpNeioui) fprintf(fmoyenne,"Mean genetic diversity (Nei Expected Heterozygosity) and SE = %11.8lf (+- %11.8lf))\n",HexpNei_moy_glob,1.96*HexpNei_moy_glob_var);
	if(!Specific_Sample_Designbool) if(DeltaHoui) fprintf(fmoyenne,"Mean DeltaH (Cornuet & Luikart 1996) and SE = %11.8lf (+- %11.8lf))\n",DeltaH_moy_glob,1.96*DeltaH_moy_glob_var);
 	if(!Specific_Sample_Designbool) if(Varoui) fprintf(fmoyenne,"Mean Variance of allelic size and SE = %11.8lf (+- %11.8lf))\n",Var_moy_glob,1.96*Var_moy_glob_var);
 	if(!Specific_Sample_Designbool) if(Varoui) fprintf(fmoyenne,"Mean M statistic (Garza & Williamson 2001) and SE = %11.8lf (+- %11.8lf))\n",M_moy_glob,1.96*M_moy_glob_var);
 	if(!Specific_Sample_Designbool) fprintf(fmoyenne,"Mean Fis = %11.8lf \n",fis_moy_glob);
 	if(!Specific_Sample_Designbool) fprintf(fmoyenne,"Mean Fis calculated as mean_num/mean_denom = %11.8lf\n",fis_moy_numer_glob/fis_moy_denom_glob);
 	if(!Specific_Sample_Designbool) fprintf(fmoyenne,"Theoretical expectations for : \n");
 	if(!Specific_Sample_Designbool) fprintf(fmoyenne,"Genetic diversity Hexp = %11.8lf\n",Hexp);
 	if(!Specific_Sample_Designbool) fprintf(fmoyenne,"Variance in allelic size Vexp = %11.8lf\n",Vexp);

	fclose(fmoyenne);
	if(suiviQ && !Specific_Sample_Designbool) fclose(fsuivi);
	}/*fin if(rep==repet)*/
}

/*---------------------------------------------------------------------------*/

/*---------ecriture des moyennes Fis et Het --------------*/

/*void ecriture_fichier_Fis_Het_cpp() //not used RL
{char Fishet[] = "Iterative_Statistics.txt"; // initialisation de longueur suffisante
 int j;

ffishet.open(Fishet,ios::out);

if(rep==1)
{if(!ffishet.is_open())
	{cout<<"Cannot open file: "<<Fishet<<endl<<flush;
//	getchar(); //not good for batch debugging...
	 exit(1);
	}

//ffishet.setf(ios_base::left);
ffishet.width(3);
 if(diploidebool) for(int j=1;j<=n_locus;j++)
  ffishet<<"Het_loc"<<j<<"  ";
 if(HexpNeioui) for(int j=1;j<=n_locus;j++)
  ffishet<<"Hexp_loc"<<j<<" ";
 if(DeltaHoui) for(int j=1;j<=n_locus;j++)
  ffishet<<"DeltaH_loc"<<j<<" ";
 if(Varoui) for(int j=1;j<=n_locus;j++)
  ffishet<<"  Var_loc"<<j<<"    ";
 if(Varoui) for(int j=1;j<=n_locus;j++)
  ffishet<<"  MGW_loc"<<j<<"    ";
 for(int j=1;j<=n_locus;j++)
  ffishet<<"Fis_loc"<<j<<"  ";
 for(int j=1;j<=n_locus;j++)
  ffishet<<"nb_alleles"<<j<<" ";
 if(diploidebool) ffishet<<"Het_moy     ";
 if(HexpNeioui) ffishet<<"Hexp_moy    ";
 if(DeltaHoui) ffishet<<"DeltaH_moy  ";
 if(Varoui) ffishet<<" Var_moy        ";
 if(Varoui) ffishet<<" MGW_moy        ";
 ffishet<<"fis_moy    ";
 ffishet<<"nb_allele_moy \n";
 //cout<<"zappe un morceau"<<flush;

 ffishet.close();
}//fin if(rep==1)

else

	{
	j=0;
	ffishet.open(Fishet,ios::app);
	while(!(ffishet.is_open()) && j<40){
cout<<"Cannot open file: "<<Fishet<<" ("<<j<<"th attempt)."<<endl<<flush;
		j++;
#ifdef WIN32
		mysleep(50); //5 ms ? //sleep(2); //2ms sous windows?
#else
		mysleep(50); //5 ms ? //sleep(1); // 1 seconde, nanosleep compliqué
#endif
		//getchar();
	 	//exit(1);
	ffishet.open(Fishet,ios::app);
	}
	if(j>=40){
//		printf("\n ecriture fichiers cannot open file: %sb after 20 tries",Fishet);
//	 	printf("\npress any key to exit");
//		getchar();
 		exit(1);
	}
 cout<<"zappe un autre morceau"<<flush;

 	for(int j=1;j<=n_locus;j++)
		fprintf(ffishet,"% lf   ",hetero[j]);
	if(HexpNeioui) for(int j=1;j<=n_locus;j++)
		fprintf(ffishet,"% lf   ",HexpNei[j]);
	if(DeltaHoui) for(int j=1;j<=n_locus;j++)
		fprintf(ffishet,"% lf     ",DeltaH[j]);
	if(Varoui) for(int j=1;j<=n_locus;j++)
		fprintf(ffishet,"%  8.6e   ",Var[j]);
	if(Varoui) for(int j=1;j<=n_locus;j++)
		fprintf(ffishet,"%  8.6e   ",M[j]);
	for(int j=1;j<=n_locus;j++)
		fprintf(ffishet,"% lf   ",fis[j]);
	for(int j=1;j<=n_locus;j++)
		fprintf(ffishet,"%10d    ",nbre_allele[j]);

	fprintf(ffishet,"% lf   ",hetero_moy);
	if(HexpNeioui) fprintf(ffishet,"% lf   ",HexpNei_moy);
	if(DeltaHoui) fprintf(ffishet,"% lf   ",DeltaH_moy);
	if(Varoui) fprintf(ffishet,"%  8.6e   ",Var_moy);
	if(Varoui) fprintf(ffishet,"%  8.6e   ",M_moy);
	fprintf(ffishet,"% lf   ",fis_moy);
	fprintf(ffishet,"%lf   \n",nbre_allele_moy);


	ffishet.close();
}//fin if rep!=1

}
*/

void ecriture_fichier_Fis_Het()
{char Fishet[50] = "Iterative_Statistics.txt";
  FILE* ffishet;

if(rep==1)
{if((ffishet=fopen(Fishet,"w"))==NULL)
	{printf("ecriture fichiers cannot open file: %s\n",Fishet);
	getchar();
	 exit(1);
	}


 if(diploidebool) for(int j=1;j<=n_locus;j++)
  fprintf(ffishet,"Het_loc%3d  ",j);
 if(HexpNeioui) for(int j=1;j<=n_locus;j++)
  fprintf(ffishet,"Hexp_loc%3d ",j);
 if(DeltaHoui) for(int j=1;j<=n_locus;j++)
  fprintf(ffishet,"DeltaH_loc%3d ",j);
 if(Varoui) for(int j=1;j<=n_locus;j++)
  fprintf(ffishet,"  Var_loc%3d    ",j);
 if(Varoui) for(int j=1;j<=n_locus;j++)
  fprintf(ffishet,"  MGW_loc%3d    ",j);
 for(int j=1;j<=n_locus;j++)
  fprintf(ffishet,"Fis_loc%3d  ",j);
 for(int j=1;j<=n_locus;j++)
  fprintf(ffishet,"nb_alleles%3d ",j);
 if(diploidebool) fprintf(ffishet,"Het_moy     ");
 if(HexpNeioui) fprintf(ffishet,"Hexp_moy    ");
 if(DeltaHoui) fprintf(ffishet,"DeltaH_moy  ");
 if(Varoui) fprintf(ffishet," Var_moy        ");
 if(Varoui) fprintf(ffishet," MGW_moy        ");
 fprintf(ffishet,"fis_moy    ");
 fprintf(ffishet,"nb_allele_moy \n");


 if(diploidebool) for(int j=1;j<=n_locus;j++)
  fprintf(ffishet,"%lf   ",hetero[j]);
 if(HexpNeioui) for(int j=1;j<=n_locus;j++)
  fprintf(ffishet,"%lf   ",HexpNei[j]);
 if(DeltaHoui) for(int j=1;j<=n_locus;j++)
  fprintf(ffishet,"%lf     ",DeltaH[j]);
 if(Varoui) for(int j=1;j<=n_locus;j++)
  fprintf(ffishet,"%8.6e   ",Var[j]);
 if(Varoui) for(int j=1;j<=n_locus;j++)
  fprintf(ffishet,"%8.6e   ",M[j]);
 for(int j=1;j<=n_locus;j++)
  fprintf(ffishet,"%lf   ",fis[j]);
 for(int j=1;j<=n_locus;j++)
  fprintf(ffishet,"%10d    ",nbre_allele[j]);

 if(diploidebool) fprintf(ffishet,"%lf   ",hetero_moy);
 if(HexpNeioui) fprintf(ffishet,"%lf   ",HexpNei_moy);
 if(DeltaHoui) fprintf(ffishet,"%lf   ",DeltaH_moy);
 if(Varoui) fprintf(ffishet,"% 8.6e   ",Var_moy);
 if(Varoui) fprintf(ffishet,"%8.6e   ",M_moy);
 fprintf(ffishet,"%lf  ",fis_moy);
 fprintf(ffishet,"%lf   \n",nbre_allele_moy);
 fclose(ffishet);

}/*fin if(rep==1)*/


else

	{int jj=0;
	 while((ffishet=fopen(Fishet,"a"))==NULL && jj<40){
	 	printf("\necriture fichiers cannot open file: %s; try=%d\n",Fishet,jj);
		jj++;
#ifdef WIN32
		 mysleep(50);//sleep(2); //2 ms
#else
		mysleep(50);//sleep(1); //1 s under lunix, E nanosleep mais compliquÈ...
#endif
		//getchar();
	 	//exit(1);
	}
	if(jj>=40){
		printf("\n ecriture fichiers cannot open file: %sb after 20 tries",Fishet);
	 	printf("\npress any key to exit");
		getchar();
 		exit(1);
	}
 	if(diploidebool) for(int j=1;j<=n_locus;j++)
		fprintf(ffishet,"%lf   ",hetero[j]);
	if(HexpNeioui) for(int j=1;j<=n_locus;j++)
		fprintf(ffishet,"%lf   ",HexpNei[j]);
	if(DeltaHoui) for(int j=1;j<=n_locus;j++)
		fprintf(ffishet,"%lf     ",DeltaH[j]);
	if(Varoui) for(int j=1;j<=n_locus;j++)
		fprintf(ffishet,"%8.6e   ",Var[j]);
	if(Varoui) for(int j=1;j<=n_locus;j++)
		fprintf(ffishet,"%8.6e   ",M[j]);
	for(int j=1;j<=n_locus;j++)
		fprintf(ffishet,"%lf   ",fis[j]);
	for(int j=1;j<=n_locus;j++)
		fprintf(ffishet,"%10d    ",nbre_allele[j]);

	if(diploidebool) fprintf(ffishet,"%lf   ",hetero_moy);
	if(HexpNeioui) fprintf(ffishet,"%lf   ",HexpNei_moy);
	if(DeltaHoui) fprintf(ffishet,"%lf   ",DeltaH_moy);
	if(Varoui) fprintf(ffishet,"%8.6e   ",Var_moy);
	if(Varoui) fprintf(ffishet,"%8.6e   ",M_moy);
	fprintf(ffishet,"%lf   ",fis_moy);
	fprintf(ffishet,"%lf   \n",nbre_allele_moy);

	fclose(ffishet);
}//fin if rep!=1

}





/*---------------------------------------------------------------------------*/

/*************calcul du temps de coalescence ***********
 ****************pour deux genes d'un individu**************/

void calcul_coa_individuel()
{int j,k,o,coa,mauvais;
// int noeud_gene1[1601],noeud_gene2[1601];

vector<int>noeud_gene1(2*n_genes+1); //FR 08/2005 le +1 est important
vector<int>noeud_gene2(2*n_genes+1);

for(int i=1;i<n_genes;i+=2)
 {coa=0;
 mauvais=0;
 retour:
  for(int oo=1;oo<=2*n_genes;oo++)
	{noeud_gene1[oo]=0;
	 noeud_gene2[oo]=0;
	}
  j=2;
  k=2;
  //stock la lignÈe du gene i
  noeud_gene1[1]=i;
  noeud_gene1[2]=noeud[i][locus].ancetre;
  while(noeud[noeud_gene1[j]][locus].ancetre>0){
	 j++;
	 noeud_gene1[j]=noeud[noeud_gene1[j-1]][locus].ancetre;
	 }
  //stock la lignÈe du gene i+1
  noeud_gene2[1]=i+1;
  noeud_gene2[2]=noeud[i+1][locus].ancetre;
  while(noeud[noeud_gene2[k]][locus].ancetre>0){
	 k++;
	 noeud_gene2[k]=noeud[noeud_gene2[k-1]][locus].ancetre;
	 }
  //affichage des lignÈes
  if(mauvais==1){
  printf("\nn_genes= %d  ;2*n_genes= %d   ;\n",n_genes,2*n_genes);
  for(int oo=1;oo<=2*n_genes;oo++){
   printf("\nancetre de %d= %d",oo,noeud[oo][locus].ancetre);
   getchar();
   }
  printf("\nlignÈe gene %d  ;lignÈe gene %d   ;\n",i,i+1);
  o=1;
  while((noeud_gene1[o]!=0)&&(noeud_gene2[o]!=0))
    {printf("    %d       ;   %d   ;\n",noeud_gene1[o],noeud_gene2[o]);
    getchar();
    o++;
    }
  }
  //comparaison des  deux lignÈes pour trouver le premier ancetre commun
  for(int oo=1;oo<=2*n_genes;oo++)
	{if((noeud_gene1[oo]==0)) break;
	 for(int m=1;m<=2*n_genes;m++)
	  {if((coa==1)||(noeud_gene2[m]==0)) break;
		if((noeud_gene1[oo]==noeud_gene2[m]))
			{temps_coa+=noeud[noeud_gene1[oo]][locus].generation;
			 compteur3+=1;
			 coa=1;
			 //printf("coa apres %d generations pour gene %d, %d;\n"
			 //			  ,temps_coa,i,i+1);
			 //printf("nbre de coalescence individuelles %d\n",compteur3);
			 //getchar();
			}
	  }
	}
	if(coa==0)
	{printf(
	  "\n\n !!probleme de calcul de temps de coa intra individu au locus: %d\n",locus);
	  printf("\nn_genes= %d  ;2*n_genes= %d   ;\n",n_genes,2*n_genes);
	  printf("\nlignÈe gene %d  ;lignÈe gene %d   ;\n",i,i+1);
	  o=1;
	  while((noeud_gene1[o]!=0)&&(noeud_gene2[o]!=0))
	    {printf("    %d       ;   %d   ;\n",noeud_gene1[o],noeud_gene2[o]);
	    getchar();
	    o++;
	    }
		getchar();
		mauvais=1;
		goto retour;
	  /*exit(1);*/
	}
 }
if(locus==n_locus)
{temps_coa_moy=(double) temps_coa/compteur3;
coa_moy_glob+=temps_coa_moy/repet;
}
//free_ivector(noeud_gene1);
//free_ivector(noeud_gene2);
}

/*****************************************************************************/

/******************ecriture des distances de dispersion "efficaces"***********/
void ecriture_disp()
{char disp[50]="EmpDisp_",ch1[100];
char Immig[50]="EmpImmigRate_";
	int i,j;

strcat(disp,fichier_genepop);
sprintf(ch1,"%d",rep);
strcat(disp,ch1);
strcat(Immig,fichier_genepop);
strcat(Immig,ch1);

ofstream fImmig(Immig,ios::out);
if(!fImmig.is_open())
{printf("ecriture fichiers cannot open file: %s\n",Immig);
	getchar();
	exit(1);
}
for(j=dim_reseau2;j>=1;j--) {
	for(i=1;i<dim_reseau1+1;i++) if(i!=dim_reseau1) {
		fImmig << (float) effectiveImmigration[i][j]/cumulEffectiveImmigration[i][j] << " ";
		//cout << effectiveImmigration[i][j] << " / " << cumulEffectiveImmigration[i][j] << "-> " << (float) effectiveImmigration[i][j]/cumulEffectiveImmigration[i][j] << endl;
		//getchar();
		effectiveImmigration_moy[i][j]+=effectiveImmigration[i][j];
		cumulEffectiveImmigration_moy[i][j]+=cumulEffectiveImmigration[i][j];
	} else {
		fImmig << (float) effectiveImmigration[i][j]/cumulEffectiveImmigration[i][j] << endl;
		//cout << effectiveImmigration[i][j] << " / " << cumulEffectiveImmigration[i][j] << "-> " << (float) effectiveImmigration[i][j]/cumulEffectiveImmigration[i][j] << endl;
		//getchar();
		effectiveImmigration_moy[i][j]+=effectiveImmigration[i][j];
		cumulEffectiveImmigration_moy[i][j]+=cumulEffectiveImmigration[i][j];
	}
}

fImmig.close();


if((fdisp=fopen(disp,"w"))==NULL)
	{printf("ecriture fichiers cannot open file: %s\n",disp);
	getchar();
	 exit(1);
	}
for(i=0;i<=2*grande_dim;i++)
  {fprintf(fdisp," %4d  %8lld %8lld %.12lf %.12lf \n",i-grande_dim,effective[i][x], effective[i][y],deffective[i][x],deffective[i][y]);
  }

fprintf(fdisp,"Various statistics on the whole empirical distribution\n");
fprintf(fdisp,"mean = %12.8lf %12.8lf \n",moy_dispx,moy_dispy);
fprintf(fdisp,"sigma≤  = %12.8lf %12.8lf \n",sig_dispx,sig_dispy);
fprintf(fdisp,"kurtosis= %12.8lf %12.8lf \n",kurto_dispx,kurto_dispy);
fprintf(fdisp,"skewness= %12.8lf %12.8lf \n",skew_dispx,skew_dispy);
fprintf(fdisp,"Various statistics on the semi empirical distribution (one side)\n");
fprintf(fdisp,"mean = %12.8lf %12.8lf \n",moy_demidispx,moy_demidispy);
fprintf(fdisp,"sigma≤  = %12.8lf %12.8lf \n",sig_demidispx,sig_demidispy);
fprintf(fdisp,"kurtosis= %12.8lf %12.8lf \n",kurto_demidispx,kurto_demidispy);
fprintf(fdisp,"skewness= %12.8lf %12.8lf",skew_demidispx,skew_demidispy);

fclose(fdisp);
}

void ecriture_disp_moy()
{char disp_moy[50]="MeanEmpDisp.txt";
char Immig_moy[50]="MeanEmpImmigRate.txt";

ofstream fImmig_moy(Immig_moy,ios::out);
if(!fImmig_moy.is_open())
{printf("ecriture fichiers cannot open file: %s\n",Immig_moy);
	getchar();
	exit(1);
}
for(int j=dim_reseau2;j>=1;j--) {
	for(int i=1;i<dim_reseau1+1;i++) if(i!=dim_reseau1) fImmig_moy << (float) effectiveImmigration_moy[i][j]/cumulEffectiveImmigration_moy[i][j] << " ";
	else fImmig_moy << (float) effectiveImmigration_moy[i][j]/cumulEffectiveImmigration_moy[i][j] << endl;
}
fImmig_moy.close();



if((fdisp_moy=fopen(disp_moy,"w"))==NULL)
	{printf("ecriture fichiers cannot open file: %s\n",disp_moy);
	getchar();
	 exit(1);
	}

for(int i=0;i<=2*grande_dim;i++)
  {fprintf(fdisp_moy," %4d %8lld %8lld %.12lf %.12lf \n",i-grande_dim,effective_moy[i][x],effective_moy[i][y],((double) effective_moy[i][x])/((double) cum_moyx), ((double) effective_moy[i][y]) / ((double) cum_moyy) );
  }
fprintf(fdisp_moy,"Various statistics on the whole empirical distribution\n");
fprintf(fdisp_moy,"mean = %12.8lf %12.8lf \n",moy_dispx,moy_dispy);
fprintf(fdisp_moy,"sigma2 = %12.8lf %12.8lf \n",sig_dispx,sig_dispy);
fprintf(fdisp_moy,"kurtosis= %12.8lf %12.8lf \n",kurto_dispx,kurto_dispy);
fprintf(fdisp_moy,"skewness= %12.8lf %12.8lf \n",skew_dispx,skew_dispy);
fprintf(fdisp_moy,"Various statistics on the semi empirical distribution (one side)\n");
fprintf(fdisp_moy,"mean = %12.8lf %12.8lf \n",moy_demidispx,moy_demidispy);
fprintf(fdisp_moy,"sigma2 = %12.8lf %12.8lf \n",sig_demidispx,sig_demidispy);
fprintf(fdisp_moy,"kurtosis= %12.8lf %12.8lf \n",kurto_demidispx,kurto_demidispy);
fprintf(fdisp_moy,"skewness= %12.8lf %12.8lf",skew_demidispx,skew_demidispy);
fclose(fdisp_moy);
}


/*****************************************************************************/
/*******************************************************************************/
void calcul_proba_identite()
{/*totalement changee le 10072002,
  mais toujours pas en diagonale
  modifs le 13082002 pour avpoir Qindividu
  */

int 	compteur_ind,Qind,_pas;
vector<int>compteur(sup(dimRes1G0,sup(dim_sample1,dim_sample2))+1,0);
vector<int>identity(sup(dimRes1G0,sup(dim_sample1,dim_sample2))+1,0);
//int compteur[2000],identity[2000];
//int *compteur,*identity;

fflush(stdout);
fflush(stdin);


if(diploidebool) {Qind=0;compteur_ind=0;}



for(int iLoc=1;iLoc<=n_locus;iLoc++)//pour chaque locus
	{for(int d1=2;d1<=n_genes;d1++)//on compare tous les genes de l'echantillon deux a deux
		for(int d2=1;d2<d1;d2++)
			{//calcul sur dim1
			 if(coord_individus[d1][y]==coord_individus[d2][y])
			 	{_pas=(coord_individus[d1][x]-coord_individus[d2][x])/vide_sampleX;
			 	 compteur[_pas]++;
			 	 if(noeud[d1][iLoc].etat_allele==noeud[d2][iLoc].etat_allele) identity[_pas]++;
			 	 //printf("\n dim1 1compteur[%d]=%d,identity[%d]=%d",_pas,compteur[_pas],_pas,identity[_pas]);
			 	 //getchar();
			 	 if(diploidebool&&(coord_individus[d1][x]==coord_individus[d2][x])&&(fmod(double(d1),double(2))==0.0))//car un ind=(impair,pair)
			        {compteur_ind++;
			         if(noeud[d1][iLoc].etat_allele==noeud[d2][iLoc].etat_allele) Qind++;
			         //printf("\n dim1 compteur_ind=%d,Qind=%d",compteur_ind,Qind);
			 	 	 //getchar();
			        }
			 	 if(dimRes1G0!=vide_sampleX && int(SortieInffnPtr1(-_pas*vide_sampleX,dimRes1G0)/vide_sampleX)!=_pas && EdgeEffect==0)//distance en faisant le tour du torre
			 	   {_pas=int(SortieInffnPtr1(-_pas*vide_sampleX,dimRes1G0))/vide_sampleX;
			 	    compteur[_pas]++;
			 	    if(noeud[d1][iLoc].etat_allele==noeud[d2][iLoc].etat_allele) identity[_pas]++;
			 	    //printf("\n dim1 2compteur[%d]=%d,identity[%d]=%d",_pas,compteur[_pas],_pas,identity[_pas]);
			 	 	//getchar();
			 	   }
			 	}
			  //else//calcul sur dim2
			  if(coord_individus[d1][x]==coord_individus[d2][x])
			 	{_pas=(coord_individus[d1][y]-coord_individus[d2][y])/vide_sampleY;
			 	 if(_pas!=0)
			 	 	{compteur[_pas]++;
			 	 	 if(noeud[d1][iLoc].etat_allele==noeud[d2][iLoc].etat_allele) identity[_pas]++;
			 	 	 //printf("\n dim2 1compteur[%d]=%d,identity[%d]=%d",_pas,compteur[_pas],_pas,identity[_pas]);
			 	 	 //getchar();
				 	}
			 	 if(dimRes2G0!=vide_sampleY && int(SortieInffnPtr1(-_pas*vide_sampleY,dimRes2G0))/vide_sampleY!=_pas && EdgeEffect==0)//distance en faisant le tour du torre
			 	    {_pas=int(SortieInffnPtr1(-_pas*vide_sampleY,dimRes2G0))/vide_sampleY;
			 	     compteur[_pas]++;
			 	     if(noeud[d1][iLoc].etat_allele==noeud[d2][iLoc].etat_allele) identity[_pas]++;
			 	     //printf("\n dim2 2compteur[%d]=%d,identity[%d]=%d",_pas,compteur[_pas],_pas,identity[_pas]);
			 	 	 //getchar();
			 	    }
			 	}
			}//fin boucle sur d2
	 for(_pas=0;_pas<=sup(dim_sample1,dim_sample2);_pas++)
	 	{if(identity[_pas]>0 )
		 	 {//printf("\nfinal compteur[%d]=%d,identity[%d]=%d",_pas,compteur[_pas],_pas,identity[_pas]);
			  //getchar();
		 	  Q1[iLoc][_pas]=(double) identity[_pas]/compteur[_pas];
		 	  //printf("\nfinal Q1[loc=%d][_pas=%d]=%f",iLoc,_pas,Q1[iLoc][_pas]);
			  //getchar();
		 	  Q1_moy[_pas]+=Q1[iLoc][_pas]/n_locus;
		 	 }
	 	}
	if(diploidebool) if(Qind>0) {Qind2[iLoc]= (double) Qind/compteur_ind; Qind_moy+=Qind2[iLoc]/n_locus;}

	}//fin boucle sur iLoc

for(_pas=0;_pas<=sup(dim_sample1,dim_sample2);_pas++) if(Q1_moy[_pas]!=0.0) Q1_moy_glob[_pas]+=Q1_moy[_pas]/repet;
if(diploidebool) if(Qind_moy!=0.0) Qind_moy_glob+=Qind_moy/repet;

}

/*****************************************************************************/


/*******************************************************************************/
void calcul_proba_identite_matrice()
{/*created 12/2005, adapted from calcul_proba_identitÈ_par_pas()*/
//calcul les probilitÈ d'identitÈ de paires de genes intra individus compris
//facilement modifiable si necessaire

int iLoc,i,j,i2,j2,d1,d2;

vector< vector< vector< vector<int> > > > compteur;
vector< vector< vector< vector<int> > > > identity;

//dimensionement des matrices locales
compteur.resize(dim_sample1);
identity.resize(dim_sample1);
for(i=0;i<dim_sample1;i++) {
	compteur[i].resize(dim_sample2);
	identity[i].resize(dim_sample2);
	for(j=0;j<dim_sample2;j++) {
		compteur[i][j].resize(dim_sample1);
		identity[i][j].resize(dim_sample1);
		for(i2=0;i2<dim_sample1;i2++) {
			compteur[i][j][i2].resize(dim_sample2,0);
			identity[i][j][i2].resize(dim_sample2,0);
		}
	}
}


for(iLoc=1;iLoc<=n_locus;iLoc++) {//pour chaque locus
	//initialisation des matrices locales
	for(i=0;i<dim_sample1;i++)
		for(j=0;j<dim_sample2;j++)
			for(i2=0;i2<dim_sample1;i2++)
				for(j2=0;j2<dim_sample2;j2++) {
					compteur[i][j][i2][j2]=0;
					identity[i][j][i2][j2]=0;
				}

	//cout << "\n\n**For locus=" << iLoc << endl;
	for(d1=2;d1<=n_genes;d1++) //on compare tous les genes de l'echantillon deux a deux
		for(d2=1;d2<d1;d2++) {
		 	 //cout << "\n\nComparison between genes " << d1 << "(" << coord_individus[d1][x] << "," << coord_individus[d1][y];
		 	 //cout <<  ") and " << d2 << "(" << coord_individus[d2][x] << "," << coord_individus[d2][y] << ")"<< endl ;
		 	 //cout << "new coord genes " << d1 << "(" << (coord_individus[d1][x]-xmin_sample)/vide_sampleX << "," << (coord_individus[d1][y]-ymin_sample)/vide_sampleY;
		 	 //cout <<  ") and " << d2 << "(" << (coord_individus[d2][x]-xmin_sample)/vide_sampleX << "," << (coord_individus[d2][y]-ymin_sample)/vide_sampleY << ")"<< endl ;
		 	 compteur[(coord_individus[d1][x]-xmin_sample)/vide_sampleX][(coord_individus[d1][y]-ymin_sample)/vide_sampleY][(coord_individus[d2][x]-xmin_sample)/vide_sampleX][(coord_individus[d2][y]-ymin_sample)/vide_sampleY]++;
		 	 //cout << "compteur=" << compteur[(coord_individus[d1][x]-xmin_sample)/vide_sample][(coord_individus[d1][y]-ymin_sample)/vide_sample][(coord_individus[d2][x]-xmin_sample)/vide_sample][(coord_individus[d2][y]-ymin_sample)/vide_sample];
		 	 if(noeud[d1][iLoc].etat_allele==noeud[d2][iLoc].etat_allele)
		 	 	 identity[(coord_individus[d1][x]-xmin_sample)/vide_sampleX][(coord_individus[d1][y]-ymin_sample)/vide_sampleY][(coord_individus[d2][x]-xmin_sample)/vide_sampleX][(coord_individus[d2][y]-ymin_sample)/vide_sampleY]++;
		 	 //cout << " states are " << noeud[d1][iLoc].etat_allele << " and " << noeud[d2][iLoc].etat_allele ;
		 	 //cout << "-> identity=" << identity[(coord_individus[d1][x]-xmin_sample)/vide_sample][(coord_individus[d1][y]-ymin_sample)/vide_sample][(coord_individus[d2][x]-xmin_sample)/vide_sample][(coord_individus[d2][y]-ymin_sample)/vide_sample];
		 	 //getchar();
		 	 //si on ne veut pas prendre en compte les proba intra individus :
		 	 //if((coord_individus[d1][x]==coord_individus[d2][x])&&(fmod(double(d1),double(2))==0.0))//car un ind=(impair,pair)
		}//fin boucle sur d2

	for(i=0;i<dim_sample1;i++)
		for(j=0;j<dim_sample2;j++)
			for(i2=0;i2<dim_sample1;i2++)
				for(j2=0;j2<dim_sample2;j2++) {

					if(compteur[i][j][i2][j2]>0) QMatrix[iLoc-1][i][j][i2][j2]= (double) identity[i][j][i2][j2]/compteur[i][j][i2][j2];
					else QMatrix[iLoc-1][i][j][i2][j2]=-1.0;

					QMatrix_Moy[i][j][i2][j2]+=QMatrix[iLoc-1][i][j][i2][j2]/n_locus;
					//if(QMatrix_Moy[i][j][i2][j2]>=0.0) cout << "\n" << i << "," << j << "," << i2 << "," << j2 << "->" << QMatrix_Moy[i][j][i2][j2]*n_locus;
				}

}//fin boucle sur iLoc

//computation of the global stat = pour toutes mes repets
//cout << endl;
//cout << endl;
for(i=0;i<dim_sample1;i++)
	for(j=0;j<dim_sample2;j++)
		for(i2=0;i2<dim_sample1;i2++)
			for(j2=0;j2<dim_sample2;j2++) {
				//if(QMatrix_Moy[i][j][i2][j2]>=0.0) cout << "\n" << i << "," << j << "," << i2 << "," << j2 << "->" <<QMatrix_Moy[i][j][i2][j2];
				QMatrix_Moy_Glob[i][j][i2][j2]+=QMatrix_Moy[i][j][i2][j2]/repet;
			}


}

/*****************************************************************************/

/******************ecriture Matrice Proba d'identitÈ**************************/
void ecriture_matrice_proba_id(void) {
char FileName[]="Matrix_ProbId.txt";
int i,j,i2,j2;//,count;

ofstream File;
File.open(FileName,ios::out);
if(!File.is_open()) {
	cout << "Cannot open file :" << FileName << endl << flush;
	getchar();
	exit(1);
}
//ecriture "colone" x1,y1,x2,y2,Q((x1,y1),(x2,y2))  (x1 = coord en x du gene 1... y2 = coord en y du gene2)
//count=0;
//cout << endl;
//cout << endl;
for(i=0;i<dim_sample1;i++)
	for(j=0;j<dim_sample2;j++)
		for(i2=0;i2<dim_sample1;i2++)
			for(j2=0;j2<dim_sample2;j2++) {
				if(QMatrix_Moy_Glob[i][j][i2][j2]>=0.0) { //FER
					//count++;
					//cout << endl;
					//cout << count << ";" <<  i*vide_sample+xmin_sample << "," << j*vide_sample+ymin_sample << "," << i2*vide_sample+xmin_sample;
					//cout << "," << j2*vide_sample+ymin_sample << "->" <<QMatrix_Moy[i][j][i2][j2] << endl;
					File <<  i*vide_sampleX+xmin_sample << " " << j*vide_sampleY+ymin_sample << " " << i2*vide_sampleX+xmin_sample;
					File << " " << j2*vide_sampleY+ymin_sample << " " <<QMatrix_Moy_Glob[i][j][i2][j2] << endl;
				}
}


/*
//ecriture sous forme "matricielle" x1 = coord en x du gene 1; y2 = coord en y du gene2
//             x1-x2               x1-x3     ...    x2-x1.    ..
//y1-y2 Q((x1,y1),(x2,y2))
//y1-y3
//...
cout << "\n\nMatrice des proba d'identitÈ"<< endl;
cout << setw(12) << "j\\i     ";
File << setw(12) << "j\\i     ";
for(int i=0;i<dim_sample1;i++)
	for(int i2=0;i2<dim_sample1;i2++) {
		cout << setw(4) << i*vide_sampleX+xmin_sample << "-" << setw(4) << i2*vide_sampleX+xmin_sample << " ";
		File << setw(4) << i*vide_sampleX+xmin_sample << "-" << setw(4) << i2*vide_sampleX+xmin_sample << " ";
	}

cout << endl;
File << endl;

for(int j=0;j<dim_sample2;j++)
	for(int j2=0;j2<dim_sample2;j2++) {
		cout << setw(4) << j*vide_sampleY+ymin_sample << "-" << setw(4) << j2*vide_sampleY+ymin_sample << " ";
		File << setw(4) << j*vide_sampleY+ymin_sample << "-" << setw(4) << j2*vide_sampleY+ymin_sample << " ";
		for(int i=0;i<dim_sample1;i++)
			for(int i2=0;i2<dim_sample1;i2++) {
				cout << setw(9) << QMatrix_Moy_Glob[i][j][i2][j2] << " " ;
				File << setw(9) << QMatrix_Moy_Glob[i][j][i2][j2] << " " ;
			}
		cout << endl;
		File << endl;
	}
*/
cout<< endl;
File.close();

}
/*****************************************************************************/


/*----------------calcul de l'heterozygotie attendue *Hexp
                        et du Fis (Qintra-individu - Qintra_pop/1-Qintra_pop)-----*/
void calcul_hetero_fis()
{
//modifiÈe le 31072002
//prends comme base les proba d'identitÈ.
//11022003 pb? comparaison avec mathematica
//pb car Fis plus grand pour petit torre alors que ca devrait etre l'inverse (cf mathematica)
//22022003 pb car on prends que sur l"echantillon pour calculer Qpop! faudrait toute la pop

double Qpop;

//initialisations dans ini_moyenne

if(HexpNeioui) freq_sample();

for(int loc=1;loc<=n_locus;loc++)
	{Qpop=0.0;
	if(diploidebool) hetero[loc]=1.0-Qind2[loc];
	if(HexpNeioui){
		for(int i=Kmin;i<=Kmax;i++) HexpNei[loc]+=freq[loc][i]*(1.0-freq[loc][i]);
		HexpNei[loc]*=n_genes/(n_genes-1);
	}
    for(int _pas=1;_pas<sup(dim_sample1,dim_sample2);_pas++) Qpop+=Q1[loc][_pas];
	Qpop=Qpop/( ((double) sup(dim_sample1,dim_sample2)) - 1.0);
	if(diploidebool) if(1.0-Qpop>petit) fis[loc]=(Qind2[loc]-Qpop)/(1.0-Qpop);
	  					else fis[loc]=0.0;
	if(diploidebool) hetero_moy+=hetero[loc];
	if(HexpNeioui) {
		HexpNei_moy+=HexpNei[loc];
		HexpNei_moy_glob_var+=pow(HexpNei[loc],2);
		if(DeltaHoui) {
			if(model_mut=='5'){
				if(nbre_allele[loc]<=max_allele) {
					if(n_genes==200) DeltaH[loc]=HexpNei[loc]-Hexp_GSMs100[nbre_allele[loc]];
					 else if(n_genes==60) DeltaH[loc]=HexpNei[loc]-Hexp_GSMs30[nbre_allele[loc]];
					 	    else {
				 				printf("Can not calculate DeltaH with this sample size; program finished");
				 				getchar();
				 				exit(0);
							}
				 }
				 else {
				 	printf("Too many alleles in the sample to calculate DeltaH; program finished");
				 	getchar();
				 	exit(0);
				 }
			}
			else {
				 	printf("wrong mutation model to calculate DeltaH; program finished");
				 	getchar();
				 	exit(0);
			}
		DeltaH_moy+=DeltaH[loc];
		DeltaH_moy_glob_var+=pow(DeltaH[loc],2);
	}
	}
	if(diploidebool) fis_moy_numer+=Qind2[loc]-Qpop;
	if(diploidebool) fis_moy_denom+=1.0-Qpop;
	Qpop_moy+=Qpop;
	}
//moyennes sur locus
if(diploidebool) hetero_moy=hetero_moy/n_locus;
if(HexpNeioui) HexpNei_moy/=n_locus;
if(DeltaHoui) DeltaH_moy/=n_locus;
if(diploidebool) if(fis_moy_denom>petit) fis_moy=fis_moy_numer/fis_moy_denom;
					else fis_moy=0.0;
Qpop_moy=Qpop_moy/n_locus;

if(Varoui) var_allele();


//moyenne sur repet
if(diploidebool) hetero_moy_glob+=hetero_moy;
if(HexpNeioui) HexpNei_moy_glob+=HexpNei_moy;
if(DeltaHoui) DeltaH_moy_glob+=DeltaH_moy;
if(diploidebool) fis_moy_numer_glob+=fis_moy_numer;
if(diploidebool) fis_moy_denom_glob+=fis_moy_denom;
Qpop_moy_glob+=Qpop_moy;
if(diploidebool) fis_moy_glob+=fis_moy;//le bon

if(rep==repet)
 {
  if(diploidebool) hetero_moy_glob/=repet;
  if(HexpNeioui) {
  	HexpNei_moy_glob/=repet;
  	HexpNei_moy_glob_var=sqrt(HexpNei_moy_glob_var/(n_locus*repet-1)-pow(HexpNei_moy_glob,2) )/sqrt(double(n_locus*repet));
  }
  if(DeltaHoui) {
  	DeltaH_moy_glob/=repet;
  	DeltaH_moy_glob_var=sqrt(DeltaH_moy_glob_var/(n_locus*repet-1)-pow(DeltaH_moy_glob,2) )/sqrt(double(n_locus*repet));
  }
  if(Varoui) {
  	Var_moy_glob/=repet;
  	Var_moy_glob_var=sqrt(Var_moy_glob_var/(n_locus*repet-1)-pow(Var_moy_glob,2))/sqrt(double(n_locus*repet));
  	M_moy_glob/=repet;
  	M_moy_glob_var=sqrt(M_moy_glob_var/(n_locus*repet-1)-pow(M_moy_glob,2))/sqrt(double(n_locus*repet));
  }
  Qpop_moy_glob/=repet;
  if(diploidebool) fis_moy_glob/=repet;//le bon
  if(diploidebool) fis_moy_numer_glob/=repet;
  if(diploidebool) fis_moy_denom_glob/=repet;

  //calcul des Hexp theoriques
  switch(model_mut)
	{case'1':
	 //fprintf(fp1," sous SMM; \n");
	 Hexp=1.0-1.0/sqrt(1.0+2*4*_mu*dens0);
	 Vexp=4*_mu*dens0/2;
	 break;
	 case'2':
	 //fprintf(fp1," sous IAM; \n");
	 Hexp=4*_mu*dens0/(1.0+4*_mu*dens0);
	 Vexp=numeric_limits<double>::infinity();
	 break;
	 case'3':
	 //fprintf(fp1," sous KAM; \n");
	 Hexp=1.0*(1.0 - (1+4*_mu*dens0/(Kmax-Kmin-1)) / (1.0+4*_mu*dens0*(Kmax-Kmin)/(Kmax-Kmin-1)));
	 Vexp=0.25*4*_mu*dens0*(Kmax-Kmin)*(Kmax-Kmin-1)*(Kmax-Kmin+1)/6.0;
	 break;
	 case'4':
	 //fprintf(fp1," sous TPM; \n");
	 Hexp=numeric_limits<double>::infinity();
	 Vexp=numeric_limits<double>::infinity();
	 break;
	 case'5':
	 //fprintf(fp1," sous GSM; \n");
	 Hexp=numeric_limits<double>::infinity();
	 Vexp=numeric_limits<double>::infinity();
	 break;
	}
  printf("\n");
  if(diploidebool) printf("\n Qind moy=%11.8lf (hetero moy=%11.8lf)",Qind_moy_glob,hetero_moy_glob);
  if(HexpNeioui) printf("\n HexpNei=%11.8lf (+- %11.8lf)",HexpNei_moy_glob,1.96*HexpNei_moy_glob_var);
  if(DeltaHoui) printf("\n DeltaH=%11.8lf (+- %11.8lf)",DeltaH_moy_glob,1.96*DeltaH_moy_glob_var);
  if(Varoui)     printf("\n Var=%11.8lf (+- %11.8lf)",Var_moy_glob,1.96*Var_moy_glob_var);
  if(Varoui)     printf("\n M=%11.8lf (+- %11.8lf)",M_moy_glob,1.96*M_moy_glob_var);
  if(diploidebool) printf("\n Fis moy=%11.8lf ",fis_moy_glob);
  if(diploidebool) printf("\n Fis moy2=Fis multirepet=%11.8lf ",fis_moy_numer_glob/fis_moy_denom_glob);
  printf("\n Qpop moy=%11.8lf \n ",Qpop_moy_glob);
  printf("\n Some theoretical expectations: ");
  printf("\n Hexp=%11.8lf",Hexp);
  printf("\n Vexp=%11.8lf",Vexp);
 }
}
/*******************************************************************/

/***********calcul de la moyenne, sigma≤, kurtosis et skewness de disp efficcace**/

void calcul_stat_disp()
{int cumx,cumy;

cumx=cumy=0;
moy_dispx=moy_dispy=0.0;
sig_dispx=sig_dispy=0.0;
kurto_dispx=kurto_dispy=0.0;
skew_dispx=skew_dispy=0.0;
moy_demidispx=moy_demidispy=0.0;
sig_demidispx=sig_demidispy=0.0;
kurto_demidispx=kurto_demidispy=0.0;
skew_demidispx=skew_demidispy=0.0;

for(int i=0;i<=2*grande_dim;i++)
 {cumx+=effective[i][x];
  cumy+=effective[i][y];
  effective_moy[i][x]+=effective[i][x];
  effective_moy[i][y]+=effective[i][y];
 }
//printf("\n cumx: %d; cumy: %d",cumx,cumy);
//printf("\n cum_moyx: %d; cum_moyy: %d",cum_moyx,cum_moyy);


for(int i=0;i<=2*grande_dim;i++)
{deffective[i][x]=double(effective[i][x])/ double(cumx);
 deffective[i][y]=double(effective[i][y])/ double(cumy);
 moy_dispx+=deffective[i][x]*(i-grande_dim);
 moy_dispy+=deffective[i][y]*(i-grande_dim);
 sig_dispx+=deffective[i][x]*pow(double(i-grande_dim),double(2));
 sig_dispy+=deffective[i][y]*pow(double(i-grande_dim),double(2));
 kurto_dispx+=deffective[i][x]*pow(double(i-grande_dim),double(4));
 kurto_dispy+=deffective[i][y]*pow(double(i-grande_dim),double(4));
 skew_dispx+=deffective[i][x]*pow(double(i-grande_dim),double(3));
 skew_dispy+=deffective[i][y]*pow(double(i-grande_dim),double(3));
 moy_demidispx+=deffective[i][x]*fabs( double(i-grande_dim));
 moy_demidispy+=deffective[i][y]*fabs( double(i-grande_dim));
}

for(int i=0;i<=2*grande_dim;i++)
{sig_demidispx+=deffective[i][x]*pow(fabs( double(i-grande_dim))-moy_demidispx,double(2));
 sig_demidispy+=deffective[i][y]*pow(fabs( double(i-grande_dim))-moy_demidispy,double(2));
 kurto_demidispx+=deffective[i][x]*pow(fabs( double(i-grande_dim))-moy_demidispx,double(4));
 kurto_demidispy+=deffective[i][y]*pow(fabs( double(i-grande_dim))-moy_demidispy,double(4));
 skew_demidispx+=deffective[i][x]*pow(fabs( double(i-grande_dim))-moy_demidispx,double(3));
 skew_demidispy+=deffective[i][y]*pow(fabs( double(i-grande_dim))-moy_demidispy,double(3));
}

if(sig_dispx!=0.0)
  {kurto_dispx=kurto_dispx/pow(sig_dispx,double(2))-3.0;
   skew_dispx=skew_dispx/pow(sig_dispx,double(3/2));
   kurto_demidispx=kurto_demidispx/pow(sig_demidispx,double(2))-3.0;
   skew_demidispx=skew_demidispx/pow(sig_demidispx,double(3/2));
  }
 else
   {kurto_dispx=0.0;
    skew_dispx=0.0;
    kurto_demidispx=0.0;
    skew_demidispx=0.0;
   }
if(sig_dispy!=0.0)
  {kurto_dispy=kurto_dispy/pow(sig_dispy,double(2))-3.0;
   skew_dispy=skew_dispy/pow(sig_dispy,double(3/2));
   kurto_demidispy=kurto_demidispy/pow(sig_demidispy,double(2))-3.0;
   skew_demidispy=skew_demidispy/pow(sig_demidispy,double(3/2));
  }
 else
   {kurto_dispy=0.0;
    skew_dispy=0.0;
    kurto_demidispy=0.0;
    skew_demidispy=0.0;
   }

}

void calcul_stat_disp_moy()
{

moy_dispx=moy_dispy=0.0;
sig_dispx=sig_dispy=0.0;
kurto_dispx=kurto_dispy=0.0;
skew_dispx=skew_dispy=0.0;
moy_demidispx=moy_demidispy=0.0;
sig_demidispx=sig_demidispy=0.0;
kurto_demidispx=kurto_demidispy=0.0;
skew_demidispx=skew_demidispy=0.0;

for(int i=0;i<=2*grande_dim;i++)
 {cum_moyx+=effective_moy[i][x];
  cum_moyy+=effective_moy[i][y];
  deffective[i][x]=0.0;
  deffective[i][y]=0.0;

 }
for(int i=0;i<=2*grande_dim;i++)
{deffective[i][x]=((double) effective_moy[i][x])/ double(cum_moyx);
 deffective[i][y]=((double) effective_moy[i][y])/ double(cum_moyy);
 moy_dispx+=deffective[i][x]*(i-grande_dim);
 moy_dispy+=deffective[i][y]*(i-grande_dim);
 sig_dispx+=deffective[i][x]*pow(double(i-grande_dim),double(2));
 sig_dispy+=deffective[i][y]*pow(double(i-grande_dim),double(2));
 kurto_dispx+=deffective[i][x]*pow(double(i-grande_dim),double(4));
 kurto_dispy+=deffective[i][y]*pow(double(i-grande_dim),double(4));
 skew_dispx+=deffective[i][x]*pow(double(i-grande_dim),double(3));
 skew_dispy+=deffective[i][y]*pow(double(i-grande_dim),double(3));
 moy_demidispx+=deffective[i][x]*fabs( double(i-grande_dim));
 moy_demidispy+=deffective[i][y]*fabs( double(i-grande_dim));
}

for(int i=0;i<=2*grande_dim;i++)
{sig_demidispx+=deffective[i][x]*pow(fabs( (double) (i-grande_dim))-moy_demidispx,double(2));
 sig_demidispy+=deffective[i][y]*pow(fabs( (double) (i-grande_dim))-moy_demidispy,double(2));
 kurto_demidispx+=deffective[i][x]*pow(fabs( (double) (i-grande_dim))-moy_demidispx,double(4));
 kurto_demidispy+=deffective[i][y]*pow(fabs( (double) (i-grande_dim))-moy_demidispy,double(4));
 skew_demidispx+=deffective[i][x]*pow(fabs( (double) (i-grande_dim))-moy_demidispx,double(3));
 skew_demidispy+=deffective[i][y]*pow(fabs( (double) (i-grande_dim))-moy_demidispy,double(3));
}

if(sig_dispx!=0.0)
  {kurto_dispx=kurto_dispx/pow(sig_dispx,double(2))-3.0;
   skew_dispx=skew_dispx/pow(sig_dispx,double(3/2));
   kurto_demidispx=kurto_demidispx/pow(sig_demidispx,double(2))-3.0;
   skew_demidispx=skew_demidispx/pow(sig_demidispx,double(3/2));
  }
 else
   {kurto_dispx=0.0;
    skew_dispx=0.0;
    kurto_demidispx=0.0;
    skew_demidispx=0.0;
   }
if(sig_dispy!=0.0)
  {kurto_dispy=kurto_dispy/pow(sig_dispy,double(2))-3.0;
   skew_dispy=skew_dispy/pow(sig_dispy,double(3/2));
   kurto_demidispy=kurto_demidispy/pow(sig_demidispy,double(2))-3.0;
   skew_demidispy=skew_demidispy/pow(sig_demidispy,double(3/2));
  }
 else
   {kurto_dispy=0.0;
    skew_dispy=0.0;
    kurto_demidispy=0.0;
    skew_demidispy=0.0;
   }
}
/******************************************************************************/

/*********calcul des frequences alleliques dans l'echantillon***/
void freq_sample()
{for(int j=1;j<=n_locus;j++){
	for(int i=1;i<=n_genes;i++) for(int k=Kmin;k<=Kmax;k++)
	       if(noeud[i][j].etat_allele==k){
	       	freq[j][k]+=1.0;
	       }
	for(int k=Kmin;k<=Kmax;k++) freq[j][k]/=n_genes;
}
//return(0);
}

//*********calcul de la variance de taille allelique dans l'echantillon***/
void var_allele()
{
 double *Mean,*Mean2;

Mean=dvector(n_locus+2);
Mean2=dvector(n_locus+2);
//calcul la moyenne et la moyenne des carrÈs sans frequences
for(int j=1;j<=n_locus;j++){
	Mean[j]=0.0;
	Mean2[j]=0.0;
	for(int i=1;i<=n_genes;i++){
		Mean[j]+=noeud[i][j].etat_allele;
		Mean2[j]+=pow(double(noeud[i][j].etat_allele),double(2));
	}
	Mean[j]/=n_genes;
	Mean2[j]/=n_genes;
	//printf("Mean[%d]=%11.8lf",j,Mean[j]);
	//printf("Mean2[%d]=%11.8lf",j,Mean2[j]);
	//getchar();
}
for(int j=1;j<=n_locus;j++){
	//for(i=1;i<=n_genes;i++) Var[j]+=pow((noeud[i][j].etat_allele- Mean[j]),2);
	//Var[j]/=n_genes;
	Var[j]=(Mean2[j]-pow(Mean[j],double(2)))*n_genes/(n_genes-1);
	Var_moy+=Var[j];
	Var_moy_glob_var+=pow(Var[j],double(2));
}
Var_moy/=n_locus;
Var_moy_glob+=Var_moy;

free_dvector(Mean);
free_dvector(Mean2);

for(int j=1;j<=n_locus;j++){
	M[j]= (double) nbre_allele[j]/(allele_max[j]-allele_min[j]+1.0);
	//printf("M[%d]=%e, nre_allele=%d, max=%d, min=%d",j,M[j],nbre_allele[j],allele_max[j],allele_min[j]);
	//getchar();
	M_moy+=M[j];
	M_moy_glob_var+=pow(M[j],double(2));
}
M_moy/=n_locus;
M_moy_glob+=M_moy;
}


/*-------------------------------------------------------------------------*/
/*------------------loi binomiale pour mutations----------------------------*/
double binom(double pp,int n)
{int j;
 int nold=(-1);
 double am,em,g,angle,p,bnl,sq,t,z,pold=(-1),pc,plog,pclog,en,oldg;

p=(pp<=0.5 ? pp : 1.0-pp);
am=n*p;
if(n<1000)
 {bnl=0.0;
  for(j=1;j<=n;j++) if(alea()<p) ++bnl;
 }
 else
  if(am<1.0)
	{g=exp(-am);
	 t=1.0;
	 for(j=0;j<=n;j++) {t*=alea(); if(t<g) break;}
	 bnl=(j<=n ? j : n);
	}
	else
	 {if(n!=nold)
		{en=n;
		oldg=gammln(en+1.0);
		//nold=n;
		}
	  if(p!=pold)
		{pc=1.0-p;
		 plog=log(p);
		 pclog=log(pc);
		 //pold=p;
		}
	  sq=sqrt(2.0*am*pc);
	  do
		{do
		 {angle=PI*alea();
		  z=tan(angle);
		  em=sq*z+am;
		 } while(em<0.0||em>=(en+1.0));
		 em=floor(em);
		 t=1.2*sq*(1.0+z*z)*exp(oldg-gammln(em+1.0)-gammln(en-em+1.0)+em*plog+(en-em)*pclog);
		} while(alea()>t);
		bnl=em;
//printf("\n binomiale=%f",bnl);
//cout<<pp<<" "<<n;
//getchar();
	 }
  if(p!=pp) bnl=n-bnl;
  //printf("\n binomiale=%f",bnl);
  //getchar();
  return bnl;
}
/*---------------------------------------------------------------------------*/

/*--------------------loi gamma pour loi de poisson--------------------------*/
double gammln(double xx)
{double xxx,tmp,ser;
 static double cof[6]={76.18009173,-86.50532033,24.01409822,
	-1.231739516,0.120858003e-2,-0.53363382e-5};
 int j;

 xxx=xx-1.0;
 tmp=xxx+5.5;
 tmp-=(xxx+0.5)*log(tmp);
 ser=1.0;
 for(j=0;j<5;j++)
	{xxx+=1.0;
	 ser+=cof[j]/xxx;
	}
 return -tmp+log(2.50662827465*ser);
}
/*---------------------------------------------------------------------------*/

/*-----------loi geometrique pour TPM et GSM---------------------------------*/
int loi_geom(const double var_geom)
{int g;
 double r,a,c,aleat;

do {
	r=((1.0+sqrt(1.0+4.0*var_geom))/2);
	c=(1.0/(r-1.0));
	a=(1.0/(1.0+c));
	do aleat=alea(); while (aleat<=0.0);
	g=int(floor((log(aleat/c))/log(a)));
	}while(g<=0);
return g;
}
/*---------------------------------------------------------------------------*/
/*----------essayer une autre procedure pour loi geometrique----------------*/


/*------------------procedure mutation---------------------------------------*/
int mutation(long int temps)
{ //double m;

if (temps==0) n_mut=0;
else
 {//m=temps*mu;
 //n_mut=poisson(m);
 //n_mut=arnaud(m);
 n_mut=int(binom(mu,temps));
 }


if(temps!=0) {mut_moy_glob+= double(n_mut)/temps;mut_moy_glob_var+=pow(double(n_mut)/temps,double(2));}
compte_mut+=1;
return n_mut;
}
/*---------------------------------------------------------------------------*/


/*------------------loi de poisson pour procedure mutation-------------------*/
double poisson(double poiss)
{static double sq,alpoiss,g,oldm=(-1.0);
 double em,t,y1;
 float aleat;

 if(poiss<12.0)
 {if(poiss!=oldm)
	{oldm=poiss;
	 g=exp(-poiss);
	}
  em=-1;
  t=1.0;
  do{aleat=alea();
	  em+=1.0;
	  t*=aleat;
	  }while(t>g);

 }
  else
	{if(poiss!=oldm)
		{oldm=poiss;
		 sq=sqrt(2.0*poiss);
		 alpoiss=log(poiss);
		 g=poiss*alpoiss-gammln(poiss+1.0);
		}
	 do{
			do {aleat=alea();
				 y1=tan(PI*aleat);
				 em=sq*y1+poiss;
				}while(em<0.0);
			em=floor(em);
			t=0.9*(1.0+y1*y1)*exp(em*alpoiss-gammln(em+1.0)-g);
		}while(aleat>t);
	 }
	return em;
}
